import React from 'react';
import SelectLanguageView from './SelectLanguage';

const SelectLanguage: React.FC = () => {
  return <SelectLanguageView />;
};
export default SelectLanguage;
