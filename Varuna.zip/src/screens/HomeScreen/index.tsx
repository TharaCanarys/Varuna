import React, {useEffect, useState} from 'react';
import HomeScreenView from './HomesSreenView';
import Loader from '../../components/loader';

// HomeScreen component
const HomeScreen: React.FC = () => {
  // State to store location data

  // State to control loader visibility
  const [isLoaderVisible, setLoaderVisible] = useState(false);

  // useEffect(() => {
  //   // Simulate loading time
  //   const timer = setTimeout(() => {
  //     setLoaderVisible(false);
  //   }, 2000);

  //   // Clean up timer on component unmount
  //   return () => clearTimeout(timer);
  // }, []);

  // Render loader while content is loading
  if (isLoaderVisible) {
    return <Loader />;
  }

  // Render main content when loading is complete
  return <HomeScreenView />;
};
export default HomeScreen;
