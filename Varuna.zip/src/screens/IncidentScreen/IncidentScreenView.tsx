import React, {useState, useCallback, useEffect} from 'react';
import {View, StyleSheet, RefreshControl, FlatList} from 'react-native';
import {useDispatch, useSelector} from 'react-redux';
import {COLORS} from '../../constants/colors';
import {FwButtonPrimary, FwDialog, FwTextPrimary} from '../../elements';
import {
  IncidentScreenViewProps,
  IncidentTypes,
} from '../../types/incidentTypes';
import PageHeader from '../../components/PageHeader';
import {LanguageString, USER_ROLES} from '../../constants/data';
import {commonStyle} from '../../constants/theme';
import {RootState} from '../../store/store';
import {normalized} from '../../constants/platform';
import {
  IncidentDetailsComponent,
  RenderIncidentItem,
  IncidentAddComponent,
} from '../../components';
import {setSnackMessage} from '../../store/appSlice';
import {getIncidentData} from '../../services/apiServices';

const IncidentScreenView = ({
  newIncident,
  setNewIncident,
  editingStatus,
  setEditingStatus,
  selectedIncident,
  startEditingStatus,
  newStatus,
  setNewStatus,
  closeIncidentDetails,
  openIncidentDetails,
  incidents,
  setIncidents,
  saveStatus,
  closeAddNewIncident,
  isAddingNewIncident,
  errors,
  openAddNewIncident,
  refreshing,
  setErrors,
  setRefreshing,
  validateStatus,
  setDatePickerVisibility,
}: IncidentScreenViewProps) => {
  const dispatch = useDispatch();
  const [deleteConfirmationVisible, setDeleteConfirmationVisible] =
    useState(false);
  const [incidentToDelete, setIncidentToDelete] = useState<number | null>(null);
  const language = useSelector(
    (state: RootState) => state.app.selectedLanguage,
  );

  const onGetSuccess = (data: IncidentTypes[]) => {
    setIncidents(data);
  };

  const onGetFailed = useCallback((error: any) => {
    // dispatch(setNotificationVisible(true));
    dispatch(setSnackMessage(error.message));

    console.log('Failed to get incident data', error.message);
  }, []);

  useEffect(() => {
    getIncidents();
  }, []);

  const getIncidents = async () => {
    let payload = [0];
    getIncidentData(payload, onGetSuccess, onGetFailed);
  };
  // Refresh function for pull-to-refresh
  useEffect(() => {
    if (language) {
      onRefresh();
    }
  }, [language]);
  const onRefresh = useCallback(() => {
    setRefreshing(true);
    getIncidents();
    // Simulate fetching new data
    setTimeout(() => {
      // setIncidents(incidentData);
      setRefreshing(false);
    }, 2000);
  }, [setRefreshing, setIncidents]);

  const role = useSelector((state: RootState) => state.auth.userRole);

  const validateRole =
    role == USER_ROLES.ADMIN ||
    role == USER_ROLES.SUPER_ADMIN ||
    role == USER_ROLES.IT_SUPPORT;
  // Memoized options for dropdowns
  const statusOptions = [
    {label: LanguageString('Reported'), value: 'Reported'},
    {label: LanguageString('Resolved'), value: 'Resolved'},
  ];

  const sensorOptions = [
    {label: LanguageString('Alert') + ' ' + 1, value: 'Alert 1'},
    {label: LanguageString('Alert') + ' ' + 2, value: 'Alert 2'},
    {label: LanguageString('Alert') + ' ' + 3, value: 'Alert 3'},
  ];

  const locationOptions = [
    {label: LanguageString('Golghar'), value: 'Golghar'},
    {label: LanguageString('Mohaddipur'), value: 'Mohaddipur'},
    {label: LanguageString('Gorakhnath'), value: 'Gorakhnath'},
    {label: LanguageString('Shahpur'), value: 'Shahpur'},
    {label: LanguageString('Rapti Nagar'), value: 'Rapti Nagar'},
  ];

  // Function to validate new incident
  const validateNewIncident = useCallback(() => {
    let isValid = true;
    const newErrors = {
      alertName: '',
      reportedBy: '',
      reportedTime: '',
      location: '',
      resulationTime: '',
      status: '',
    };

    if (!newIncident.alertName) {
      newErrors.alertName =
        LanguageString('Alert Name') + ' ' + LanguageString('is required');
      isValid = false;
    }

    if (!newIncident.location) {
      newErrors.location =
        LanguageString('Location') + ' ' + LanguageString('is required');
      isValid = false;
    }

    if (!newIncident.status) {
      newErrors.status =
        LanguageString('Status') + ' ' + LanguageString('is required');
      isValid = false;
    }

    setErrors(newErrors);
    return isValid;
  }, [newIncident, setErrors]);

  // Function to handle adding new incident
  const handleAddNewIncident = useCallback(() => {
    if (validateNewIncident()) {
      const newId = Math.max(...incidents?.map(s => s.id), 0) + 1;
      const incidentToAdd = {
        ...newIncident,
        id: newId,
        reportedBy: role, // Replace this with the actual logged-in user's name or ID
        resulationTime: '0',
      };
      setIncidents(prevIncidents => [
        ...prevIncidents,
        {...incidentToAdd, reportedBy: incidentToAdd.reportedBy || ''},
      ]);
      closeAddNewIncident();
    }
  }, [
    validateNewIncident,
    newIncident,
    incidents,
    setIncidents,
    closeAddNewIncident,
  ]);

  // Function to show delete confirmation
  const showDeleteConfirmation = useCallback((id: number) => {
    setIncidentToDelete(id);
    setDeleteConfirmationVisible(true);
  }, []);

  // Function to hide delete confirmation
  const hideDeleteConfirmation = useCallback(() => {
    setDeleteConfirmationVisible(false);
    setIncidentToDelete(null);
  }, []);

  // Function to handle deleting incident
  const handleDeleteIncident = useCallback(() => {
    if (incidentToDelete !== null) {
      setIncidents(prevIncidents =>
        prevIncidents.filter(incident => incident.id !== incidentToDelete),
      );
      hideDeleteConfirmation();
    }
  }, [incidentToDelete, setIncidents, hideDeleteConfirmation]);

  const hideDatePicker = useCallback(() => {
    setDatePickerVisibility(false);
  }, [setDatePickerVisibility]);

  const handleConfirm = useCallback(
    (date: Date) => {
      hideDatePicker();
      const indianTime = new Date(date.getTime() + 5.5 * 60 * 60 * 1000);
      setNewIncident(prevIncident => ({
        ...prevIncident,
        reportedTime: indianTime.toISOString(),
      }));
    },
    [hideDatePicker, setNewIncident],
  );

  // Memoized render item for FlatList
  const renderIncidentItem = useCallback(
    ({item}: {item: IncidentTypes}) => (
      <RenderIncidentItem
        item={item}
        styles={styles}
        validateRole={validateRole}
        setEditingStatus={setEditingStatus}
        startEditingStatus={startEditingStatus}
        openIncidentDetails={openIncidentDetails}
        showDeleteConfirmation={showDeleteConfirmation}
      />
    ),
    [
      openIncidentDetails,
      setEditingStatus,
      startEditingStatus,
      showDeleteConfirmation,
    ],
  );

  return (
    <>
      <PageHeader title="Incident" />
      {isAddingNewIncident || selectedIncident ? (
        <View></View>
      ) : (
        <View style={commonStyle.addButtonContainer}>
          <FwButtonPrimary
            mode="outlined"
            onPress={openAddNewIncident}
            icon="plus">
            <FwTextPrimary>
              {LanguageString('Add New Incident')}
            </FwTextPrimary>
          </FwButtonPrimary>
        </View>
      )}
      <View style={styles.container}>
        <FlatList
          data={incidents}
          renderItem={renderIncidentItem}
          keyExtractor={item => item?.incidentID}
          refreshControl={
            <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
          }
          showsVerticalScrollIndicator={false}
        />
      </View>
      {/* Incident Details Modal */}
      <IncidentDetailsComponent
        styles={styles}
        newStatus={newStatus}
        saveStatus={saveStatus}
        setNewStatus={setNewStatus}
        validateRole={validateRole}
        statusOptions={statusOptions}
        editingStatus={editingStatus}
        validateStatus={validateStatus}
        selectedIncident={selectedIncident}
        startEditingStatus={startEditingStatus}
        closeIncidentDetails={closeIncidentDetails}
      />
      {/* Modal for adding new incident */}
      <IncidentAddComponent
        errors={errors}
        styles={styles}
        newIncident={newIncident}
        sensorOptions={sensorOptions}
        statusOptions={statusOptions}
        setNewIncident={setNewIncident}
        locationOptions={locationOptions}
        isAddingNewIncident={isAddingNewIncident}
        closeAddNewIncident={closeAddNewIncident}
        handleAddNewIncident={handleAddNewIncident}
      />
      {/* Delete Confirmation Dialog box */}
      <FwDialog
        visible={deleteConfirmationVisible}
        hideDialog={hideDeleteConfirmation}
        title={LanguageString('Delete this Incident?')}>
        <FwButtonPrimary mode="outlined" onPress={hideDeleteConfirmation}>
          <FwTextPrimary>{LanguageString('Cancel')}</FwTextPrimary>
        </FwButtonPrimary>
        <FwButtonPrimary mode="outlined" onPress={handleDeleteIncident}>
          <FwTextPrimary>{LanguageString('Delete')}</FwTextPrimary>
        </FwButtonPrimary>
      </FwDialog>
    </>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: normalized(1),
    padding: normalized(16),
    backgroundColor: COLORS.OFF_WHITE,
  },
  title: {
    fontSize: normalized(24),
    fontWeight: 'bold',
    marginBottom: normalized(16),
    color: COLORS.BLACK,
  },
  subtitle: {
    fontSize: normalized(18),
    marginBottom: normalized(16),
    color: COLORS.BLACK,
  },
  incidentCard: {
    marginBottom: normalized(16),
    elevation: 2,
    backgroundColor: COLORS.BG_WHITE,
  },
  cardText: {
    color: COLORS.BLACK,
  },
  cardContent: {
    marginLeft: normalized(58),
    marginTop: normalized(-16),
  },
  modalContainer: {
    backgroundColor: 'white',
    padding: normalized(24),
    margin: normalized(24),
    borderRadius: normalized(8),
    elevation: normalized(4),
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: normalized(24),
  },
  modalTitle: {
    fontSize: normalized(20),
    fontWeight: 'bold',
    color: COLORS.BLACK,
  },

  modalContent: {
    color: COLORS.BLACK,
    lineHeight: normalized(30),
  },
  statusInput: {
    backgroundColor: COLORS.SECONDARY,
    padding: normalized(8),
    borderRadius: normalized(4),
  },

  dropdownContainer: {
    marginTop: normalized(16),
    marginLeft: normalized(20),
  },
  input: {
    marginBottom: normalized(8),
  },
  cardActions: {
    flexDirection: 'row',
  },
  cardIcon: {
    fontSize: normalized(30),
    marginTop: normalized(60),
    paddingRight: normalized(20),
  },
});
export default IncidentScreenView;
