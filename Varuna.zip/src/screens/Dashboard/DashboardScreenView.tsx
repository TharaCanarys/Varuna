import React, {useState, useEffect} from 'react';

import {FlatList, StyleSheet, Platform, RefreshControl} from 'react-native';
import {List as PaperList} from 'react-native-paper';

import {COLORS} from '../../constants/colors';
import {LanguageString} from '../../constants/data';
import Loader from '../../components/loader';
import {
  AssetsList,
  Drains,
  PumpsList,
  Weather,
  WaterLevel,
  SensorStatus,
  SummaryMetrics,
  TaskSummary,
  TicketsSummary,
} from '../../components';
import PumpingStation from '../../components/DashboardComponents/PumpingStations';
import {normalized} from '../../constants/platform';
import {RootState} from '../../store/store';
import {useSelector} from 'react-redux';
import FwImage from '../../elements/FwImage';
import PageHeader from '../../components/PageHeader';
import { PAGES } from '../../components/pages';

// Dummy JSON Data

const renderIcon = (icon: any, color: string) => (
  <FwImage
    source={icon}
    style={{
      width: 36,
      height: 36,
      tintColor: color,
      ...(Platform.OS === 'ios' ? {resizeMode: 'contain'} : {}),
    }}
  />
);

const DashboardScreenView = ({isLoading}: {isLoading: boolean}) => {
  const data = useSelector((state: RootState) => state.app.dashboardData);
  const [expandedAccordion, setExpandedAccordion] = useState('summaryMetrics');
  const [refreshing, setRefreshing] = useState(false);
  const handleAccordionPress = (accordionId: React.SetStateAction<string>) => {
    setExpandedAccordion(expandedAccordion === accordionId ? '' : accordionId);
  };

  const onRefresh = React.useCallback(() => {
    setRefreshing(true);

    setRefreshing(false);
  }, []);

  if (data == null || isLoading) {
    return <Loader />;
  }
  const sections = [
    {
      id: 'summaryMetrics',
      title: 'SummaryMetrics',
      render: () => <SummaryMetrics data={data?.data} renderIcon={renderIcon} />,
    },
    // {
    //   id: 'rainfall',
    //   title: 'Weather Forecast & Nowcast',
    //   render: () => <Weather />,
    // },
    {
      id: 'riskZones',
      title: 'Water Level',
      render: () => <WaterLevel data={data?.data?.dashboardDataCount} />,
    },
    
    // {
    //   id: 'sensorStatus',
    //   title: 'SensorStatus',
    //   render: () => <SensorStatus data={data?.data} />,
    // },
    
    
    {
      id: 'tasksSummary',
      title: 'TaskSummary',
      render: () => <TaskSummary data={data?.data?.dashboardDataCount} />,
    },
    {
      id: 'pumpsList',
      title: 'PumpList',
      render: () => <PumpsList data={data?.data?.dashboardDataCount} renderIcon={renderIcon} />,
    },
    {
      id: 'drains',
      title: 'Nala Types',
      render: () => <Drains data={data?.data?.dashboardDataCount} renderIcon={renderIcon} />,
    },
    {
      id: 'pumpingStation',
      title: 'PumpingStation',
      render: () => <PumpingStation data={data?.data?.dashboardDataCount} renderIcon={renderIcon} />,
    },
    // {
    //   id: 'ticketsSummary',
    //   title: 'Tickets Summary',
    //   render: () => <TicketsSummary data={data?.data} />,
    // },
    {
      id: 'assetsList',
      title: 'AssetsList',
      render: () => <AssetsList data={data?.data?.dashboardDataCount} />,
    },
  ];

  const renderItem = ({item}: {item: any}) => (
    <PaperList.Accordion
      title={LanguageString(item.title)}
      style={{backgroundColor: COLORS.TRANSPARENT,height: normalized(60)}}
      expanded={expandedAccordion === item.id}
      onPress={() => handleAccordionPress(item.id)}>
      {item.render()}
    </PaperList.Accordion>
  );

  return (
    <>
    <PageHeader title={PAGES.DASHBOARD} />
    <FlatList
      data={sections}
      renderItem={renderItem}
      keyExtractor={item => item.id}
      style={styles.container}
      refreshControl={
        <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
      }
    />
    </>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: normalized(16),
    marginTop: normalized(-10),
  },
});

export default DashboardScreenView;
