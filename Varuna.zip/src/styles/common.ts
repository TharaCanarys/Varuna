import { StyleSheet } from 'react-native';

export const commonStyle = StyleSheet.create({
  modalRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 8,
  },
  boldText: {
    fontWeight: 'bold',
  },
  normalText: {
    flex: 1,
  },
});
