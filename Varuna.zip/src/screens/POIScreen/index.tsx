import React, {useCallback, useState, useEffect} from 'react';
import {POIPropTypes} from '../../types/commonTypes';
import {
  poiData,
  LanguageString,
} from '../../constants/data';
import POIScreenView from './POIScreenView';
import {useSelector} from 'react-redux';
import {RootState} from '../../store/store';
import {getPoiData} from '../../services/apiServices';

const POIScreen: React.FC = () => {
  const [selectedPOI, setSelectedPOI] = useState<POIPropTypes | null>(null);
  const [editingStatus, setEditingStatus] = useState(false);
  const [isLoading, setLoading] = useState(false);
  const [newStatus, setNewStatus] = useState('');
  const [statusError, setStatusError] = useState('');
  const [pois, setPOIs] = useState<POIPropTypes[]>();
  const [isAddingNewPOI, setIsAddingNewPOI] = useState(false);
  const language = useSelector(
    (state: RootState) => state.app.selectedLanguage,
  );
  // Testing Translate Sample Demo
  const testTranslation = async () => {
    // console.log('Value Recieved', poiData);
    // const updatedPOIData = poiData.map(async (data: POIPropTypes) => {
    //   const nameTranslated = await translate(data.poiName, {
    //     from: 'en',
    //     to: 'hi',
    //     autoCorrect: true,
    //   });
    //   if (data.poiName) {
    //     data.poiName = nameTranslated.text;
    //     return {
    //       ...data,
    //     };
    //   }
    //   return data;
    // });
  };
  // useEffect(() => {
  //   // testTranslation();
  // }, [poiData]);
  // const SetPOIData = () => {};
  const [newPOI, setNewPOI] = useState<POIPropTypes>({
    id: 0,
    location: '',
    poiName: '',
    //poiType: '',
    elevation: '',
    network: '',
    poiStatus: '',
    floodRiskLevel: '',
    adjescentPois: '',
  });
  const [errors, setErrors] = useState({
    location: '',
    poiName: '',
    //poiType: '',
    elevation: '',
    network: '',
    poiStatus: '',
    floodRiskLevel: '',
    adjescentPois: '',
  });
  const [refreshing, setRefreshing] = useState(false);

  const initialNewPOIState = {
    id: 0,
    location: '',
    poiName: '',
    //poiType: '',
    elevation: '',
    network: '',
    poiStatus: '',
    floodRiskLevel: '',
    adjescentPois: '',
  };

  // Simulate data refresh
  useEffect(() => {
    onRefresh();
    setPOIs([...poiData]);
    // getPOI();
  }, [language]);
  const onRefresh = useCallback(() => {
    setRefreshing(true);
    setTimeout(() => {
      setPOIs([...poiData]);
      setRefreshing(false);
    }, 1000);
    // getPOI();
  }, []);

  const onGetSuccess = (data: POIPropTypes[]) => {
    console.log('Data Recieved in get', data);
    setPOIs(data);
  };
  const onGetFailed = (error: any) => {
    console.log('Error Recieved in get', error);
  };

  const getPOI = () => {
    let payload = [0];
    getPoiData(payload, setLoading, onGetSuccess, onGetFailed);
  };
  // Open poi details modal
  const openPOIDetails = useCallback((poi: POIPropTypes) => {
    setSelectedPOI(poi);
    setNewStatus(poi.poiStatus);
  }, []);

  // Close poi details modal
  const closePOIDetails = useCallback(() => {
    setSelectedPOI(null);
    setEditingStatus(false);
  }, []);

  // Toggle status editing
  const startEditingStatus = useCallback(() => {
    setEditingStatus(prev => !prev);
  }, []);

  // Save updated poi status
  const saveStatus = useCallback(() => {
    if (selectedPOI) {
      setPOIs(prevPOIs =>
        prevPOIs?.map(poi =>
          poi.id === selectedPOI.id ? {...poi, poiStatus: newStatus} : poi,
        ),
      );
      setSelectedPOI(prev => ({...prev!, poiStatus: newStatus}));
      setEditingStatus(false);
    }
  }, [selectedPOI, newStatus]);

  // Validate status input
  const validateStatus = useCallback((status: string) => {
    if (!status) {
      setStatusError(LanguageString('Status') + LanguageString(' is required'));
    } else {
      setStatusError('');
    }
  }, []);

  // Open add new poi modal
  const openAddNewPOI = useCallback(() => {
    setIsAddingNewPOI(true);
  }, []);

  // Close add new poi modal
  const closeAddNewPOI = useCallback(() => {
    setIsAddingNewPOI(false);
    setNewPOI(initialNewPOIState);
    setErrors({
      location: '',
      poiName: '',
      //poiType: '',
      elevation: '',
      network: '',
      poiStatus: '',
      floodRiskLevel: '',
      adjescentPois: '',
    });
  }, []);

  // Validate new poi input
  const validateNewPOI = useCallback(() => {
    let isValid = true;
    const newErrors = {
      location: '',
      poiName: '',
      //poiType: '',
      elevation: '',
      network: '',
      poiStatus: '',
      floodRiskLevel: '',
      adjescentPois: '',
    };

    if (!newPOI.poiStatus) {
      newErrors.poiStatus =
        LanguageString('Status') + ' ' + LanguageString('is required');
      isValid = false;
    }

    if (!newPOI.location) {
      newErrors.location =
        LanguageString('Location') + ' ' + LanguageString('is required');
      isValid = false;
    }
    if (!newPOI.poiName) {
      newErrors.poiName =
        LanguageString('Name') + ' ' + LanguageString('is required');
      isValid = false;
    }
    // if (!newPOI.poiType) {
    //   newErrors.poiType =
    //     LanguageString('Type') + LanguageString('is required');
    //   isValid = false;
    // }
    if (!newPOI.elevation) {
      newErrors.elevation =
        LanguageString('Elevation') + ' ' + LanguageString('is required');
      isValid = false;
    }
    if (!newPOI.network) {
      newErrors.network =
        LanguageString('Network') + ' ' + LanguageString('is required');
      isValid = false;
    }
    if (!newPOI.floodRiskLevel) {
      newErrors.floodRiskLevel =
        LanguageString('Flood Risk Level') +
        ' ' +
        LanguageString('is required');
      isValid = false;
    }
    if (!newPOI.adjescentPois) {
      newErrors.adjescentPois =
        LanguageString('Adjescent') +
        ' ' +
        LanguageString('POI') +
        ' ' +
        LanguageString('is required');
      isValid = false;
    }

    setErrors(newErrors);
    return isValid;
  }, [newPOI]);

  // Add new poi
  const handleAddNewPOI = useCallback(() => {
    if (validateNewPOI()) {
      setPOIs(prevPOIs => {
        if (!prevPOIs) return [newPOI];
        const newId = Math.max(...prevPOIs.map(s => s.id), 0) + 1;
        const poiToAdd = {...newPOI, id: newId};
        return [...prevPOIs, poiToAdd];
      });
      closeAddNewPOI();
    }
  }, [newPOI, validateNewPOI, closeAddNewPOI]);

  // Delete poi
  const handleDeletePOI = useCallback((poi: POIPropTypes) => {
    setPOIs(prevPOIs => prevPOIs?.filter(s => s.id !== poi.id));
  }, []);

  const poiScreenViewProps = {
    selectedPOI,
    editingStatus,
    newStatus,
    pois,
    isAddingNewPOI,
    setIsAddingNewPOI,
    newPOI,
    setNewPOI,
    setNewStatus,
    errors,
    refreshing,
    onRefresh,
    openPOIDetails,
    closePOIDetails,
    startEditingStatus,
    saveStatus,
    validateStatus,
    openAddNewPOI,
    closeAddNewPOI,
    handleAddNewPOI,
    handleDeletePOI,
    language,
    isLoading,
  };

  return <POIScreenView {...poiScreenViewProps} />;
};
export default POIScreen;
