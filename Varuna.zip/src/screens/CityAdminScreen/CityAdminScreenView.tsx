import React, {useCallback, useMemo} from 'react';
import {
  View,
  StyleSheet,
  RefreshControl,
  FlatList,
  ScrollView,
} from 'react-native';
import {Card, HelperText} from 'react-native-paper';

import {
  FwButtonPrimary,
  FwDialog,
  FwTextInputPrimary,
  FwTextPrimary,
  FwTextSecondary,
} from '../../elements';
import {CityAdminScreenProps} from '../../types/commonTypes';
import {LanguageString, USER_ROLES} from '../../constants/data';
import {COLORS} from '../../constants/colors';
import FWDropdown from '../../elements/FwDropdown';
import {IMAGES} from '../../assets';
import PageHeader from '../../components/PageHeader';
import {useSelector} from 'react-redux';
import {RootState} from '../../store/store';
import {commonStyle} from '../../constants/theme';
import {normalized} from '../../constants/platform';
import FwImage from '../../elements/FwImage';
import FwModal from '../../elements/FwModal';
// Main component for the CityAdmin Screen
const CityAdminScreenView = ({
  selectedCityAdmin,
  refreshing,
  cityAdmins,
  newStatus,
  setNewStatus,
  editingStatus,
  isAddingNewCityAdmin,
  newCityAdmin,
  setNewCityAdmin,
  errors,
  openCityAdminDetails,
  onRefresh,
  startEditingStatus,
  handleDeleteCityAdmin,
  openAddNewCityAdmin,
  closeCityAdminDetails,
  validateStatus,
  saveStatus,
  closeAddNewCityAdmin,
  handleAddNewCityAdmin,
}: CityAdminScreenProps) => {
  // State for delete confirmation dialog
  const [showDeleteDialog, setShowDeleteDialog] = React.useState(false);
  const [cityAdminToDelete, setCityAdminToDelete] = React.useState(null);

  const keyFacilityOptions = [
    {label: LanguageString('Hospital'), value: 'Hospital'},
    {label: LanguageString('School'), value: 'School'},
    {label: LanguageString('Police Station'), value: 'Police Station'},
    {label: LanguageString('Government Office'), value: 'Government Office'},
  ];
  const cityAdminTypeOptions = [
    {label: LanguageString('Preventive'), value: 'Preventive'},
    {label: LanguageString('Corrective'), value: 'Corrective'},
    {label: LanguageString('Predictive'), value: 'Predictive'},
  ];
  const floodRiskLevelOptions = [
    {label: LanguageString('Low'), value: 'Low'},
    {label: LanguageString('Medium'), value: 'Medium'},
    {label: LanguageString('High'), value: 'High'},
    {label: LanguageString('Critical'), value: 'Critical'},
  ];
  const cityAdminNameOptions = [
    {label: LanguageString('Downtown'), value: 'Downtown'},
    {label: LanguageString('Suburb'), value: 'Suburb'},
    {label: LanguageString('Rural'), value: 'Rural'},
    {label: LanguageString('Urban'), value: 'Urban'},
  ];
  const emergencyServiceOptions = [
    {label: LanguageString('Ambulance'), value: 'Ambulance'},
    {label: LanguageString('Fire Brigade'), value: 'Fire Brigade'},
    {label: LanguageString('Police Station'), value: 'Police Station'},
  ];
  const locationOptions = [
    {label: LanguageString('Rapti Nagar'), value: 'Rapti Nagar'},
    {label: LanguageString('Om Nagar'), value: 'Om Nagar'},
    {label: LanguageString('Rasoolpur'), value: 'Rasoolpur'},
  ];
  const statusOptions = [
    {label: LanguageString('Active'), value: 'Active'},
    {label: LanguageString('Inactive'), value: 'Inactive'},
    {label: LanguageString('Maintenance'), value: 'Maintenance'},
  ];
  // Open delete confirmation dialog
  const openDeleteDialog = useCallback((cityAdmin: any) => {
    setCityAdminToDelete(cityAdmin);
    setShowDeleteDialog(true);
  }, []);

  // Close delete confirmation dialog
  const closeDeleteDialog = useCallback(() => {
    setShowDeleteDialog(false);
    setCityAdminToDelete(null);
  }, []);

  const role = useSelector((state: RootState) => state.auth.userRole);

  const validateRole =
    role == USER_ROLES.ADMIN ||
    role == USER_ROLES.SUPER_ADMIN ||
    role == USER_ROLES.IT_SUPPORT;
  // Confirm cityAdmin deletion
  const confirmDelete = useCallback(() => {
    console.log('Deleting cityAdmin:', cityAdminToDelete);
    if (cityAdminToDelete) {
      handleDeleteCityAdmin(cityAdminToDelete);
    }
    closeDeleteDialog();
  }, [cityAdminToDelete, handleDeleteCityAdmin, closeDeleteDialog]);

  // Render individual cityAdmin card
  const renderCityAdminCard = useCallback(
    (cityAdmin: any, index: number) => (
      <Card
        key={index}
        style={styles.cityAdminCard}
        onPress={() => openCityAdminDetails(cityAdmin)}>
        <Card.Title
          title={LanguageString(cityAdmin.cityAdminAreaName)}
          titleStyle={commonStyle.cardHeaderText}
          left={() => (
            <View style={styles.cardImage}>
              <FwImage source={IMAGES.CITYADMIN} style={styles.cardImageIcon} />
            </View>
          )}
        />
        <Card.Content style={styles.cardContent}>
          <View style={commonStyle.modalRow}>
            <FwTextPrimary style={commonStyle.boldText}>
              {LanguageString('Area Type') + ' : '}
            </FwTextPrimary>
            <FwTextPrimary style={commonStyle.normalText}>
              {LanguageString(cityAdmin.cityAdminAreaType)}
            </FwTextPrimary>
          </View>
          <View style={commonStyle.modalRow}>
            <FwTextPrimary style={commonStyle.boldText}>
              {LanguageString('Risk Level') + ' : '}
            </FwTextPrimary>
            <FwTextPrimary style={commonStyle.normalText}>
              {LanguageString(cityAdmin.floodRiskLevel)}
            </FwTextPrimary>
          </View>
          <View style={commonStyle.modalRow}>
            <FwTextPrimary style={commonStyle.boldText}>
              {LanguageString('Contact Person') + ' : '}
            </FwTextPrimary>
            <FwTextPrimary style={commonStyle.normalText}>
              {LanguageString(cityAdmin.contactPerson)}
            </FwTextPrimary>
          </View>
        </Card.Content>
      </Card>
    ),
    [openCityAdminDetails, startEditingStatus, openDeleteDialog],
  );

  // Render a message if no cityAdmins
  const cityAdminCards = useMemo(() => {
    if (cityAdmins.length === 0) {
      return (
        <FwTextPrimary style={styles.cityAdminCardText}>
          {LanguageString('No City Admin Area found')}
        </FwTextPrimary>
      );
    }
    return cityAdmins.map(renderCityAdminCard);
  }, [cityAdmins, renderCityAdminCard]);

  // Render cityAdmin details modal content
  const renderCityAdminDetails = useCallback(
    () => (
      <FlatList
        data={[
          {
            label: LanguageString('Area Name'),
            value: LanguageString(selectedCityAdmin?.cityAdminAreaName || ''),
          },
          {
            label: LanguageString('Admin Area Type'),
            value: LanguageString(selectedCityAdmin?.cityAdminAreaType || ''),
          },
          {
            label: LanguageString('Location'),
            value: LanguageString(selectedCityAdmin?.location || ''),
          },
          {
            label: LanguageString('Population'),
            value: LanguageString(String(selectedCityAdmin?.population) || ''),
          },
          {
            label: LanguageString('Key Facilities'),
            value: LanguageString(selectedCityAdmin?.keyFacility || ''),
          },
          {
            label: LanguageString('Flood Risk Level'),
            value: LanguageString(selectedCityAdmin?.floodRiskLevel || ''),
          },
          {
            label: LanguageString('Contact Person'),
            value: LanguageString(selectedCityAdmin?.contactPerson || ''),
          },
          {
            label: LanguageString('Emergency Service'),
            value: LanguageString(selectedCityAdmin?.emergencyService || ''),
          },
          {
            label: LanguageString('Evolution Plan'),
            value: LanguageString(selectedCityAdmin?.evolutionPlan || ''),
          },
        ]}
        ListHeaderComponent={
          <View style={commonStyle.modalHeader}>
            <FwTextSecondary style={commonStyle.modalTitle}>
              {LanguageString('City Admin Area Details')}
            </FwTextSecondary>
          </View>
        }
        renderItem={({item}) => (
          <ScrollView>
            <View style={commonStyle.modalRow}>
              <FwTextPrimary style={commonStyle.boldText}>
                {item.label + ' '}:{' '}
              </FwTextPrimary>
              <FwTextPrimary style={commonStyle.normalText}>
                {item.value}
              </FwTextPrimary>
            </View>
          </ScrollView>
        )}
        ListFooterComponent={
          <>
            {editingStatus && (
              <FWDropdown
                multiple={false}
                label={'Select Status'}
                options={statusOptions}
                value={newStatus}
                onSelect={(value: string | undefined) => {
                  if (value !== undefined) {
                    setNewStatus(value);
                    validateStatus(value);
                  }
                }}
              />
            )}
            {editingStatus && (
              <FwButtonPrimary
                onPress={saveStatus}
                style={commonStyle.saveButton}>
                <FwTextSecondary>Save</FwTextSecondary>
              </FwButtonPrimary>
            )}
            <FwButtonPrimary
              onPress={closeCityAdminDetails}
              style={commonStyle.closeButton}>
              <FwTextSecondary>{LanguageString('Cancel')}</FwTextSecondary>
            </FwButtonPrimary>
          </>
        }
      />
    ),
    [
      selectedCityAdmin,
      editingStatus,
      newStatus,
      startEditingStatus,
      setNewStatus,
      validateStatus,
      saveStatus,
      closeCityAdminDetails,
    ],
  );

  // Render add new cityAdmin modal content
  const renderAddNewCityAdmin = useCallback(
    () => (
      <FlatList
        data={[
          {
            key: 'location',
            component: (
              <>
                <FWDropdown
                  multiple={false}
                  label={LanguageString('Select Location')}
                  options={locationOptions}
                  value={LanguageString(newCityAdmin?.location)}
                  onSelect={(value: string | undefined) => {
                    if (value !== undefined) {
                      setNewCityAdmin({...newCityAdmin, location: value});
                    }
                  }}
                />
                <HelperText type="error" visible={!!errors.location}>
                  {errors.location}
                </HelperText>
              </>
            ),
          },
          {
            key: 'cityAdminAreaName',
            component: (
              <>
                <FWDropdown
                  multiple={false}
                  label={LanguageString('Select City Admin Area Name')}
                  options={cityAdminNameOptions}
                  value={LanguageString(newCityAdmin?.cityAdminAreaName)}
                  onSelect={(value: string | undefined) => {
                    if (value !== undefined) {
                      setNewCityAdmin({
                        ...newCityAdmin,
                        cityAdminAreaName: value,
                      });
                    }
                  }}
                />
                <HelperText type="error" visible={!!errors.cityAdminAreaName}>
                  {errors.cityAdminAreaName}
                </HelperText>
              </>
            ),
          },
          {
            key: 'cityAdminAreaType',
            component: (
              <>
                <FWDropdown
                  multiple={false}
                  label={LanguageString('Select Admin Area Type')}
                  options={cityAdminTypeOptions}
                  value={newCityAdmin?.cityAdminAreaType}
                  onSelect={(value: string | undefined) => {
                    if (value !== undefined) {
                      setNewCityAdmin({
                        ...newCityAdmin,
                        cityAdminAreaType: value,
                      });
                    }
                  }}
                />
                <HelperText type="error" visible={!!errors.cityAdminAreaType}>
                  {errors.cityAdminAreaType}
                </HelperText>
              </>
            ),
          },
          {
            key: 'population',
            component: (
              <>
                <FwTextInputPrimary
                  label={LanguageString('Population')}
                  value={newCityAdmin?.population.toString()}
                  onChangeText={text =>
                    setNewCityAdmin({...newCityAdmin, population: Number(text)})
                  }
                  style={styles.input}
                  error={!!errors.population}
                  keyboardType="numeric"
                />
                <HelperText type="error" visible={!!errors.population}>
                  {errors.population}
                </HelperText>
              </>
            ),
          },
          {
            key: 'contactPerson',
            component: (
              <>
                <FwTextInputPrimary
                  label={LanguageString('Contact Person')}
                  value={newCityAdmin?.contactPerson}
                  onChangeText={text =>
                    setNewCityAdmin({...newCityAdmin, contactPerson: text})
                  }
                  style={styles.input}
                  error={!!errors.contactPerson}
                />
                <HelperText type="error" visible={!!errors.contactPerson}>
                  {errors.contactPerson}
                </HelperText>
              </>
            ),
          },
          {
            key: 'keyFacility',
            component: (
              <>
                <FWDropdown
                  multiple={true}
                  label={LanguageString('Select key Facilities')}
                  options={keyFacilityOptions}
                  value={newCityAdmin?.keyFacility}
                  onSelect={(value: string | undefined) => {
                    if (value !== undefined) {
                      setNewCityAdmin({...newCityAdmin, keyFacility: value});
                    }
                  }}
                />
                <HelperText type="error" visible={!!errors.keyFacility}>
                  {errors.keyFacility}
                </HelperText>
              </>
            ),
          },
          {
            key: 'floodRiskLevel',
            component: (
              <>
                <FWDropdown
                  multiple={false}
                  label={LanguageString('Select Flood Risk Level')}
                  options={floodRiskLevelOptions}
                  value={newCityAdmin?.floodRiskLevel}
                  onSelect={(value: string | undefined) => {
                    if (value !== undefined) {
                      setNewCityAdmin({...newCityAdmin, floodRiskLevel: value});
                    }
                  }}
                />
                <HelperText type="error" visible={!!errors.floodRiskLevel}>
                  {errors.floodRiskLevel}
                </HelperText>
              </>
            ),
          },
          {
            key: 'emergencyService',
            component: (
              <>
                <FWDropdown
                  multiple={true}
                  label={LanguageString('Select Emergency Services')}
                  options={emergencyServiceOptions}
                  value={newCityAdmin?.emergencyService}
                  onSelect={(value: string | undefined) => {
                    if (value !== undefined) {
                      setNewCityAdmin({
                        ...newCityAdmin,
                        emergencyService: value,
                      });
                    }
                  }}
                />
                <HelperText type="error" visible={!!errors.emergencyService}>
                  {errors.emergencyService}
                </HelperText>
              </>
            ),
          },
          {
            key: 'evolutionPlan',
            component: (
              <>
                <FwTextInputPrimary
                  label={LanguageString('Evolution Plan')}
                  value={newCityAdmin?.evolutionPlan}
                  onChangeText={text =>
                    setNewCityAdmin({...newCityAdmin, evolutionPlan: text})
                  }
                  style={styles.input}
                  error={!!errors.evolutionPlan}
                />
                <HelperText type="error" visible={!!errors.evolutionPlan}>
                  {errors.evolutionPlan}
                </HelperText>
              </>
            ),
          },
        ]}
        renderItem={({item}) => item.component}
        ListHeaderComponent={
          <View style={commonStyle.modalHeader}>
            <FwTextPrimary style={commonStyle.modalTitle}>
              {LanguageString('Add New City Admin Area')}
            </FwTextPrimary>
          </View>
        }
        ListFooterComponent={
          <>
            <FwButtonPrimary
              onPress={handleAddNewCityAdmin}
              style={commonStyle.saveButton}>
              <FwTextSecondary>{LanguageString('Save')}</FwTextSecondary>
            </FwButtonPrimary>
            <FwButtonPrimary
              onPress={closeAddNewCityAdmin}
              style={commonStyle.closeButton}>
              <FwTextSecondary>{LanguageString('Cancel')}</FwTextSecondary>
            </FwButtonPrimary>
          </>
        }
      />
    ),
    [
      newCityAdmin,
      errors,
      setNewCityAdmin,
      handleAddNewCityAdmin,
      closeAddNewCityAdmin,
    ],
  );

  // Main render function
  return (
    <>
      <PageHeader title="City Admin Area" />
      <FlatList
        style={styles.container}
        data={cityAdminCards as any[]}
        renderItem={({item}) => item}
        keyExtractor={(item, index) => index.toString()}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
        }
        // ListFooterComponent={
        //   <View style={styles.addButtonContainer}>
        //     {validateRole ? (
        //       <FwButtonPrimary
        //         mode="contained"
        //         onPress={openAddNewCityAdmin}
        //         icon="plus">
        //         <FwTextSecondary>{LanguageString('Add New')}</FwTextSecondary>
        //       </FwButtonPrimary>
        //     ) : null}
        //   </View>
        // }
      />
      {/* CityAdmin Details Modal */}
      <FwModal
        visible={selectedCityAdmin !== null}
        onDismiss={closeCityAdminDetails}
        contentContainerStyle={styles.modalContainer}>
        {selectedCityAdmin && renderCityAdminDetails()}
      </FwModal>
      {/* Add New CityAdmin Modal */}
      <FwModal
        visible={isAddingNewCityAdmin}
        onDismiss={closeAddNewCityAdmin}
        contentContainerStyle={styles.modalContainer}>
        {renderAddNewCityAdmin()}
      </FwModal>
      {/* Delete Confirmation Dialog */}
      <FwDialog
        visible={showDeleteDialog}
        hideDialog={closeDeleteDialog}
        title={'Delete City Admin'}>
        <FwButtonPrimary mode="outlined" onPress={closeDeleteDialog}>
          <FwTextPrimary>{LanguageString('Cancel')}</FwTextPrimary>
        </FwButtonPrimary>
        <FwButtonPrimary mode="outlined" onPress={confirmDelete}>
          <FwTextPrimary>{LanguageString('Delete')}</FwTextPrimary>
        </FwButtonPrimary>
      </FwDialog>
    </>
  );
};

// Styles for the component
const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: normalized(16),
    backgroundColor: COLORS.OFF_WHITE,
  },
  title: {
    fontSize: normalized(24),
    fontWeight: 'bold',
    marginBottom: normalized(16),
    color: COLORS.BLACK,
  },
  subtitle: {
    fontSize: normalized(18),
    marginBottom: normalized(16),
    color: COLORS.BLACK,
  },
  cityAdminCard: {
    marginBottom: normalized(16),
    elevation: 2,
    backgroundColor: COLORS.BG_WHITE,
  },
  cardText: {
    color: COLORS.BLACK,
  },
  addButtonContainer: {
    marginVertical: normalized(24),
    alignItems: 'center',
  },
  cardContent: {
    marginLeft: normalized(58),
    marginTop: normalized(-16),
  },
  modalContainer: {
    backgroundColor: COLORS.BG_WHITE,
    padding: normalized(24),
    margin: normalized(24),
    borderRadius: normalized(8),
    elevation: normalized(4),
    height: '60%',
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: normalized(24),
  },

  modalContent: {
    color: COLORS.BLACK,
    lineHeight: normalized(27),
  },

  dropdownContainer: {
    marginTop: normalized(16),
    marginLeft: normalized(20),
  },
  input: {
    marginBottom: normalized(8),
  },
  cardActions: {
    flexDirection: 'row',
  },
  cardImage: {
    width: normalized(50),
    height: normalized(50),
    borderRadius: normalized(50),
    marginRight: normalized(16),
    marginTop: normalized(50),
  },
  cardImageIcon: {
    width: normalized(50),
    height: normalized(50),
    borderRadius: normalized(50),
    marginRight: normalized(16),
    marginTop: normalized(30),
  },
  appBar: {
    marginTop: '20%',
  },
  noCityAdminsText: {
    textAlign: 'center',
    marginTop: normalized(20),
    fontSize: normalized(16),
    color: COLORS.BLACK,
  },
  cityAdminCardContent: {
    marginLeft: normalized(58),
    marginTop: normalized(-16),
  },
  cityAdminCardText: {
    color: COLORS.BLACK,
  },
  intenanceCardActions: {
    flexDirection: 'row',
  },
  cityAdminCardActionsButton: {
    margin: normalized(8),
  },
  intenanceCardActionsButtonText: {
    color: COLORS.BLACK,
  },
  cityAdminCardActionsButtonText: {
    color: COLORS.BLACK,
  },
});

export default CityAdminScreenView;
