import React from 'react';
import {View, StyleSheet, ScrollView} from 'react-native';
import FwModal from '../../elements/FwModal';
import {commonStyle} from '../../constants/theme';
import {FwButtonPrimary, FwTextPrimary, FwTextSecondary} from '../../elements';
import {LanguageString} from '../../constants/data';
import FWDropdown from '../../elements/FwDropdown';
import {HelperText} from 'react-native-paper';

const IncidentAddComponent = ({
  errors,
  styles,
  newIncident,
  sensorOptions,
  statusOptions,
  setNewIncident,
  locationOptions,
  isAddingNewIncident,
  closeAddNewIncident,
  handleAddNewIncident,
}: any) => {
  return (
    <FwModal
      visible={isAddingNewIncident}
      onDismiss={closeAddNewIncident}
      contentContainerStyle={styles.modalContainer}>
      <View style={commonStyle.modalHeader}>
        <FwTextPrimary style={commonStyle.modalTitle}>
          {LanguageString('Add New Incident')}
        </FwTextPrimary>
      </View>
      <FWDropdown
        multiple={false}
        label={LanguageString('Select Alert Name')}
        options={sensorOptions}
        value={LanguageString(newIncident.alertName)}
        onSelect={(value: string | undefined) => {
          if (value !== undefined) {
            setNewIncident({...newIncident, alertName: value});
          }
        }}
      />

      <HelperText type="error" visible={!!errors.alertName}>
        {errors.alertName}
      </HelperText>
      <FWDropdown
        multiple={false}
        label={LanguageString('Select Location')}
        options={locationOptions}
        value={newIncident.location}
        onSelect={(value: string | undefined) => {
          if (value !== undefined) {
            setNewIncident({...newIncident, location: value});
          }
        }}
      />
      <HelperText type="error" visible={!!errors.location}>
        {errors.location}
      </HelperText>

      {/* <DateTimePickerModal
          isVisible={isDatePickerVisible}
          mode="datetime"
          onConfirm={handleConfirm}
          onCancel={hideDatePicker}
        /> */}
      <FWDropdown
        multiple={false}
        label={LanguageString('Select Status')}
        options={statusOptions}
        value={newIncident.status}
        onSelect={(value: string | undefined) => {
          if (value !== undefined) {
            setNewIncident({...newIncident, status: value});
          }
        }}
      />
      <HelperText type="error" visible={!!errors.status}>
        {errors.status}
      </HelperText>
      <FwButtonPrimary
        onPress={handleAddNewIncident}
        style={commonStyle.saveButton}>
        <FwTextSecondary>{LanguageString('Save')}</FwTextSecondary>
      </FwButtonPrimary>
      <FwButtonPrimary
        onPress={closeAddNewIncident}
        style={commonStyle.closeButton}>
        <FwTextSecondary>{LanguageString('Cancel')}</FwTextSecondary>
      </FwButtonPrimary>
    </FwModal>
  );
};

export default IncidentAddComponent;
