import React from 'react';
import {
  FwButtonPrimary,
  FwButtonSecondary,
  FwTextInputPrimary,
  FwTextPrimary,
  FwTextSecondary,
} from '../../elements';
import {TouchableOpacity, View} from 'react-native';
import {LanguageString} from '../../constants/data';

const RenderOtpVerification = ({
  updateFormState,
  validateOTP,
  errorState,
  formState,
  uiState,
  handleResendOTP,
  styles,
  handleVerifyOTP,
  closeOtpModal,
}: any) => {
  return (
    <>
      <FwTextPrimary type="title_2" style={styles.modalTitle}>
        {LanguageString('Enter OTP')}
      </FwTextPrimary>
      <FwTextInputPrimary
        label="OTP"
        value={formState.otp}
        onChangeText={(text: string) => {
          updateFormState('otp', text);
          validateOTP(text);
        }}
        style={styles.input}
        keyboardType="numeric"
        maxLength={6}
        error={!!errorState.otpError}
      />
      {errorState.otpError ? (
        <FwTextPrimary style={styles.errorText}>
          {errorState.otpError}
        </FwTextPrimary>
      ) : null}
      {/* Timer and resend OTP option */}
      <View style={styles.timerContainer}>
        {uiState.timer > 0 ? (
          <FwTextPrimary style={styles.timerText}>
            00:{uiState.timer < 10 ? `0${uiState.timer}` : uiState.timer}
          </FwTextPrimary>
        ) : null}
        {uiState.timer === 0 && (
          <TouchableOpacity onPress={handleResendOTP}>
            <FwTextPrimary style={styles.resendLink}>
              {LanguageString('Resend OTP')}
            </FwTextPrimary>
          </TouchableOpacity>
        )}
      </View>
      <FwButtonPrimary
        disabled={formState.otp.length !== 6}
        mode="contained"
        style={styles.modalButton}
        onPress={handleVerifyOTP}>
        <FwTextSecondary type="buttonText">
          {LanguageString('Verify OTP')}
        </FwTextSecondary>
      </FwButtonPrimary>
      <FwButtonSecondary
        mode="outlined"
        style={styles.modalButton}
        onPress={closeOtpModal}>
        <FwTextPrimary type="buttonText">
          {LanguageString('Cancel')}
        </FwTextPrimary>
      </FwButtonSecondary>
    </>
  );
};

export default RenderOtpVerification;
