
// Define the Incident interface
export interface IncidentTypes {
  incidentID: string;
  id: number;
  alertName: string;
  reportedBy: string;
  reportedTime: string;
  location: string;
  resulationTime: string;
  status: string;
}

export interface IncidentErrorTypes {
  alertName: string;
  reportedBy: string;
  reportedTime: string;
  location: string;
  resulationTime: string;
  status: string;
}

export interface IncidentScreenViewProps {
  newIncident: IncidentTypes;
  setNewIncident: React.Dispatch<React.SetStateAction<IncidentTypes>>;
  editingStatus: boolean;
  setEditingStatus: (show: boolean) => void;
  selectedIncident: IncidentTypes | null;
  startEditingStatus: () => void;

  newStatus: string;
  setNewStatus: React.Dispatch<React.SetStateAction<string>>;
  openIncidentDetails: (incident: IncidentTypes) => void;
  closeIncidentDetails: () => void;
  incidents: IncidentTypes[];
  setIncidents: React.Dispatch<React.SetStateAction<IncidentTypes[]>>;
  saveStatus: () => void;
  refreshing: boolean;
  setRefreshing: React.Dispatch<React.SetStateAction<boolean>>;
  validateStatus: (status: string) => void;
  openAddNewIncident: () => void;
  closeAddNewIncident: () => void;
  isAddingNewIncident: boolean;
  errors: IncidentErrorTypes;
  setErrors: React.Dispatch<React.SetStateAction<IncidentErrorTypes>>;
  setDatePickerVisibility: (show: boolean) => void;
  isDatePickerVisible: boolean;

}

// Define the Incident interface
export const incidentData: IncidentTypes[] = [
  {
    id: 1,
    alertName: 'Alerts',
    reportedBy: 'Admin',
    reportedTime: '2023-09-15 08:30',
    location: 'Golghar',
    resulationTime: '12/4/2024 11:16:21 AM',
    status: 'Resolved',
  },
  {
    id: 2,
    alertName: 'Alerts',
    reportedBy: 'Admin',
    reportedTime: '2024-05-15 12:00',
    location: 'Gorakhnath',
    resulationTime: '0',
    status: 'Reported',
  },
  {
    id: 3,
    alertName: 'Alerts',
    reportedBy: 'Admin',
    reportedTime: '2023-05-15 10:30',
    location: 'Shahpur',
    resulationTime: '0',
    status: 'Reported',
  },
];
