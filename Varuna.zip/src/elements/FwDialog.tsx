import React from 'react';
import {Dialog, Portal} from 'react-native-paper';
import {FwDialogProps} from '../types/commonTypes';
import FwTextPrimary from './FwTextPrimary';
import {normalized} from '../constants/platform';
import {LanguageString} from '../constants/data';

export default function FwDialog({
  children,
  title,
  description,
  visible,
  hideDialog,
  ...rest
}: FwDialogProps) {
  return (
    <Portal>
      <Dialog
        visible={visible}
        onDismiss={hideDialog}
        {...rest}
        theme={{
          animation: {
            scale: 1,
            defaultAnimationDuration: 200,
          },
        }}>
        <Dialog.Title style={{fontSize: normalized(20)}}>
          {LanguageString(title)}
        </Dialog.Title>
        {description && (
          <Dialog.Content>
            <FwTextPrimary>{description}</FwTextPrimary>
          </Dialog.Content>
        )}
        <Dialog.Actions>{children}</Dialog.Actions>
      </Dialog>
    </Portal>
  );
}
