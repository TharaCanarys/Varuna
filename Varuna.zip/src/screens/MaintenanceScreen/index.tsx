// Import necessary dependencies and types
import React, {useCallback, useState, useMemo, useEffect} from 'react';
import MaintenanceScreenView from './MaintenanceScreenView';
import {MaintenancePropTypes} from '../../types/commonTypes';
import {User} from '../../types/userTypes';
import {LanguageString, maintenanceData} from '../../constants/data';
import {useDispatch, useSelector} from 'react-redux';
import {RootState} from '../../store/store';
import {getAllUsers, getMaintenanceData} from '../../services/apiServices';
import {getToken} from '../../services/authService';
import {
  setNotificationVisible,
  setSnackMessage,
  setUsers,
} from '../../store/appSlice';
import {AppState} from '../../store/appSlice';
import {logout} from '../../utils/navigation';
import {useNavigation} from '@react-navigation/native';

const MaintenanceScreen: React.FC = () => {
  // State variables for managing maintenance data and UI
  const [selectedMaintenance, setSelectedMaintenance] =
    useState<MaintenancePropTypes | null>(null);
  const [editingStatus, setEditingStatus] = useState(false);
  const [newStatus, setNewStatus] = useState('');
  const [statusError, setStatusError] = useState('');
  const [description, setDescription] = useState<string>('');
  const [remarks, setRemarks] = useState('');
  const dispatch = useDispatch();
  const [maintenances, setMaintenances] = useState<MaintenancePropTypes[]>();
  const [isAddingNewMaintenance, setIsAddingNewMaintenance] = useState(false);
  const [showDatePicker, setShowDatePicker] = useState(false);
  const [refreshing, setRefreshing] = useState(false);

  // Initial state for new maintenance entry
  const initialNewMaintenanceState = useMemo(
    () => ({
      id: 0,
      status: '',
      location: '',
      maintenanceType: '',
      description: '',
      scheduledDate: '',
      dueDate: '',
      completedDate: '',
      Technician: '',
      Remarks: '',
      assetsType: '',
    }),
    [],
  );

  const [newMaintenance, setNewMaintenance] = useState<MaintenancePropTypes>(
    initialNewMaintenanceState,
  );

  const onGetSuccess = (data: MaintenancePropTypes[]) => {
    setMaintenances(data);
    fetchUsers();
    // dispatch(setNotificationVisible(true));
    // dispatch(setSnackMessage('Maintenance data fetched successfully'));
  };
  const navigation = useNavigation();
  const fetchUsers = async (): Promise<void> => {
    try {
      const response = await getAllUsers();
      if (response?.data) {
        dispatch(setUsers(response.data as User[]));
      }
    } catch (error: unknown) {
      console.error('Error fetching users:', error);
    }
  };

  const onGetFailed = useCallback((error: any) => {
    // dispatch(setNotificationVisible(true));
    // dispatch(setSnackMessage(error.message));
    console.log('Failed to get maintenance data', error.message);
    if (error.message === 'Unauthorized: No user id found.') {
      logout(navigation as any);
    }

  }, []);

  useEffect(() => {
    getMaintenance();
  }, []);

  const getMaintenance = async () => {
    let payload = [0];
    getMaintenanceData(payload, onGetSuccess, onGetFailed);
  };

  // State for form validation errors
  const [errors, setErrors] = useState({
    status: '',
    location: '',
    maintenanceType: '',
    description: '',
    scheduledDate: '',
    dueDate: '',
    completedDate: '',
    Technician: '',
    Remarks: '',
    assetsType: '',
  });
  const language = useSelector(
    (state: RootState) => state.app.selectedLanguage,
  );
  // Refresh function to reload maintenance data
  const onRefresh = useCallback(() => {
    setRefreshing(true);
    getMaintenance();
    setTimeout(() => {
      setRefreshing(false);
    }, 1000);
  }, [language]);

  // Function to open maintenance details modal
  const openMaintenanceDetails = useCallback(
    (maintenance: MaintenancePropTypes) => {
      setSelectedMaintenance(maintenance);
      // setNewStatus(maintenance?.status);
    },
    [],
  );

  // Function to close maintenance details modal
  const closeMaintenanceDetails = useCallback(() => {
    setSelectedMaintenance(null);
    setEditingStatus(false);
  }, []);

  // Toggle editing status
  const startEditingStatus = useCallback(
    () => setEditingStatus(prev => !prev),
    [],
  );

  // Save updated status
  const saveStatus = useCallback(() => {
    if (selectedMaintenance) {
      // setMaintenances(prevMaintenances =>
      //   prevMaintenances.map(maintenance =>
      //     maintenance.id === selectedMaintenance.id
      //       ? {...maintenance, status: newStatus}
      //       : maintenance,
      //   ),
      // );
      setSelectedMaintenance(prev => ({...prev!, status: newStatus}));
      setEditingStatus(false);
    }
  }, [selectedMaintenance, newStatus]);

  // Validate status input
  const validateStatus = useCallback((status: string) => {
    setStatusError(
      status
        ? ''
        : LanguageString('Status') + ' ' + LanguageString('is required'),
    );
  }, []);

  // Open add new maintenance form
  const openAddNewMaintenance = useCallback(() => {
    setIsAddingNewMaintenance(true);
    const currentIndianDate = new Date(
      new Date().getTime() + 5.5 * 60 * 60 * 1000,
    );
    setNewMaintenance(prev => ({
      ...prev,
      scheduledDate: currentIndianDate
        .toISOString()
        .slice(0, 19)
        .replace('T', ' '),
    }));
  }, []);

  // Close add new maintenance form
  const closeAddNewMaintenance = useCallback(() => {
    setIsAddingNewMaintenance(false);
    setNewMaintenance(prev => ({...prev, ...initialNewMaintenanceState}));
    setErrors({
      status: '',
      location: '',
      maintenanceType: '',
      description: '',
      scheduledDate: '',
      dueDate: '',
      completedDate: '',
      Technician: '',
      Remarks: '',
      assetsType: '',
    });
  }, [initialNewMaintenanceState]);
  // Validate new maintenance form
  const validateNewMaintenance = useCallback(() => {
    const newErrors = {
      status: '',
      location: '',
      maintenanceType: '',
      description: '',
      scheduledDate: '',
      dueDate: '',
      completedDate: '',
      Technician: '',
      Remarks: '',
      assetsType: '',
    };

    let isValid = true;

    if (!newMaintenance.status) {
      newErrors.status =
        LanguageString('Status') + ' ' + LanguageString('is required');
      isValid = false;
    }
    if (!newMaintenance.location) {
      newErrors.location =
        LanguageString('Location') + ' ' + LanguageString('is required');
      isValid = false;
    }
    if (!newMaintenance.maintenanceType) {
      newErrors.maintenanceType =
        LanguageString('Maintenance Type') +
        ' ' +
        LanguageString('is required');
      isValid = false;
    }
    if (!newMaintenance.description) {
      newErrors.description =
        LanguageString('Description') + ' ' + LanguageString('is required');
      isValid = false;
    }
    if (!newMaintenance.dueDate) {
      newErrors.dueDate =
        LanguageString('Due Date') + ' ' + LanguageString('is required');
      isValid = false;
    }
    if (!newMaintenance.completedDate) {
      newErrors.completedDate =
        LanguageString('Completed Date') + ' ' + LanguageString('is required');
      isValid = false;
    }
    if (!newMaintenance.Technician) {
      newErrors.Technician =
        LanguageString('Technician') + ' ' + LanguageString('is required');
      isValid = false;
    }
    if (!newMaintenance.Remarks) {
      newErrors.Remarks =
        LanguageString('Remarks') + ' ' + LanguageString('is required');
      isValid = false;
    }
    if (!newMaintenance.assetsType) {
      newErrors.assetsType =
        LanguageString('Assets Type') + ' ' + LanguageString('is required');
      isValid = false;
    }
    setErrors(newErrors);
    return isValid;
  }, [newMaintenance]);

  // Add new maintenance entry
  const handleAddNewMaintenance = useCallback(() => {
    if (validateNewMaintenance()) {
      setMaintenances(prevMaintenances => {
        const newId =
          Math.max(...(prevMaintenances || []).map(s => s.id), 0) + 1;
        return [...(prevMaintenances || []), {...newMaintenance, id: newId}];
      });
      closeAddNewMaintenance();
    }
  }, [newMaintenance, validateNewMaintenance, closeAddNewMaintenance]);

  // Delete maintenance entry
  // const handleDeleteMaintenance = useCallback((id: number) => {
  //   setMaintenances(prevMaintenances =>
  //     prevMaintenances.filter(s => s.id !== id),
  //   );
  // }, []);

  // Memoized props for MaintenanceScreenView component
  const maintenanceScreenViewProps = useMemo(
    () => ({
      selectedMaintenance,
      setShowDatePicker,
      editingStatus,
      newStatus,
      maintenances,
      isAddingNewMaintenance,
      setIsAddingNewMaintenance,
      newMaintenance,
      setNewMaintenance,
      setNewStatus,
      showDatePicker,
      errors,
      refreshing,
      onRefresh,
      openMaintenanceDetails,
      closeMaintenanceDetails,
      startEditingStatus,
      saveStatus,
      validateStatus,
      openAddNewMaintenance,
      closeAddNewMaintenance,
      handleAddNewMaintenance,
      // handleDeleteMaintenance,
      remarks,
      description,
      setDescription,
      setRemarks,
    }),
    [
      selectedMaintenance,
      editingStatus,
      newStatus,
      maintenances,
      isAddingNewMaintenance,
      newMaintenance,
      showDatePicker,
      errors,
      refreshing,
      onRefresh,
      openMaintenanceDetails,
      closeMaintenanceDetails,
      startEditingStatus,
      saveStatus,
      validateStatus,
      openAddNewMaintenance,
      closeAddNewMaintenance,
      handleAddNewMaintenance,
      // handleDeleteMaintenance,
      remarks,
      description,
      setDescription,
      setRemarks,
    ],
  );

  // Render MaintenanceScreenView component with props
  return <MaintenanceScreenView {...maintenanceScreenViewProps} />;
};

export default MaintenanceScreen;
