import React, {useCallback, useState} from 'react';
import {useDispatch} from 'react-redux';
import SignupScreenView from './SignupScreenView';
import {setToken, setUserDetails} from '../../store/authSlice';
import {storeToken} from '../../services/authService';
import {ALL_URLS, BASE_URL_DSS_OPS} from '../../constants/data';
import {CommonActions, useNavigation} from '@react-navigation/native';
import {HandleSendOtp, handleVerifyOTP} from '../../services/apiServices';
import {DecodeJWT} from '../../components/DecodeJWT';
import {PAGES} from '../../components/pages';

const SignupScreen: React.FC = () => {
  const dispatch = useDispatch();

  const navigation = useNavigation();

  // Form state
  const [formState, setFormState] = useState({
    email: '',
    // fullname: '',
    // area: '',
    phone: '' as string,
    // city: '',
    // pincode: undefined as number | undefined,
    password: '',
    confirmPassword: '',
    otp: 0 as number | undefined,
  });

  // Error state
  const [errorState, setErrorState] = useState({
    // emailError: '',
    // fullnameError: '',
    otpError: '',
    phoneError: '',
    // areaError: '',
    // cityError: '',
    // pincodeError: '',
    // passwordError: '',
    // confirmPasswordError: '',
    // confirmMobileError: '',
  });

  // UI state
  const [uiState, setUiState] = useState({
    showNextFields: true,
    showPassword: false,
    showConfirmPassword: false,
    showOtpInput: false,
    isFormValid: false,
    loading: false,
    createPasswordModal: false,
    showCreatePasswordModal: false,
  });

  // Modal state
  const [modalState, setModalState] = useState({
    visible: false,
    dialogTitle: '',
    dialogDescription: '',
  });
  const updateFormState = (field: string, value: string | number) => {
    setFormState(prev => ({...prev, [field]: value}));
  };

  const updateUiState = (field: string, value: boolean | number) => {
    setUiState(prev => ({...prev, [field]: value}));
  };

  const updateModalState = (field: string, value: boolean | string) => {
    setModalState(prev => ({...prev, [field]: value}));
  };

  const handleSignup = async (
    phoneNumber: number | undefined,
  ): Promise<void> => {
    const payload = {
      phoneNumber,
    };
    try {
      const {token} = await fetch(BASE_URL_DSS_OPS + ALL_URLS.CREATE_USER, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(payload),
      }).then(response => response.json());

      await storeToken(token);
      dispatch(setToken(token));
    } catch (error) {
      console.error('Sign up error:', error);
    }
  };

  const handleOtpVerification = async () => {
    const payload = {
      otp: formState.otp,
      mobileNumber: formState.phone,
    };
    const dummyOtp = 8888;
    console.log('Verify OTP payload:', payload);
    handleVerifyOTP(
      formState?.phone?.toString() ?? '',
      formState?.otp,
      (loading: boolean) => updateUiState('isLoading', true),
      onOTPVerifySuccess,
      onOTPVerifyFailed,
    );
    // updateUiState('loading', true);
    // try {
    //   const response = await fetch(BASE_URL_DSS_OPS + ALL_URLS.VERIFY_OTP, {
    //     method: 'POST',
    //     headers: {
    //       'Content-Type': 'application/json',
    //     },
    //     body: JSON.stringify(payload),
    //   });

    //   if (response.ok) {
    //     // if (formState.otp == dummyOtp) {
    //     updateUiState('showOtpInput', false);
    //     // updateUiState('showCreatePasswordModal', true);
    //     updateUiState('loading', false);
    //   } else {
    //     setErrorState(prev => ({
    //       ...prev,
    //       otpError: 'Invalid OTP. Please try again.',
    //     }));
    //     updateUiState('loading', false);
    //   }
    // } catch (error) {
    //   updateUiState('loading', false);
    //   console.error('Error during OTP verification:', error);

    //   setErrorState(prev => ({
    //     ...prev,
    //     otpError: 'An error occurred. Please try again.',
    //   }));
    // }
  };
  const onOTPVerifySuccess = async (data: any) => {
    const token = data.data.token;
    const decoded = DecodeJWT({token});
    if (decoded) {
      const id = (decoded as any).id;
      const role = (decoded as any).role;
      console.log('Decoded Token:', role);
      console.log('Decoded Token ID:', id);
      dispatch(setUserDetails({id, role}));
      dispatch(setToken(token));
      await storeToken(token);
      // Replace the navigation to DASHBOARD_NAV with a more specific screen
      updateUiState('loading', false);
      navigation.dispatch(
        CommonActions.reset({
          index: 0,
          routes: [{name: PAGES.DASHBOARD_NAV}], // Assuming HOME is a valid screen in your navigation
        }),
      );
      console.log('Now save token ahndhandle login:', data);
    }
  };
  const onOTPVerifyFailed = (error: any) => {
    setErrorState(prev => ({...prev, otpError: error}));
  };

  const handleResendOTP = () => {
    const payload = {
      mobileNumber: formState.phone?.toString(),
    };
    console.log('Resend OTP payload:', payload);
    HandleSendOtp(payload, onOTPVerifySuccess, onOTPVerifyFailed);
    updateUiState('timer', 60);
  };

  const hideDialog = useCallback(() => {
    updateModalState('visible', false);
  }, []);

  return (
    <SignupScreenView
      formState={formState}
      uiState={uiState}
      modalState={modalState}
      errorState={errorState}
      updateFormState={updateFormState}
      updateUiState={updateUiState}
      updateModalState={updateModalState}
      handleOtpVerification={handleOtpVerification}
      hideDialog={hideDialog}
      navigation={navigation}
      handleResendOTP={handleResendOTP}
    />
  );
};
export default SignupScreen;
