import React from 'react';
import {ScrollView, View} from 'react-native';
import {FwButtonPrimary, FwTextPrimary, FwTextSecondary} from '../../elements';
import {LanguageString} from '../../constants/data';
import {commonStyle} from '../../constants/theme';
import FWDropdown from '../../elements/FwDropdown';
import {MaintenancePropTypes} from '../../types/commonTypes';
import { AppState } from 'react-native';
import { useSelector } from 'react-redux';

interface MaintenanceDetailsComponentProps {
  selectedMaintenance: MaintenancePropTypes;
  editingStatus: boolean;
  newStatus: string;
  setNewStatus: (status: string) => void;
  validateStatus: (status: string) => void;
  saveStatus: () => void;
  closeMaintenanceDetails: () => void;
}

const MaintenanceDetailsComponent = ({
  selectedMaintenance,
  editingStatus,
  newStatus,
  setNewStatus,
  validateStatus,
  saveStatus,
  closeMaintenanceDetails,
}: MaintenanceDetailsComponentProps) => {
  const statusOptions = [
    {label: LanguageString('Pending'), value: 'Pending'},
    {label: LanguageString('In progress'), value: 'In progress'},
    {label: LanguageString('Closed'), value: 'Closed'},
  ];
  const users = useSelector((state: AppState) => state.app.users?.data);

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-GB', {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
    });
  };

  // Find user name based on technician ID
  const getUserName = (assignedUserID: number): string => { 
    const user = users?.find((user: any) => user.userID === assignedUserID);
    return user ? user.userName : 'Unknown';
  };
  return (
    <ScrollView>
      <View style={commonStyle.modalHeader}>
        <FwTextSecondary style={commonStyle.modalTitle}>
          {LanguageString('Maintenance Details')}
        </FwTextSecondary>
      </View>

      {selectedMaintenance && (
        <>
          <View style={commonStyle.modalRow}>
            <FwTextPrimary style={commonStyle.boldText}>
              {LanguageString('Maintenance ID')}:
            </FwTextPrimary>
            <FwTextPrimary style={commonStyle.normalText}>
              {selectedMaintenance.maintenanceID}
            </FwTextPrimary>
          </View>

          <View style={commonStyle.modalRow}>
            <FwTextPrimary style={commonStyle.boldText}>
              {LanguageString('Description')}:
            </FwTextPrimary>
            <FwTextPrimary style={commonStyle.normalText}>
              {selectedMaintenance.description}
            </FwTextPrimary>
          </View>

          <View style={commonStyle.modalRow}>
            <FwTextPrimary style={commonStyle.boldText}>
              {LanguageString('Assigned To')}:
            </FwTextPrimary>
            <FwTextPrimary style={commonStyle.normalText}>
              {getUserName(selectedMaintenance?.assignedUserID)}
            </FwTextPrimary>
          </View>

          <View style={commonStyle.modalRow}>
            <FwTextPrimary style={commonStyle.boldText}>
              {LanguageString('Status')}:
            </FwTextPrimary>
            <FwTextPrimary style={commonStyle.normalText}>
              {selectedMaintenance.status === 1 ? LanguageString('Scheduled') :
               selectedMaintenance.status === 3 ? LanguageString('Completed') :
               selectedMaintenance.status}
            </FwTextPrimary>
          </View>

          <View style={commonStyle.modalRow}>
            <FwTextPrimary style={commonStyle.boldText}>
              {LanguageString('Scheduled Date')}:
            </FwTextPrimary>
            <FwTextPrimary style={commonStyle.normalText}>
              {formatDate(selectedMaintenance.scheduledDate)}
            </FwTextPrimary>
          </View>

          <View style={commonStyle.modalRow}>
            <FwTextPrimary style={commonStyle.boldText}>
              {LanguageString('Due Date')}:
            </FwTextPrimary>
            <FwTextPrimary style={commonStyle.normalText}>
              {formatDate(selectedMaintenance.dueDate)}
            </FwTextPrimary>
          </View>
        </>
      )}
      {editingStatus && (
        <FWDropdown
          multiple={false}
          label={LanguageString('Select Status')}
          options={statusOptions}
          value={newStatus}
          onSelect={(value: string | undefined) => {
            if (value !== undefined) {
              setNewStatus(value);
              validateStatus(value);
            }
          }}
        />
      )}
      {editingStatus && (
        <FwButtonPrimary onPress={saveStatus} style={commonStyle.saveButton}>
          <FwTextSecondary>{LanguageString('Save')}</FwTextSecondary>
        </FwButtonPrimary>
      )}
      <FwButtonPrimary
        onPress={closeMaintenanceDetails}
        style={commonStyle.closeButton}>
        <FwTextSecondary>{LanguageString('Cancel')}</FwTextSecondary>
      </FwButtonPrimary>
    </ScrollView>
  );
};

export default MaintenanceDetailsComponent;