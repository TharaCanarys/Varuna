import React, {useCallback, useEffect, useMemo, useState} from 'react';
import ProfileScreenView from './ProfileScreenView';
import {useDispatch, useSelector} from 'react-redux';
import {PErrors, PFields, Profile} from '../../types/profileTypes';
import {LanguageString} from '../../constants/data';
import {RootState} from '../../store/store';
import {showDialog} from '../../store/appSlice';
import {useNavigation} from '@react-navigation/native';
const ProfileScreen: React.FC = () => {
  const dispatch = useDispatch();
  const [editing, setEditing] = useState<boolean>(false);
  const role = useSelector((state: RootState) => state.auth.userRole);
  const email = useSelector((state: RootState) => state.auth.userName);
  const [profile, setProfile] = useState<Profile>({
    firstName: '',
    lastName: '',
    address: LanguageString('address'),
    city: LanguageString('Gorakhpur'),
    state: LanguageString('Uttar Pradesh'),
    zipCode: LanguageString('273001'),
  });
  const [refreshing, setRefreshing] = useState(false);
  const language = useSelector(
    (state: RootState) => state.app.selectedLanguage,
  );
  const onRefresh = React.useCallback(() => {
    setRefreshing(true);
    setProfile(prevProfile => ({
      ...prevProfile,
      firstName: role,
      lastName: email,
      address: LanguageString('address'),
      city: LanguageString('Gorakhpur'),
      state: LanguageString('Uttar Pradesh'),
      zipCode: LanguageString('273001'),
    }));
    setErrors({
      firstName: '',
      lastName: '',
      address: '',
      city: '',
      state: '',
      zipCode: '',
    });
    setEditing(false);
    setTimeout(() => {
      setRefreshing(false);
    }, 2000);
  }, [language, role, email]);

  useEffect(() => {
    onRefresh();
  }, [language, onRefresh]);

  const handleLanguageChange = () => {
    dispatch(showDialog());
  };
  useEffect(() => {
    setProfile(prevProfile => ({
      ...prevProfile,
      firstName: role,
      lastName: email,
    }));
  }, [role, email]);
  const [errors, setErrors] = useState<PErrors>({
    firstName: '',
    lastName: '',
    address: '',
    city: '',
    state: '',
    zipCode: '',
  });

  const validateField = useCallback((field: keyof Profile, value: string) => {
    let error = '';
    if (!value?.trim()) {
      error = LanguageString(`This field is required`);
    } else if (field === 'zipCode' && !/^\d{6}(-\d{4})?$/.test(value)) {
      error = LanguageString('Invalid zip code');
    } else if (field === 'firstName' && value.length < 2) {
      error = LanguageString('First name must be at least 2 characters');
    } else if (field === 'lastName' && value.length < 2) {
      error = LanguageString('Last name must be at least 2 characters');
    }
    setErrors(prevErrors => ({...prevErrors, [field]: error}));
  }, []);

  const handleInputChange = useCallback(
    (field: keyof Profile, value: string) => {
      setProfile(prevProfile => ({
        ...prevProfile,
        [field]: value,
      }));
      validateField(field, value);
    },
    [validateField],
  );

  const fields: PFields[] = useMemo(
    () => [
      {name: 'firstName', label: LanguageString('Role'), icon: 'account'},
      {name: 'lastName', label: LanguageString('Name'), icon: 'account'},
      {name: 'address', label: LanguageString('Address'), icon: 'map-marker'},
      {name: 'city', label: LanguageString('City'), icon: 'map-marker'},
      {name: 'state', label: LanguageString('State'), icon: 'map-marker'},
      {name: 'zipCode', label: LanguageString('Zip Code'), icon: 'map-marker'},
    ],
    [language],
  );

  const handleSubmit = useCallback(async () => {
    let hasErrors = false;
    const updatedErrors = {...errors};

    fields.forEach(field => {
      const value = profile[field.name]?.trim() ?? '';
      if (!value) {
        updatedErrors[field.name] = LanguageString(
          `${field.label} is required`,
        );
        hasErrors = true;
      } else {
        validateField(field.name as keyof Profile, value);
        if (errors[field.name as keyof Profile]) {
          hasErrors = true;
        }
      }
    });
    setErrors(updatedErrors);

    if (!hasErrors) {
      try {
        dispatch({type: 'UPDATE_PROFILE', payload: profile});
        setEditing(false);
      } catch (error) {
        console.error('Error updating profile:', error);
      }
    }
  }, [fields, profile, errors, validateField, dispatch]);

  const toggleEditing = useCallback(() => {
    setEditing(prev => !prev);
    if (editing) {
      setErrors({
        firstName: '',
        lastName: '',
        address: '',
        city: '',
        state: '',
        zipCode: '',
      });
    }
  }, [editing]);

  const navigation = useNavigation();
  return (
    <ProfileScreenView
      editing={editing}
      fields={fields}
      refreshing={refreshing}
      onRefresh={onRefresh}
      handleInputChange={handleInputChange}
      profile={profile}
      errors={errors}
      toggleEditing={toggleEditing}
      language={language}
      handleSubmit={handleSubmit}
    />
  );
};
export default ProfileScreen;
