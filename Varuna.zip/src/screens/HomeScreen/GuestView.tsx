// Import necessary dependencies
import React, {useState, useEffect} from 'react';
import {View, StyleSheet} from 'react-native';
import MapView, {Marker} from 'react-native-maps';
import {Button, Menu} from 'react-native-paper';
import {COLORS} from '../../constants/colors';
import {HeaderBanner} from '../../components/HeaderBanner';
import BackPanel from '../../components/BackPanel';
import {fetchLocations} from '../../services/apiServices';
import {useDispatch} from 'react-redux';
import {saveLocation} from '../../store/appSlice';
import {normalized} from '../../constants/platform';

export interface Location {
  locationName: any;
  id: number;
  name: string;
  latitude: number;
  longitude: number;
  sensorId: string;
  pumpId: string;
  poiId: string;
}

const GuestView: React.FC = () => {
  // Initial map region (Gorakhpur)
  const initialRegion = {
    latitude: 26.7605,
    longitude: 83.3731,
    latitudeDelta: 0.0922,
    longitudeDelta: 0.0421,
  };
  const [drawerVisible, setDrawerVisible] = useState(false);
  const [notificationVisible, setNotificationVisible] = useState(false);
  const [selectedSensor, setSelectedSensor] = useState('');
  const [selectedPump, setSelectedPump] = useState('');
  const [selectedPoi, setSelectedPoi] = useState('');
  const [sensorMenuOpen, setSensorMenuOpen] = useState(false);
  const [pumpMenuOpen, setPumpMenuOpen] = useState(false);
  const [poiMenuOpen, setPoiMenuOpen] = useState(false);
  const [visibleLocations, setVisibleLocations] = useState<Location[]>([]);
  const [locations, setLocations] = useState<Location[]>([]);

  // Handler functions
  const toggleDrawer = () => setDrawerVisible(!drawerVisible);
  const toggleNotification = () => setNotificationVisible(!notificationVisible);
  const dispatch = useDispatch();

  // Data for sensors and POIs
  const SENSORS = [
    {label: 'Sensor 1', value: '1'},
    {label: 'Sensor 2', value: '2'},
    {label: 'Sensor 3', value: '3'},
    {label: 'Sensor 4', value: '4'},
    {label: 'Sensor 5', value: '5'},
  ];

  const Pumps = [
    {label: 'Pump 1', value: '1'},
    {label: 'Pump 2', value: '2'},
    {label: 'Pump 3', value: '3'},
    {label: 'Pump 4', value: '4'},
    {label: 'Pump 5', value: '5'},
  ];
  const POIS = [
    {label: 'POI 1', value: '1'},
    {label: 'POI 2', value: '2'},
    {label: 'POI 3', value: '3'},
    {label: 'POI 4', value: '4'},
    {label: 'POI 5', value: '5'},
  ];

  const onFetchLocations = (data: Location[]) => {
    console.log('Location data Fetched');
    setLocations(data);
    dispatch(saveLocation(data));
  };

  const onLocationFailed = (data: Location[]) => {
    console.log('Location data Fetching Failed', data);
  };

  // useEffect(() => {
  //   fetchLocations({onFetchLocations, onLocationFailed});
  // }, []);

  useEffect(() => {
    updateVisibleLocations();
  }, [selectedSensor, selectedPump, selectedPoi, locations]);

  const updateVisibleLocations = () => {
    const filteredLocations = locations.filter(location => {
      if (selectedSensor) {
        return location.sensorId === selectedSensor;
      }
      if (selectedPump) {
        return location.pumpId === selectedPump;
      }
      if (selectedPoi) {
        return location.poiId === selectedPoi;
      }
      return !selectedSensor && !selectedPoi;
    });
    setVisibleLocations(filteredLocations);
  };

  return (
    <>
      <HeaderBanner />
      <BackPanel />
      <View style={styles.container}>
        {/* Sensor and POI Selection */}
        <View style={[styles.row, {zIndex: 1}]}>
          <Menu
            visible={sensorMenuOpen}
            onDismiss={() => setSensorMenuOpen(false)}
            anchor={
              <Button mode="outlined" onPress={() => setSensorMenuOpen(true)}>
                {selectedSensor === ''
                  ? 'Select Sensor'
                  : `Sensor ${selectedSensor}`}
              </Button>
            }>
            <Menu.Item
              key="all"
              onPress={() => {
                setSelectedSensor('');
                setSensorMenuOpen(false);
              }}
              title="All Sensors"
            />
            {SENSORS.map(item => (
              <Menu.Item
                key={item.value}
                onPress={() => {
                  setSelectedSensor(item.value);
                  setSensorMenuOpen(false);
                }}
                title={item.label}
              />
            ))}
          </Menu>
          <Menu
            visible={pumpMenuOpen}
            onDismiss={() => setPumpMenuOpen(false)}
            anchor={
              <Button mode="outlined" onPress={() => setPumpMenuOpen(true)}>
                {selectedPump === '' ? 'Select Pump' : `Pump ${selectedPump}`}
              </Button>
            }>
            <Menu.Item
              key="all"
              onPress={() => {
                setSelectedPump('');
                setPumpMenuOpen(false);
              }}
              title="All Pumps"
            />
            {Pumps.map(item => (
              <Menu.Item
                key={item.value}
                onPress={() => {
                  setSelectedPump(item.value);
                  setPumpMenuOpen(false);
                }}
                title={item.label}
              />
            ))}
          </Menu>
          <Menu
            visible={poiMenuOpen}
            onDismiss={() => setPoiMenuOpen(false)}
            anchor={
              <Button mode="outlined" onPress={() => setPoiMenuOpen(true)}>
                {selectedPoi === '' ? 'Select POI' : `POI ${selectedPoi}`}
              </Button>
            }>
            <Menu.Item
              key="all"
              onPress={() => {
                setSelectedPoi('');
                setPoiMenuOpen(false);
              }}
              title="All POIs"
            />
            {POIS.map(item => (
              <Menu.Item
                key={item.value}
                onPress={() => {
                  setSelectedPoi(item.value);
                  setPoiMenuOpen(false);
                }}
                title={item.label}
              />
            ))}
          </Menu>
        </View>

        {/* Map View */}
        <View style={styles.mapContainer}>
          <MapView
            style={styles.map}
            initialRegion={initialRegion}
            showsUserLocation={true}
            followsUserLocation={true}>
            {visibleLocations.map(location => (
              <Marker
                key={location.id}
                coordinate={{
                  latitude: location.latitude,
                  longitude: location.longitude,
                }}
                title={location.locationName}
                description={'Location ID : ' + location.id.toString()}
              />
            ))}
          </MapView>
        </View>
      </View>
    </>
  );
};

// Styles
const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  row: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginHorizontal: normalized(10),
    marginVertical: normalized(10),
  },
  mapContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  map: {
    ...StyleSheet.absoluteFillObject,
  },
  search: {
    marginBottom: normalized(20),
    position: 'absolute',
    top: normalized(70),
    left: normalized(0),
    right: normalized(0),
    zIndex: normalized(1),
  },
  drawer: {
    backgroundColor: COLORS.PRIMARY,
    padding: normalized(20),
    margin: normalized(20),
    borderRadius: 5,
  },
});

export default GuestView;
