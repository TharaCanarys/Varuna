import React, {useCallback, useState, useMemo, useEffect} from 'react';
import {CityAdminPropTypes} from '../../types/commonTypes';
import {
  cityAdminData,
  LanguageString,
} from '../../constants/data';
import CityAdminScreenView from './CityAdminScreenView';
import {useSelector} from 'react-redux';
import {RootState} from '../../store/store';

const CityAdminScreen: React.FC = () => {
  const [selectedCityAdmin, setSelectedCityAdmin] =
    useState<CityAdminPropTypes | null>(null);
  const [editingStatus, setEditingStatus] = useState(false);
  const [newStatus, setNewStatus] = useState('');
  const [statusError, setStatusError] = useState('');
  const language = useSelector(
    (state: RootState) => state.app.selectedLanguage,
  );
  const [cityAdmins, setCityAdmins] =
    useState<CityAdminPropTypes[]>(cityAdminData);
  const [isAddingNewCityAdmin, setIsAddingNewCityAdmin] = useState(false);
  const [newCityAdmin, setNewCityAdmin] = useState<CityAdminPropTypes>({
    id: 0,
    cityAdminAreaName: '',
    cityAdminAreaType: '',
    location: '',
    population: 0,
    keyFacility: '',
    floodRiskLevel: '',
    contactPerson: '',
    emergencyService: '',
    evolutionPlan: '',
  });
  const [errors, setErrors] = useState({
    cityAdminAreaName: '',
    cityAdminAreaType: '',
    location: '',
    population: 0,
    keyFacility: '',
    floodRiskLevel: '',
    contactPerson: '',
    emergencyService: '',
    evolutionPlan: '',
  });
  const [refreshing, setRefreshing] = useState(false);

  // Memoize the initial state of newCityAdmin to avoid unnecessary re-renders
  const initialNewCityAdminState = useMemo(
    () => ({
      id: 0,
      cityAdminAreaName: '',
      cityAdminAreaType: '',
      maintenanceType: '',
      location: '',
      population: 0,
      keyFacility: '',
      floodRiskLevel: '',
      contactPerson: '',
      emergencyService: '',
      evolutionPlan: '',
    }),
    [],
  );

  // Simulate data refresh
  useEffect(() => {
    onRefresh();
  }, [language]);
  const onRefresh = useCallback(() => {
    setRefreshing(true);
    setTimeout(() => {
      setCityAdmins([...cityAdminData]);
      setRefreshing(false);
    }, 1000);
  }, []);

  // Open cityAdmin details modal
  const openCityAdminDetails = useCallback((cityAdmin: CityAdminPropTypes) => {
    setSelectedCityAdmin(cityAdmin);
  }, []);

  // Close cityAdmin details modal
  const closeCityAdminDetails = useCallback(() => {
    setSelectedCityAdmin(null);
    setEditingStatus(false);
  }, []);

  // Toggle status editing
  const startEditingStatus = useCallback(() => {
    setEditingStatus(prev => !prev);
  }, []);

  // Save updated cityAdmin status
  const saveStatus = useCallback(() => {
    if (selectedCityAdmin) {
      setCityAdmins(prevCityAdmins =>
        prevCityAdmins.map(cityAdmin =>
          cityAdmin.id === selectedCityAdmin.id
            ? {...cityAdmin, status: newStatus}
            : cityAdmin,
        ),
      );
      setSelectedCityAdmin(prev => ({...prev!, status: newStatus}));
      setEditingStatus(false);
    }
  }, [selectedCityAdmin, newStatus]);

  // Validate status input
  const validateStatus = useCallback((status: string) => {
    if (!status) {
      setStatusError(LanguageString('Status')) +
        ' ' +
        LanguageString('is required');
    } else {
      setStatusError('');
    }
  }, []);

  // Open add new cityAdmin modal
  const openAddNewCityAdmin = useCallback(() => {
    setIsAddingNewCityAdmin(true);
  }, []);

  // Close add new cityAdmin modal
  const closeAddNewCityAdmin = useCallback(() => {
    setIsAddingNewCityAdmin(false);
    setNewCityAdmin(initialNewCityAdminState);
    setErrors({
      cityAdminAreaName: '',
      cityAdminAreaType: '',
      location: '',
      population: 0,
      keyFacility: '',
      floodRiskLevel: '',
      contactPerson: '',
      emergencyService: '',
      evolutionPlan: '',
    });
  }, [initialNewCityAdminState]);

  // Validate new cityAdmin input
  const validateNewCityAdmin = useCallback(() => {
    let isValid = true;
    const newErrors = {
      cityAdminAreaName: '',
      cityAdminAreaType: '',
      location: '',
      population: 0,
      keyFacility: '',
      floodRiskLevel: '',
      contactPerson: '',
      emergencyService: '',
      evolutionPlan: '',
    };
    if (!newCityAdmin.location) {
      newErrors.location =
        LanguageString('Location') + ' ' + LanguageString('is required');
      isValid = false;
    }
    if (!newCityAdmin.cityAdminAreaName) {
      newErrors.cityAdminAreaName =
        LanguageString('City Admin Area Name') +
        ' ' +
        LanguageString('is required');
      isValid = false;
    }
    if (!newCityAdmin.cityAdminAreaType) {
      newErrors.cityAdminAreaType =
        LanguageString('Admin Area Type') + ' ' + LanguageString('is required');
      isValid = false;
    }
    if (!newCityAdmin.keyFacility) {
      newErrors.keyFacility =
        LanguageString('Key Facility') + ' ' + LanguageString('is required');
      isValid = false;
    }
    if (!newCityAdmin.floodRiskLevel) {
      newErrors.floodRiskLevel =
        LanguageString('Flood Risk Level') +
        ' ' +
        LanguageString('is required');
      isValid = false;
    }
    if (!newCityAdmin.contactPerson) {
      newErrors.contactPerson =
        LanguageString('Contact Person') + ' ' + LanguageString('is required');
      isValid = false;
    }
    if (!newCityAdmin.emergencyService) {
      newErrors.emergencyService =
        LanguageString('Emergency Service') +
        ' ' +
        LanguageString('is required');
      isValid = false;
    }
    if (!newCityAdmin.evolutionPlan) {
      newErrors.evolutionPlan =
        LanguageString('Evolution Plan') + ' ' + LanguageString('is required');
      isValid = false;
    }

    setErrors(newErrors);
    return isValid;
  }, [newCityAdmin]);

  // Add new cityAdmin
  const handleAddNewCityAdmin = useCallback(() => {
    if (validateNewCityAdmin()) {
      setCityAdmins(prevCityAdmins => {
        const newId = Math.max(...prevCityAdmins.map(s => s.id), 0) + 1;
        const cityAdminToAdd = {...newCityAdmin, id: newId};
        return [...prevCityAdmins, cityAdminToAdd];
      });
      closeAddNewCityAdmin();
    }
  }, [newCityAdmin, validateNewCityAdmin, closeAddNewCityAdmin]);

  // Delete cityAdmin
  const handleDeleteCityAdmin = useCallback((id: number) => {
    setCityAdmins(prevCityAdmins =>
      prevCityAdmins.filter(s => s.id !== id),
    );
  }, []);

  // Memoize the props for CityAdminScreenView to prevent unnecessary re-renders
  const cityAdminScreenViewProps = useMemo(
    () => ({
      selectedCityAdmin,
      editingStatus,
      newStatus,
      cityAdmins,
      isAddingNewCityAdmin,
      setIsAddingNewCityAdmin,
      newCityAdmin,
      setNewCityAdmin,
      setNewStatus,
      errors,
      refreshing,
      onRefresh,
      openCityAdminDetails,
      closeCityAdminDetails,
      startEditingStatus,
      saveStatus,
      validateStatus,
      openAddNewCityAdmin,
      closeAddNewCityAdmin,
      handleAddNewCityAdmin,
      handleDeleteCityAdmin,
    }),
    [
      selectedCityAdmin,
      editingStatus,
      newStatus,
      cityAdmins,
      setIsAddingNewCityAdmin,
      isAddingNewCityAdmin,
      newCityAdmin,
      errors,
      refreshing,
      onRefresh,
      openCityAdminDetails,
      closeCityAdminDetails,
      startEditingStatus,
      saveStatus,
      validateStatus,
      openAddNewCityAdmin,
      closeAddNewCityAdmin,
      handleAddNewCityAdmin,
      handleDeleteCityAdmin,
    ],
  );

  return <CityAdminScreenView {...cityAdminScreenViewProps} />;
};export default CityAdminScreen;
