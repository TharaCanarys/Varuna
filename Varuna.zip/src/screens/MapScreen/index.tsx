import React, {useRef} from 'react';
import {View, StyleSheet, Dimensions} from 'react-native';
import {WebView} from 'react-native-webview';

const MapScreen: React.FC = () => {
  const webViewRef = useRef(null); // WebView reference

  const hideNavbarScript = `
    document.querySelector('nav')?.remove();
    document.querySelector('.navbar')?.remove();
    document.querySelector('header')?.remove();
    document.querySelector('.logos-container').style.display = 'none';
    true;
  `;

  const onLoadEnd = () => {
    // Inject the JavaScript to hide elements after the page has loaded
    if (webViewRef.current) {
      webViewRef.current.injectJavaScript(hideNavbarScript); // Ensure it's injected on iOS too
    }
  };

  return (
    <View style={styles.container}>
      <WebView
        ref={webViewRef}
        source={{uri: 'https://ufews.com:8085/Home/Maps'}}
        style={styles.webview}
        javaScriptEnabled={true}
        domStorageEnabled={true}
        startInLoadingState={true}
        onLoadEnd={onLoadEnd} // Inject script on load end
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  webview: {
    width: Dimensions.get('window').width,
    height: Dimensions.get('window').height,
  },
});

export default MapScreen;
