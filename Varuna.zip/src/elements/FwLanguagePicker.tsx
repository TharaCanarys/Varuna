import React, {useEffect, useCallback} from 'react';
import {StyleSheet, View} from 'react-native';
import i18n from '../language/i18n';
import {getLanguage, storeLanguage} from '../services/authService';
import {useNavigation, useRoute} from '@react-navigation/native';
import FwDialog from './FwDialog';
import {hideDialog, setLanguage} from '../store/appSlice';
import {useDispatch, useSelector} from 'react-redux';
import FwButtonPrimary from './FwButtonPrimary';
import FwTextPrimary from './FwTextPrimary';
import {LanguageString} from '../constants/data';
import {RootState} from '../store/store';
import {IMAGES} from '../assets';
import FwImage from './FwImage';
import {normalized} from '../constants/platform';
import {PAGES} from '../components/pages';
// Component for handling language selection and switching functionality
const FwLanguagePicker = () => {
  // Get language alert state from Redux store
  const visibleDialog = useSelector(
    (state: RootState) => state.app.languageAlert,
  );

  // Get selected language from Redux store
  const language = useSelector(
    (state: RootState) => state.app.selectedLanguage,
  );

  const navigation = useNavigation();
  const route = useRoute();
  const dispatch = useDispatch();

  // Load saved language preference when component mounts
  // useEffect(() => {
  //   const loadLanguage = async () => {
  //     const savedLanguage = await getLanguage();
  //     if (savedLanguage) {
  //       i18n.changeLanguage(savedLanguage);
  //     }
  //   };
  //   loadLanguage();
  // }, [dispatch]);

  // Function to hide language change confirmation dialog
  // const hideDialog = useCallback(() => {
  //   dispatch(saveLanguageAlert(false));
  // }, []);

  // Function to handle language change
  const changeLanguage = useCallback(async (lang: string) => {
    // Save language preference and update app state
    await storeLanguage(lang);
    i18n.changeLanguage(lang);
    dispatch(setLanguage(lang));
    dispatch(hideDialog());
    if (LanguageString(route.name) == LanguageString(PAGES.DASHBOARD)) {
      // console.log('Dashboard route.name', route.name);
      navigation.navigate(PAGES.DASHBOARD_NAV as never);
    } else {
      // console.log('Different route.name', route.name);
      // navigation.navigate(PAGES.HOME);
    }
    // Handle navigation based on current route
  }, []);

  return (
    <View>
      {/* Language switcher icon */}
      <FwImage source={IMAGES.TRANSLATE} style={styles.translateIcon} />
      {/* Language change confirmation dialog */}

      <FwDialog
        title="Change Language"
        // description="This is a customizable dialog."
        visible={visibleDialog}
        hideDialog={() => dispatch(hideDialog())}>
        <FwButtonPrimary mode="outlined" onPress={() => dispatch(hideDialog())}>
          <FwTextPrimary>{LanguageString('LanguageCancel')}</FwTextPrimary>
        </FwButtonPrimary>
        <FwButtonPrimary
          mode="outlined"
          onPress={() => changeLanguage(language == 'hi' ? 'en' : 'hi')}>
          <FwTextPrimary>{LanguageString('LanguageConfirm')}</FwTextPrimary>
        </FwButtonPrimary>
      </FwDialog>
      {/* <FwDialog
        visible={visibleDialog}
        hideDialog={hideDialog}
        title={'Change Language'}>
        <FwButtonPrimary mode="outlined" onPress={hideDialog}>
          <FwTextPrimary>{LanguageString('LanguageCancel')}</FwTextPrimary>
        </FwButtonPrimary>
        <FwButtonPrimary
          mode="outlined"
          onPress={() => changeLanguage(language == 'hi' ? 'en' : 'hi')}>
          <FwTextPrimary>{LanguageString('LanguageConfirm')}</FwTextPrimary>
        </FwButtonPrimary>
      </FwDialog> */}
    </View>
  );
};

export default FwLanguagePicker;

// Styles for the language picker component
const styles = StyleSheet.create({
  translateIcon: {
    width: normalized(25),
    height: normalized(25),
  },
});
