import React from 'react';
import {StyleSheet, View} from 'react-native';
import {Surface} from 'react-native-paper';
import {COLORS} from '../../constants/colors';
import {normalized} from '../../constants/platform';
import {FwButtonPrimary, FwTextPrimary} from '../../elements';
import {commonStyle} from '../../constants/theme';
import {LanguageString} from '../../constants/data';
import FwModal from '../../elements/FwModal';

const LogDetailsModal = ({
  visible,
  selectedLog,
  onDismiss,
  getSeverityStyle,
}: any) => {
  return (
    <FwModal
      visible={visible}
      onDismiss={onDismiss}
      contentContainerStyle={styles.modalContent}>
      {selectedLog && (
        <Surface style={styles.surface}>
          <FwTextPrimary style={commonStyle.modalTitle}>
            {LanguageString(selectedLog.status)}
          </FwTextPrimary>
          <View style={commonStyle.modalRow}>
            <FwTextPrimary style={commonStyle.boldText}>
              {LanguageString('Log ID') + ' '} :
            </FwTextPrimary>
            <FwTextPrimary style={commonStyle.normalText}>
              {selectedLog.logId}{' '}
            </FwTextPrimary>
          </View>
          <View style={commonStyle.modalRow}>
            <FwTextPrimary style={commonStyle.boldText}>
              {LanguageString('Timestamp') + ' '} :
            </FwTextPrimary>
            <FwTextPrimary style={commonStyle.normalText}>
              {selectedLog.loggedTime}
            </FwTextPrimary>
          </View>
          <View style={commonStyle.modalRow}>
            <FwTextPrimary style={commonStyle.boldText}>
              {LanguageString('Category') + ' '} :
            </FwTextPrimary>
            <FwTextPrimary style={commonStyle.normalText}>
              {LanguageString(selectedLog.category)}
            </FwTextPrimary>
          </View>
          <View style={commonStyle.modalRow}>
            <FwTextPrimary style={commonStyle.boldText}>
              {LanguageString('Severity') + ' '} :
            </FwTextPrimary>
            <FwTextPrimary style={commonStyle.normalText}>
              <FwTextPrimary
                style={
                  [styles.tag, getSeverityStyle(selectedLog.severity)] as any
                }>
                {LanguageString(selectedLog.severity)}
              </FwTextPrimary>
            </FwTextPrimary>
          </View>
          <View style={commonStyle.modalRow}>
            <FwTextPrimary style={commonStyle.boldText}>
              {LanguageString('Status') + ' '} :
            </FwTextPrimary>
            <FwTextPrimary style={commonStyle.normalText}>
              <FwTextPrimary
                style={
                  [
                    styles.status,
                    selectedLog.status === LanguageString('Success')
                      ? styles.success
                      : styles.error,
                  ] as any
                }>
                {LanguageString(selectedLog.status)}
              </FwTextPrimary>
            </FwTextPrimary>
          </View>
          <View style={commonStyle.modalRow}>
            <FwTextPrimary style={commonStyle.boldText}>
              {LanguageString('Details') + ' '} :
            </FwTextPrimary>
            <FwTextPrimary style={commonStyle.normalText}>
              {selectedLog.details}
            </FwTextPrimary>
          </View>
          <FwButtonPrimary
            mode="contained"
            onPress={onDismiss}
            style={styles.closeButton}>
            {LanguageString('Close')}
          </FwButtonPrimary>
        </Surface>
      )}
    </FwModal>
  );
};
export default LogDetailsModal;

const styles = StyleSheet.create({
  modalContent: {
    backgroundColor: COLORS.BG_WHITE,
    padding: normalized(20),
    borderRadius: normalized(20),
  },
  modalTitle: {
    fontSize: normalized(20),
    fontWeight: 'bold',
    marginBottom: normalized(20),
  },
  closeButton: {
    marginTop: normalized(20),
  },
  surface: {
    padding: normalized(20),
    backgroundColor: COLORS.BG_WHITE,
    borderRadius: normalized(8),
  },
  tag: {
    paddingHorizontal: normalized(8),
    paddingVertical: 2,
    borderRadius: normalized(4),
    overflow: 'hidden',
  },
  status: {
    fontWeight: 'bold',
  },
  success: {
    color: COLORS.MEDIUMGREEN,
  },
  error: {
    color: COLORS.ERROR,
  },
});
