import React, {useCallback, useEffect, useState} from 'react';
import {View, StyleSheet, RefreshControl, FlatList} from 'react-native';

import {
  FwButtonPrimary,
  FwDialog,
  FwTextPrimary,
  FwTextSecondary,
} from '../../elements';
import {SensorScreenProps} from '../../types/commonTypes';
import {LanguageString, USER_ROLES} from '../../constants/data';
import {COLORS} from '../../constants/colors';
import PageHeader from '../../components/PageHeader';
import {PAGES} from '../../components/pages';
import {useSelector} from 'react-redux';
import {RootState} from '../../store/store';
import {commonStyle} from '../../constants/theme';
import {normalized} from '../../constants/platform';
import FwModal from '../../elements/FwModal';
import Loader from '../../components/loader';
import {SensorDetailsModal, SensorItem} from '../../components';
import AddSensorComponent from '../../components/SensorComponents/AddSensorComponent';
import FwNotifyMessage from '../../elements/FwNotifyMessage';

// Main component for the Sensor Screen
const SensorScreenView = ({
  selectedSensor,
  refreshing,
  sensors,
  newStatus,
  setNewStatus,
  editingStatus,
  isAddingNewSensor,
  newSensor,
  setNewSensor,
  errors,
  showDatePicker,
  setShowDatePicker,
  openSensorDetails,
  onRefresh,
  startEditingStatus,
  // handleUpdateSensor,
  handleDeleteSensor,
  openAddNewSensor,
  closeSensorDetails,
  validateStatus,
  saveStatus,
  closeAddNewSensor,
  handleAddNewSensor,
  onDateChange,
  sensorNameOptions,
  locationOptions,
  snackbarVisible,
  setSnackbarVisible,
}: SensorScreenProps) => {
  // State for delete confirmation dialog
  const [showDeleteDialog, setShowDeleteDialog] = React.useState(false);
  const [sensorToDelete, setSensorToDelete] = React.useState(null);
  const [showLoader, setShowLoader] = React.useState(false);

  // User Role got from redux store
  const role = useSelector((state: RootState) => state.auth.userRole);
  const validateRole =
    role == USER_ROLES.ADMIN ||
    role == USER_ROLES.SUPER_ADMIN ||
    role == USER_ROLES.IT_SUPPORT ||
    role == USER_ROLES.SENSOR_MANAGER;

  const language = useSelector(
    (state: RootState) => state.app.selectedLanguage,
  );

  const statusOptions = [
    {label: LanguageString('Active'), value: 0},
    {label: LanguageString('Inactive'), value: 1},
    {label: LanguageString('Maintenance'), value: 2},
  ];
  // Open delete confirmation dialog
  const openDeleteDialog = useCallback((sensor: any) => {
    setSensorToDelete(sensor);
    setShowDeleteDialog(true);
  }, []);

  // Close delete confirmation dialog
  const closeDeleteDialog = useCallback(() => {
    setShowDeleteDialog(false);
    setSensorToDelete(null);
  }, []);

  // Confirm sensor deletion
  const confirmDelete = useCallback(() => {
    if (sensorToDelete) {
      handleDeleteSensor(sensorToDelete);
    }
    closeDeleteDialog();
  }, [sensorToDelete, handleDeleteSensor, closeDeleteDialog]);

  // Render individual sensor card

  useEffect(() => {
    sensors.forEach(sensor => {
      const canBeEnabled =
        sensor.status === 'Active' || sensor.status === 'Maintenance';
      const updatedSensor = {
        ...sensor,
        enabled: canBeEnabled,
      };
      // handleUpdateSensor(updatedSensor);
    });
  }, []);

  useEffect(() => {
    if (sensors.length === 0) {
      setShowLoader(true);
    } else {
      setShowLoader(false);
    }
  }, [sensors]);

  const renderSensorCard = useCallback(
    ({item: sensor, index}: {item: any; index: number}) => {
      return (
        <SensorItem
          index={index}
          styles={styles}
          openSensorDetails={openSensorDetails}
          sensor={sensor}
          validateRole={validateRole}
          startEditingStatus={startEditingStatus}
          openDeleteDialog={openDeleteDialog}
        />
      );
    },
    [openSensorDetails, startEditingStatus, openDeleteDialog],
  ); // Render a message if no sensors
  const ListEmptyComponent = useCallback(
    () => (
      <>
        {showLoader ? (
          <Loader />
        ) : (
          <FwTextPrimary style={styles.noSensorsText}>
            {LanguageString('No sensors found')}
          </FwTextPrimary>
        )}
      </>
    ),
    [showLoader],
  );

  // Render sensor details modal content
  //console.log('List sensor', sensors);
  const renderSensorDetails = useCallback(
    () => (
      <SensorDetailsModal
        selectedSensor={selectedSensor}
        validateRole={validateRole}
        startEditingStatus={startEditingStatus}
        editingStatus={editingStatus}
        statusOptions={statusOptions}
        newStatus={newStatus}
        setNewStatus={setNewStatus}
        validateStatus={validateStatus}
        saveStatus={saveStatus}
        closeSensorDetails={closeSensorDetails}
      />
    ),
    [
      selectedSensor,
      editingStatus,
      newStatus,
      startEditingStatus,
      setNewStatus,
      validateStatus,
      saveStatus,
      closeSensorDetails,
    ],
  );

  // Render add new sensor modal content
  const renderAddNewSensor = useCallback(
    () => (
      <AddSensorComponent
        sensorNameOptions={sensorNameOptions}
        newSensor={newSensor}
        setNewSensor={setNewSensor}
        errors={errors}
        locationOptions={locationOptions}
        showDatePicker={showDatePicker}
        setShowDatePicker={setShowDatePicker}
        onDateChange={onDateChange}
        statusOptions={statusOptions}
        handleAddNewSensor={handleAddNewSensor}
        closeAddNewSensor={closeAddNewSensor}
      />
    ),
    [
      newSensor,
      errors,
      showDatePicker,
      setNewSensor,
      setShowDatePicker,
      onDateChange,
      handleAddNewSensor,
      closeAddNewSensor,
      language,
    ],
  );

  // Main render function
  return (
    <>
      <PageHeader title={PAGES.SENSOR} />
      {isAddingNewSensor || selectedSensor ? (
        <View></View>
      ) : (
        <View style={commonStyle.addButtonContainer}>
          <FwButtonPrimary
            mode="outlined"
            onPress={openAddNewSensor}
            icon="plus">
            <FwTextPrimary>{LanguageString('Add New')}</FwTextPrimary>
          </FwButtonPrimary>
        </View>
      )}
      <FlatList
        style={styles.container}
        data={sensors}
        renderItem={renderSensorCard}
        keyExtractor={(item, index) => index.toString()}
        ListEmptyComponent={ListEmptyComponent}
        maxToRenderPerBatch={10}
        windowSize={5}
        removeClippedSubviews={true}
        initialNumToRender={10}
        onEndReachedThreshold={0.5}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
        }
      />

      <FwModal
        visible={selectedSensor !== null}
        onDismiss={closeSensorDetails}
        contentContainerStyle={styles.modalContainer}>
        {selectedSensor && renderSensorDetails()}
      </FwModal>

      {snackbarVisible ? (
        <FwNotifyMessage
          type="success"
          visible={snackbarVisible}
          // onDismiss={() => setSnackbarVisible(false)}
        >
          <FwTextSecondary>
            {LanguageString('Updated Successfully')}
          </FwTextSecondary>
        </FwNotifyMessage>
      ) : null}

      {/* Add New Sensor Modal */}

      <FwModal
        visible={isAddingNewSensor}
        onDismiss={closeAddNewSensor}
        contentContainerStyle={styles.modalContainer}>
        {renderAddNewSensor()}
      </FwModal>

      {/* Delete Confirmation Dialog box */}
      <FwDialog
        visible={showDeleteDialog}
        hideDialog={closeDeleteDialog}
        title={LanguageString('Delete this Sensor?')}>
        <FwButtonPrimary mode="outlined" onPress={closeDeleteDialog}>
          <FwTextPrimary>{LanguageString('Cancel')}</FwTextPrimary>
        </FwButtonPrimary>
        <FwButtonPrimary mode="outlined" onPress={confirmDelete}>
          <FwTextPrimary>{LanguageString('Delete')}</FwTextPrimary>
        </FwButtonPrimary>
      </FwDialog>
    </>
  );
};

// Styles for the component
const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: normalized(16),
    backgroundColor: COLORS.OFF_WHITE,
  },
  sensorCard: {
    marginBottom: normalized(16),
    elevation: 2,
  },
  cardContent: {
    marginLeft: normalized(58),
    marginTop: normalized(-16),
  },
  modalContainer: {
    backgroundColor: COLORS.BG_WHITE,
    padding: normalized(24),
    margin: normalized(24),
    borderRadius: 8,
    elevation: 4,
    zIndex: 1000,
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: normalized(24),
  },
  modalTitle: {
    fontSize: normalized(20),
    fontWeight: 'bold',
    color: COLORS.BLACK,
  },

  modalContent: {
    color: COLORS.BLACK,
    lineHeight: 24,
  },

  dropdownContainer: {
    marginTop: normalized(16),
    marginLeft: normalized(20),
  },
  input: {
    marginBottom: normalized(8),
  },
  cardActions: {
    flexDirection: 'row',
  },
  appBar: {
    marginTop: 'auto',
  },
  noSensorsText: {
    textAlign: 'center',
    marginTop: normalized(20),
    fontSize: normalized(16),
    color: COLORS.BLACK,
  },
});

export default SensorScreenView;
