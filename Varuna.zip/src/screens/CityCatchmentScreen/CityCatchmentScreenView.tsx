import React, {useCallback, useMemo} from 'react';
import {ScrollView, View, StyleSheet, RefreshControl} from 'react-native';
import {Card, HelperText} from 'react-native-paper';

import {
  FwButtonPrimary,
  FwDialog,
  FwTextInputPrimary,
  FwTextPrimary,
  FwTextSecondary,
} from '../../elements';
import {CityCatchmentScreenProps} from '../../types/commonTypes';
import {
  floodRiskLevelOptions,
  waterBodiesOptions,
  runOfCoeffecientOptions,
  LanguageString,
  USER_ROLES,
} from '../../constants/data';
import {COLORS} from '../../constants/colors';
import FWDropdown from '../../elements/FwDropdown';
import {IMAGES} from '../../assets';
import PageHeader from '../../components/PageHeader';
import {useSelector} from 'react-redux';
import {RootState} from '../../store/store';
import {commonStyle} from '../../constants/theme';
import {normalized} from '../../constants/platform';
import FwImage from '../../elements/FwImage';
import FwModal from '../../elements/FwModal';
// Main component for the CityCatchment Screen
const CityCatchmentScreenView = ({
  selectedCityCatchment,
  refreshing,
  cityCatchments,
  newStatus,
  setNewStatus,
  editingStatus,
  isAddingNewCityCatchment,
  newCityCatchment,
  setNewCityCatchment,
  errors,
  openCityCatchmentDetails,
  onRefresh,
  startEditingStatus,
  handleDeleteCityCatchment,
  openAddNewCityCatchment,
  closeCityCatchmentDetails,
  validateStatus,
  saveStatus,
  closeAddNewCityCatchment,
  handleAddNewCityCatchment,
}: CityCatchmentScreenProps) => {
  // State for delete confirmation dialog
  const [showDeleteDialog, setShowDeleteDialog] = React.useState(false);
  const [cityCatchmentToDelete, setCityCatchmentToDelete] =
    React.useState(null);

  const locationOptions = [
    {label: LanguageString('Rapti Nagar'), value: 'Rapti Nagar'},
    {label: LanguageString('Om Nagar'), value: 'Om Nagar'},
    {label: LanguageString('Rasoolpur'), value: 'Rasoolpur'},
  ];
  const statusOptions = [
    {label: LanguageString('Active'), value: 'Active'},
    {label: LanguageString('Inactive'), value: 'Inactive'},
  ];
  // Open delete confirmation dialog
  const openDeleteDialog = useCallback((cityCatchment: any) => {
    setCityCatchmentToDelete(cityCatchment);
    setShowDeleteDialog(true);
  }, []);

  // Close delete confirmation dialog
  const closeDeleteDialog = useCallback(() => {
    setShowDeleteDialog(false);
    setCityCatchmentToDelete(null);
  }, []);

  const role = useSelector((state: RootState) => state.auth.userRole);

  const validateRole =
    role == USER_ROLES.ADMIN ||
    role == USER_ROLES.SUPER_ADMIN ||
    role == USER_ROLES.IT_SUPPORT;

  // Confirm cityCatchment deletion
  const confirmDelete = useCallback(() => {
    console.log('Deleting cityCatchment:', cityCatchmentToDelete);
    if (cityCatchmentToDelete) {
      handleDeleteCityCatchment(cityCatchmentToDelete);
    }
    closeDeleteDialog();
  }, [cityCatchmentToDelete, handleDeleteCityCatchment, closeDeleteDialog]);

  // Render individual cityCatchment card
  const renderCityCatchmentCard = useCallback(
    (cityCatchment: any, index: number) => (
      <Card
        key={index}
        style={styles.cityCatchmentCard}
        onPress={() => openCityCatchmentDetails(cityCatchment)}>
        <Card.Title
          title={LanguageString(cityCatchment.cityCatchmentAreaName)}
          titleStyle={commonStyle.cardHeaderText}
          left={() => (
            <View style={styles.cardImage}>
              <FwImage source={IMAGES.CITYADMIN} style={styles.cardImageIcon} />
            </View>
          )}
        />
        <Card.Content style={styles.cardContent}>
          <View style={commonStyle.modalRow}>
            <FwTextPrimary style={commonStyle.boldText}>
              {LanguageString('Location') + ' : '}
            </FwTextPrimary>
            <FwTextPrimary style={commonStyle.normalText}>
              {LanguageString(cityCatchment.location)}
            </FwTextPrimary>
          </View>
          <View style={commonStyle.modalRow}>
            <FwTextPrimary style={commonStyle.boldText}>
              {LanguageString('Average Rainfall') + ' : '}
            </FwTextPrimary>
            <FwTextPrimary style={commonStyle.normalText}>
              {LanguageString(cityCatchment.avgRainfall)}
            </FwTextPrimary>
          </View>
          <View style={commonStyle.modalRow}>
            <FwTextPrimary style={commonStyle.boldText}>
              {LanguageString('Flood Risk Level') + ' : '}
            </FwTextPrimary>
            <FwTextPrimary style={commonStyle.normalText}>
              {LanguageString(cityCatchment.floodRiskLevel)}
            </FwTextPrimary>
          </View>
        </Card.Content>
      </Card>
    ),
    [openCityCatchmentDetails, startEditingStatus, openDeleteDialog],
  );

  // Render a message if no cityCatchments
  const cityCatchmentCards = useMemo(() => {
    if (cityCatchments.length === 0) {
      return (
        <FwTextPrimary style={styles.cityCatchmentCardText}>
          {LanguageString('No City Catchment Area found')}
        </FwTextPrimary>
      );
    }
    return cityCatchments.map(renderCityCatchmentCard);
  }, [cityCatchments, renderCityCatchmentCard]);

  // Render cityCatchment details modal content
  const renderCityCatchmentDetails = useCallback(
    () => (
      <ScrollView>
        <View style={commonStyle.modalHeader}>
          <FwTextSecondary style={commonStyle.modalTitle}>
            {LanguageString('City Catchment Area Details')}
          </FwTextSecondary>
          {/* <IconButton icon="pencil" size={24} onPress={startEditingStatus} /> */}
        </View>

        {selectedCityCatchment && (
          <ScrollView>
            <View style={commonStyle.modalRow}>
              <FwTextPrimary style={commonStyle.boldText}>
                {LanguageString('Area Name')} :{' '}
              </FwTextPrimary>
              <FwTextPrimary style={commonStyle.normalText}>
                {LanguageString(selectedCityCatchment.cityCatchmentAreaName)}
              </FwTextPrimary>
            </View>
            <View style={commonStyle.modalRow}>
              <FwTextPrimary style={commonStyle.boldText}>
                {LanguageString('Location')} :{' '}
              </FwTextPrimary>
              <FwTextPrimary style={commonStyle.normalText}>
                {LanguageString(selectedCityCatchment.location)}
              </FwTextPrimary>
            </View>
            <View style={commonStyle.modalRow}>
              <FwTextPrimary style={commonStyle.boldText}>
                {LanguageString('Area Size')} :{' '}
              </FwTextPrimary>
              <FwTextPrimary style={commonStyle.normalText}>
                {LanguageString(selectedCityCatchment.areaSize)}
              </FwTextPrimary>
            </View>
            <View style={commonStyle.modalRow}>
              <FwTextPrimary style={commonStyle.boldText}>
                {LanguageString('Water Bodies')} :{' '}
              </FwTextPrimary>
              <FwTextPrimary style={commonStyle.normalText}>
                {LanguageString(selectedCityCatchment.waterBodies)}
              </FwTextPrimary>
            </View>
            <View style={commonStyle.modalRow}>
              <FwTextPrimary style={commonStyle.boldText}>
                {LanguageString('Run of Coeffecient')} :{' '}
              </FwTextPrimary>
              <FwTextPrimary style={commonStyle.normalText}>
                {LanguageString(selectedCityCatchment.runOfCoeffecient)}
              </FwTextPrimary>
            </View>
            <View style={commonStyle.modalRow}>
              <FwTextPrimary style={commonStyle.boldText}>
                {LanguageString('Average Rainfall')} :{' '}
              </FwTextPrimary>
              <FwTextPrimary style={commonStyle.normalText}>
                {LanguageString(selectedCityCatchment.avgRainfall)}
              </FwTextPrimary>
            </View>
            <View style={commonStyle.modalRow}>
              <FwTextPrimary style={commonStyle.boldText}>
                {LanguageString('Drainage Capacity')} :{' '}
              </FwTextPrimary>
              <FwTextPrimary style={commonStyle.normalText}>
                {LanguageString(selectedCityCatchment.drainageCapacity)}
              </FwTextPrimary>
            </View>
            <View style={commonStyle.modalRow}>
              <FwTextPrimary style={commonStyle.boldText}>
                {LanguageString('Flood Risk Level')} :{' '}
              </FwTextPrimary>
              <FwTextPrimary style={commonStyle.normalText}>
                {LanguageString(selectedCityCatchment.floodRiskLevel)}
              </FwTextPrimary>
            </View>
          </ScrollView>
        )}
        {editingStatus && (
          <FWDropdown
            multiple={false}
            label={LanguageString('Select Status')}
            options={statusOptions}
            value={newStatus}
            onSelect={(value: string | undefined) => {
              if (value !== undefined) {
                setNewStatus(value);
                validateStatus(value);
              }
            }}
          />
        )}
        {editingStatus && (
          <FwButtonPrimary onPress={saveStatus} style={commonStyle.saveButton}>
            <FwTextSecondary>{LanguageString('Save')}</FwTextSecondary>
          </FwButtonPrimary>
        )}
        <FwButtonPrimary
          onPress={closeCityCatchmentDetails}
          style={commonStyle.closeButton}>
          <FwTextSecondary>{LanguageString('Cancel')}</FwTextSecondary>
        </FwButtonPrimary>
      </ScrollView>
    ),
    [
      selectedCityCatchment,
      editingStatus,
      newStatus,
      startEditingStatus,
      setNewStatus,
      validateStatus,
      saveStatus,
      closeCityCatchmentDetails,
    ],
  );

  // Render add new cityCatchment modal content
  const renderAddNewCityCatchment = useCallback(
    () => (
      <ScrollView>
        <View style={commonStyle.modalHeader}>
          <FwTextPrimary style={commonStyle.modalTitle}>
            {LanguageString('Add New City Catchment Area')}
          </FwTextPrimary>
        </View>

        <FWDropdown
          multiple={false}
          label={LanguageString('Select Location')}
          options={locationOptions}
          value={newCityCatchment?.location}
          onSelect={(value: string | undefined) => {
            if (value !== undefined) {
              setNewCityCatchment({...newCityCatchment, location: value});
            }
          }}
        />
        <HelperText type="error" visible={!!errors.location}>
          {errors.location}
        </HelperText>

        <FwTextInputPrimary
          label={LanguageString('Enter City Catchment Area Name')}
          value={newCityCatchment?.cityCatchmentAreaName}
          onChangeText={text =>
            setNewCityCatchment({
              ...newCityCatchment,
              cityCatchmentAreaName: text,
            })
          }
          style={styles.input}
          error={!!errors.cityCatchmentAreaName}
        />
        <HelperText type="error" visible={!!errors.cityCatchmentAreaName}>
          {LanguageString(errors.cityCatchmentAreaName)}
        </HelperText>

        <FwTextInputPrimary
          label={LanguageString('Area Size')}
          value={newCityCatchment?.areaSize}
          onChangeText={text =>
            setNewCityCatchment({...newCityCatchment, areaSize: text})
          }
          style={styles.input}
          error={!!errors.areaSize}
        />
        <HelperText type="error" visible={!!errors.areaSize}>
          {LanguageString(errors.areaSize)}
        </HelperText>

        <FWDropdown
          multiple={true}
          label={LanguageString('Select Water Bodies')}
          options={waterBodiesOptions}
          value={newCityCatchment?.waterBodies}
          onSelect={(value: string | undefined) => {
            if (value !== undefined) {
              setNewCityCatchment({
                ...newCityCatchment,
                waterBodies: value,
              });
            }
          }}
        />
        <HelperText type="error" visible={!!errors.waterBodies}>
          {LanguageString(errors.waterBodies)}
        </HelperText>

        <FWDropdown
          multiple={false}
          label={LanguageString('Select Run Of Co-effecient')}
          options={runOfCoeffecientOptions}
          value={newCityCatchment?.runOfCoeffecient}
          onSelect={(value: string | undefined) => {
            if (value !== undefined) {
              setNewCityCatchment({
                ...newCityCatchment,
                runOfCoeffecient: value,
              });
            }
          }}
        />
        <HelperText type="error" visible={!!errors.runOfCoeffecient}>
          {LanguageString(errors.runOfCoeffecient)}
        </HelperText>

        <FwTextInputPrimary
          label={LanguageString('Average Rainfall')}
          value={newCityCatchment?.avgRainfall}
          onChangeText={text =>
            setNewCityCatchment({...newCityCatchment, avgRainfall: text})
          }
          style={styles.input}
          error={!!errors.avgRainfall}
        />
        <HelperText type="error" visible={!!errors.avgRainfall}>
          {LanguageString(errors.avgRainfall)}
        </HelperText>

        <FwTextInputPrimary
          label={LanguageString('Drainage Capacity')}
          value={newCityCatchment?.drainageCapacity}
          onChangeText={text =>
            setNewCityCatchment({...newCityCatchment, drainageCapacity: text})
          }
          style={styles.input}
          error={!!errors.drainageCapacity}
        />
        <HelperText type="error" visible={!!errors.drainageCapacity}>
          {LanguageString(errors.drainageCapacity)}
        </HelperText>

        <FWDropdown
          multiple={false}
          label={LanguageString('Select Flood Risk Level')}
          options={floodRiskLevelOptions}
          value={LanguageString(newCityCatchment?.floodRiskLevel)}
          onSelect={(value: string | undefined) => {
            if (value !== undefined) {
              setNewCityCatchment({
                ...newCityCatchment,
                floodRiskLevel: value,
              });
            }
          }}
        />
        <HelperText type="error" visible={!!errors.floodRiskLevel}>
          {LanguageString(errors.floodRiskLevel)}
        </HelperText>

        <FwButtonPrimary
          onPress={handleAddNewCityCatchment}
          style={commonStyle.saveButton}>
          <FwTextSecondary>{LanguageString('Save')}</FwTextSecondary>
        </FwButtonPrimary>
        <FwButtonPrimary
          onPress={closeAddNewCityCatchment}
          style={commonStyle.closeButton}>
          <FwTextSecondary>{LanguageString('Cancel')}</FwTextSecondary>
        </FwButtonPrimary>
      </ScrollView>
    ),
    [
      newCityCatchment,
      errors,
      setNewCityCatchment,
      handleAddNewCityCatchment,
      closeAddNewCityCatchment,
    ],
  );

  // Main render function
  return (
    <>
      <PageHeader title={LanguageString('City Catchment Area')} />
      <ScrollView
        style={styles.container}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
        }>
        {cityCatchmentCards}
        {/* <View style={styles.addButtonContainer}>
          <FwButtonPrimary
            mode="contained"
            onPress={openAddNewCityCatchment}
            icon="plus">
            <FwTextSecondary>{LanguageString('Add New')}</FwTextSecondary>
          </FwButtonPrimary>
        </View> */}
      </ScrollView>
      {/* CityCatchment Details Modal */}
      <FwModal
        visible={selectedCityCatchment !== null}
        onDismiss={closeCityCatchmentDetails}
        contentContainerStyle={styles.modalContainer}>
        {selectedCityCatchment && renderCityCatchmentDetails()}
      </FwModal>
      {/* Add New CityCatchment Modal */}
      <FwModal
        visible={isAddingNewCityCatchment}
        onDismiss={closeAddNewCityCatchment}
        contentContainerStyle={styles.modalContainer}>
        {renderAddNewCityCatchment()}
      </FwModal>
      {/* Delete Confirmation Dialog */}
      <FwDialog
        visible={showDeleteDialog}
        hideDialog={closeDeleteDialog}
        title={'Delete City Catchment'}
        description={'Are you sure you want to delete this cityCatchment?'}>
        <FwButtonPrimary mode="outlined" onPress={closeDeleteDialog}>
          <FwTextPrimary>{LanguageString('Cancel')}</FwTextPrimary>
        </FwButtonPrimary>
        <FwButtonPrimary mode="outlined" onPress={confirmDelete}>
          <FwTextPrimary>{LanguageString('Delete')}</FwTextPrimary>
        </FwButtonPrimary>
      </FwDialog>
    </>
  );
};

// Styles for the component
const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: normalized(16),
    backgroundColor: COLORS.OFF_WHITE,
  },
  title: {
    fontSize: normalized(24),
    fontWeight: 'bold',
    marginBottom: normalized(16),
    color: COLORS.BLACK,
  },
  subtitle: {
    fontSize: normalized(18),
    marginBottom: normalized(16),
    color: COLORS.BLACK,
  },
  cityCatchmentCard: {
    marginBottom: normalized(16),
    elevation: 2,
    backgroundColor: COLORS.BG_WHITE,
  },
  cardText: {
    color: COLORS.BLACK,
  },
  addButtonContainer: {
    marginVertical: normalized(24),
    alignItems: 'center',
  },
  cardContent: {
    marginLeft: normalized(58),
    marginTop: normalized(-16),
  },
  modalContainer: {
    backgroundColor: COLORS.BG_WHITE,
    padding: normalized(24),
    margin: normalized(24),
    borderRadius: normalized(8),
    elevation: normalized(4),
  },

  modalContent: {
    color: COLORS.BLACK,
    lineHeight: normalized(24),
  },

  dropdownContainer: {
    marginTop: normalized(16),
    marginLeft: normalized(20),
  },
  input: {
    marginBottom: normalized(8),
  },
  cardActions: {
    flexDirection: 'row',
  },
  cardImage: {
    width: normalized(50),
    height: normalized(50),
    borderRadius: normalized(50),
    marginRight: normalized(16),
    marginTop: normalized(50),
  },
  cardImageIcon: {
    width: normalized(50),
    height: normalized(50),
    borderRadius: normalized(50),
    marginRight: normalized(16),
  },
  noCityCatchmentsText: {
    textAlign: 'center',
    marginTop: normalized(20),
    fontSize: normalized(16),
    color: COLORS.BLACK,
  },
  cityCatchmentCardContent: {
    marginLeft: normalized(58),
    marginTop: normalized(-16),
  },
  cityCatchmentCardText: {
    color: COLORS.BLACK,
  },
  intenanceCardActions: {
    flexDirection: 'row',
  },
  cityCatchmentCardActionsButton: {
    margin: normalized(8),
  },
  intenanceCardActionsButtonText: {
    color: COLORS.BLACK,
  },
  cityCatchmentCardActionsButtonText: {
    color: COLORS.BLACK,
  },
});

export default CityCatchmentScreenView;
