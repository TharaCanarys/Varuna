import React, {useCallback, useState, useRef} from 'react';
import {createStackNavigator} from '@react-navigation/stack';
import {
  NavigationContainer,
  useNavigation,
  CommonActions,
} from '@react-navigation/native';
import {useDispatch, useSelector} from 'react-redux';
import {RootState} from '../store/store';
import {
  HomeScreen,
  LoginScreen,
  SignupScreen,
  SplashScreen,
  ProfileScreen,
  LanguageSelectionScreen,
  NotificationScreen,
  TaskHistory,
  AddIncident,
} from '../screens';
import {Snackbar, Divider, List} from 'react-native-paper';
import {PAGES} from '../components/pages';
import {COLORS} from '../constants/colors';
import {View, StyleSheet} from 'react-native';
import FwTextPrimary from '../elements/FwTextPrimary.tsx';
import {removeToken} from '../services/authService.ts';
import {logout} from '../utils/navigation';
import {LanguageString} from '../constants/data.tsx';
import FwDialog from '../elements/FwDialog.tsx';
import FwButtonPrimary from '../elements/FwButtonPrimary.tsx';
import {normalized} from '../constants/platform.tsx';
import AppDrawer from './AppDrawer.tsx';
import {HeaderBanner} from '../components/HeaderBanner.tsx';
import {AppbarTop} from '../components/AppBar.tsx';
import FwModal from '../elements/FwModal.tsx';
import { setNotificationVisible } from '../store/appSlice.ts';
const Stack = createStackNavigator();

const AppNavigator: React.FC = () => {
  const role = useSelector((state: RootState) => state.auth.userRole);
  const id = useSelector((state: RootState) => state.auth.userId);
  const token = useSelector((state: RootState) => state.auth.token);
  // const language = useSelector(
  //   (state: RootState) => state.app.selectedLanguage,
  // );
  const DrawerNavigator = () => {
    const navigation = useNavigation();
    const dispatch = useDispatch();
    const [visible, setVisibleMenu] = useState(false);
    const [visibleSearch, setVisibleSearch] = useState(false);
    const [searchQuery, setSearchQuery] = useState('');
    // const [notificationVisible, setNotificationVisible] = useState(false);
    const [logoutDialogVisible, setLogoutDialogVisible] = useState(false);

    const toggleMenu = () => setVisibleMenu(!visible);
    const notificationVisible = useSelector((state: RootState) => state.app.notificationVisible);
    const snackMessage = useSelector((state: RootState) => state.app.snackMessage);
    // const handleSettings = () => {
    //   toggleMenu();
    //   console.log('Settings pressed');
    // };
    const handleNavProfile = () => {
      toggleMenu();
      navigation.navigate(PAGES.PROFILE as never);
    };
    const handleLogout = async () => {
      toggleMenu();
      setLogoutDialogVisible(true);
    };
    const confirmLogout = async () => {
      console.log('Logout pressed');
      await logout(navigation);
      setLogoutDialogVisible(false);
    };

    const menuItems = [
      {title: 'UserProfile', icon: 'account', onPress: handleNavProfile},
      // {title: 'Settings', icon: 'cog', onPress: handleSettings},
      {title: 'Logout', icon: 'logout', onPress: handleLogout},
    ];

    return (
      <>
        <AppDrawer
          dispatch={dispatch}
          toggleMenu={toggleMenu}
          visibleSearch={visibleSearch}
          searchQuery={searchQuery}
          setSearchQuery={setSearchQuery}
          role={role}
        />
        <FwModal
          visible={visible}
          onDismiss={toggleMenu}
          dismissable={true}
          contentContainerStyle={styles.modalContent}>
          <FwTextPrimary style={styles.modalHeader}>
            {LanguageString('Menu')}
          </FwTextPrimary>
          <Divider style={styles.divider} />
          {menuItems.map((item, index) => (
            <React.Fragment key={index}>
              <List.Item
                title={LanguageString(item.title)}
                left={props => <List.Icon {...props} icon={item.icon} />}
                onPress={item.onPress}
              />
              <Divider style={styles.divider} />
            </React.Fragment>
          ))}
        </FwModal>
        <FwDialog
          visible={logoutDialogVisible}
          hideDialog={() => setLogoutDialogVisible(false)}
          title={LanguageString('Logout Confirmation') + '?'}>
          <FwButtonPrimary
            mode="outlined"
            onPress={() => setLogoutDialogVisible(false)}>
            <FwTextPrimary>{LanguageString('Cancel')}</FwTextPrimary>
          </FwButtonPrimary>
          <FwButtonPrimary mode="outlined" onPress={confirmLogout}>
            <FwTextPrimary>{LanguageString('Confirm')}</FwTextPrimary>
          </FwButtonPrimary>
        </FwDialog>
        {/* <Snackbar
          visible={notificationVisible}
          onDismiss={() => dispatch(setNotificationVisible(false))}
          action={{
            label: 'Close',
            onPress: () => dispatch(setNotificationVisible(false)),
          }}
          style={styles.snackbar}>
          {LanguageString(snackMessage)}
        </Snackbar> */}
      </>
    );
  };

  // Main app navigation structure
  const stackScreens = [
    {
      name: PAGES.SPLASH,
      component: SplashScreen,
      options: {headerShown: false},
    },
    {name: PAGES.LOGIN, component: LoginScreen, options: {headerShown: false}},
    {
      name: PAGES.SIGNUP,
      component: SignupScreen,
      options: {headerShown: false},
    },
    {
      name: PAGES.NOTIFICATIONS,
      component: NotificationScreen,
      options: {headerShown: false},
    },
    {
      name: PAGES.PROFILE,
      component: ProfileScreen,
      options: {headerShown: false},
    },
    {
      name: PAGES.HOME,
      component: HomeScreen,
      options: {headerShown: false},
    },
    {
      name: PAGES.TASKS_HISTORY,
      component: TaskHistory,
      options: {headerShown: false},
    },
    {
      name: PAGES.DASHBOARD_NAV,
      component: DrawerNavigator,
      options: {headerShown: false},
    },
    {
      name: PAGES.LANGUAGE_SELECTION,
      component: LanguageSelectionScreen,
      options: {headerShown: false},
    },
    {
      name: PAGES.ADDINCIDENT,
      component: AddIncident,
      options: {headerShown: false},
    },
  ];

  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName={PAGES.LANGUAGE_SELECTION}>
        {stackScreens.map((screen, index) => (
          <Stack.Screen
            key={index}
            name={screen.name}
            component={screen.component as React.ComponentType<any>}
            options={screen.options}
          />
        ))}
      </Stack.Navigator>
    </NavigationContainer>
  );
};

// Styles
const styles = StyleSheet.create({
  container: {
    flex: 1,
  },

  appBar: {
    backgroundColor: COLORS.PRIMARY,
    height: normalized(45),
    marginTop: normalized(-0),
    elevation: normalized(4),
  },
  appBarContent: {
    color: COLORS.SECONDARY,
  },

  snackbar: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
  },

  modalContent: {
    backgroundColor: 'white',
    padding: normalized(10),
    margin: normalized(20),
    position: 'absolute',
    top: normalized(115),
    elevation: normalized(4),
    borderRadius: normalized(8),
    right: 0,
  },
  modalHeader: {
    fontSize: normalized(13),
    fontWeight: 'bold',
    marginBottom: normalized(5),
  },
  divider: {
    marginVertical: normalized(5),
  },
});
export default AppNavigator;
