import React from 'react';
import {Card} from 'react-native-paper';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import {FwTextPrimary} from '../../elements';
import {LanguageString} from '../../constants/data';
import {View} from 'react-native';
import {normalized} from '../../constants/platform';
import {COLORS} from '../../constants/colors';

const SensorDataComponent = ({styles, dummyData}: any) => {
  return (
    <Card style={styles.card}>
      <Card.Content>
        <FwTextPrimary style={styles.cardTitle}>
          {LanguageString('Sensor Data')}
        </FwTextPrimary>
        
        <View style={styles.detailRow}>
          <MaterialCommunityIcons
            name="radar"
            size={normalized(20)}
            color={COLORS.PRIMARY}
          />
          <FwTextPrimary style={styles.detailText}>
            {LanguageString('Radar Detection')}:
          </FwTextPrimary>
          <FwTextPrimary style={styles.valueText}>
            {LanguageString(dummyData.sensorData.radarDetection)}
          </FwTextPrimary>
        </View>
        <View style={styles.detailRow}>
          <MaterialCommunityIcons
            name="wave"
            size={normalized(20)}
            color={COLORS.PRIMARY}
          />
          <FwTextPrimary style={styles.detailText}>
            {LanguageString('Flow Rate')}:
          </FwTextPrimary>
          <FwTextPrimary style={styles.valueText}>
            {dummyData.sensorData.flowRate}
          </FwTextPrimary>
        </View>
      </Card.Content>
    </Card>
  );
};

export default SensorDataComponent;
