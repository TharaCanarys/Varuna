import React from 'react';
import {StyleSheet, View} from 'react-native';
import {IconButton} from 'react-native-paper';
import {FwButtonPrimary, FwTextPrimary, FwTextSecondary} from '../../elements';
import {LanguageString} from '../../constants/data';
import {commonStyle} from '../../constants/theme';
import FWDropdown from '../../elements/FwDropdown';
import {normalized} from '../../constants/platform';
import {COLORS} from '../../constants/colors';
import FwModal from '../../elements/FwModal';

const EscalationDetailsModal = ({
  selectedEscalation,
  closeEscalationDetails,
  validateRole,
  startEditingStatus,
  editingStatus,
  newStatus,
  setNewStatus,
  validateStatus,
  saveStatus,
}: any) => {
  const statusOptions = [
    {label: LanguageString('Pending'), value: 'Pending'},
    {label: LanguageString('In progress'), value: 'In progress'},
    {label: LanguageString('Closed'), value: 'Closed'},
  ];
  return (
    <FwModal
      visible={selectedEscalation !== null}
      onDismiss={closeEscalationDetails}
      contentContainerStyle={styles.modalContainer}>
      {selectedEscalation && (
        <>
          <View style={commonStyle.modalHeader}>
            <FwTextPrimary style={commonStyle.modalTitle}>
              {LanguageString('Escalation Details')}
            </FwTextPrimary>
            {validateRole ? (
              <IconButton
                icon="pencil"
                size={24}
                onPress={startEditingStatus}
                disabled={selectedEscalation.status === 'Closed'}
              />
            ) : null}
          </View>

          <>
            <View style={commonStyle.modalRow}>
              <FwTextPrimary style={commonStyle.boldText}>
                {LanguageString('Escalation Name')} :{' '}
              </FwTextPrimary>
              <FwTextPrimary style={commonStyle.normalText}>
                {LanguageString(selectedEscalation.escalationName) +
                  ' ' +
                  selectedEscalation.id}
              </FwTextPrimary>
            </View>
            {/* {'\n'} */}
            <View style={commonStyle.modalRow}>
              <FwTextPrimary style={commonStyle.boldText}>
                {LanguageString('Escalated By')} :{' '}
              </FwTextPrimary>
              <FwTextPrimary style={commonStyle.normalText}>
                {LanguageString(selectedEscalation.escalatedBy)}
              </FwTextPrimary>
            </View>
            {/* {'\n'} */}
            <View style={commonStyle.modalRow}>
              <FwTextPrimary style={commonStyle.boldText}>
                {LanguageString('Escalation Date/Time')} :{' '}
              </FwTextPrimary>
              <FwTextPrimary style={commonStyle.normalText}>
                {LanguageString(selectedEscalation.escalationTime)}
              </FwTextPrimary>
            </View>
            {/* {'\n'} */}
            <View style={commonStyle.modalRow}>
              <FwTextPrimary style={commonStyle.boldText}>
                {LanguageString('Escalation level')} :{' '}
              </FwTextPrimary>
              <FwTextPrimary style={commonStyle.normalText}>
                {LanguageString(selectedEscalation.escalationLevel) + ' ' + 1}
              </FwTextPrimary>
            </View>
            {/* {'\n'} */}
            <View style={commonStyle.modalRow}>
              <FwTextPrimary style={commonStyle.boldText}>
                {LanguageString('Escalation type')} :{' '}
              </FwTextPrimary>
              <FwTextPrimary style={commonStyle.normalText}>
                {LanguageString(selectedEscalation.escalationType)}
              </FwTextPrimary>
            </View>
            {/* {'\n'} */}
            <View style={commonStyle.modalRow}>
              <FwTextPrimary style={commonStyle.boldText}>
                {LanguageString('Resolution Time')} :{' '}
              </FwTextPrimary>
              <FwTextPrimary style={commonStyle.normalText}>
                {LanguageString(selectedEscalation.resulationTime)}
              </FwTextPrimary>
            </View>
            {/* {'\n'} */}
            <View style={commonStyle.modalRow}>
              <FwTextPrimary style={commonStyle.boldText}>
                {LanguageString('Status')} :{' '}
              </FwTextPrimary>
              <FwTextPrimary style={commonStyle.normalText}>
                {!editingStatus && LanguageString(selectedEscalation.status)}
              </FwTextPrimary>
            </View>
            {/* {'\n'} */}
          </>
          {editingStatus && selectedEscalation.status !== 'Closed' && (
            <FWDropdown
              multiple={false}
              label={LanguageString('Select Status')}
              options={statusOptions}
              value={newStatus}
              onSelect={(value: string | undefined) => {
                if (value !== undefined) {
                  setNewStatus(value);
                  validateStatus(value);
                }
              }}
            />
          )}
          {editingStatus && selectedEscalation.status !== 'Closed' && (
            <FwButtonPrimary
              onPress={saveStatus}
              style={commonStyle.saveButton}>
              <FwTextSecondary>{LanguageString('Save')}</FwTextSecondary>
            </FwButtonPrimary>
          )}
          <FwButtonPrimary
            onPress={closeEscalationDetails}
            style={commonStyle.closeButton}>
            <FwTextSecondary>{LanguageString('Cancel')}</FwTextSecondary>
          </FwButtonPrimary>
        </>
      )}
    </FwModal>
  );
};
export default EscalationDetailsModal;

const styles = StyleSheet.create({
  modalContainer: {
    backgroundColor: COLORS.BG_WHITE,
    padding: normalized(24),
    margin: normalized(24),
    borderRadius: normalized(8),
    elevation: normalized(4),
  },
  dropdownContainer: {
    marginTop: normalized(16),
    marginLeft: normalized(20),
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: normalized(24),
  },
  modalTitle: {
    fontSize: normalized(20),
    fontWeight: 'bold',
    color: COLORS.BLACK,
  },
});
