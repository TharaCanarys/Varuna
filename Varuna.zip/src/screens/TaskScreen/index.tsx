import React, {useEffect, useMemo, useState, useCallback} from 'react';
import TaskScreenView from './TaskScreenView';
import {TaskTypes, TaskStatus, TaskHistoryTypes, ErrorState} from '../../types/commonTypes';
import {getAllUsers, getTasks} from '../../services/apiServices';
import { useDispatch } from 'react-redux';
import { setUsers } from '../../store/appSlice';
import { User } from '../../types/userTypes';

export interface TaskScreenProps {
  selectedTask: TaskTypes | null;
  tasks: TaskTypes[];
  newTask: TaskTypes;
  updateTaskState: (field: keyof TaskTypes, value: any) => void;
  setNewTask: (task: TaskTypes) => void;
  errors: ErrorState;
  editingStatus: boolean;
  newStatus: string;
  setNewStatus: (status: string) => void;
  isAddingNewTask: boolean;
  setTaskToDelete: (task: TaskTypes | null) => void;
  setDeleteConfirmationVisible: (visible: boolean) => void;
  taskToDelete: TaskTypes | null;
  deleteConfirmationVisible: boolean;
  setRefreshing: (refreshing: boolean) => void;
  setSelectedTask: (task: TaskTypes | null) => void;
  setTasks: (tasks: TaskTypes[]) => void;
  setIsAddingNewTask: (isAddingNewTask: boolean) => void;
  setEditingStatus: (editing: boolean) => void;
  setStatusError: (error: string) => void;
  isDetailsVisible: boolean;
  setDetailsVisible: (visible: boolean) => void;
  refreshing: boolean;
  setErrors: (errors: ErrorState) => void;
  setShowTaskHistory: (visible: boolean) => void;
  showTaskHistory: boolean;
  setShowDeleteConfirmation: (visible: boolean) => void;
  showDeleteConfirmation: boolean;
}

const TaskScreen: React.FC = () => {
  const [selectedTask, setSelectedTask] = useState<TaskTypes | null>(null);
  const [editingStatus, setEditingStatus] = useState<boolean>(false);
  const [newStatus, setNewStatus] = useState<string>('');
  const [statusError, setStatusError] = useState<string>('');
  const [tasks, setTasks] = useState<TaskTypes[]>([]);
  const [newTask, setNewTask] = useState<TaskTypes>({
    taskID: '',
    description: '',
    assignedToUserID: '',
    createdByUserID: '',
    status: TaskStatus.ASSIGNED,
    creationDate: '',
    manualIncidentEntryId: '',
    taskHistory: []
  });
  const [errors, setErrors] = useState<ErrorState>({
    description: '',
    assignedToUserID: '',
    createdByUserID: '',
    status: '',
    creationDate: '',
    manualIncidentEntryId: '',
    taskHistory: []
  });
  const [isAddingNewTask, setIsAddingNewTask] = useState(false);
  const [taskToDelete, setTaskToDelete] = useState<TaskTypes | null>(null);
  const [deleteConfirmationVisible, setDeleteConfirmationVisible] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [isDetailsVisible, setDetailsVisible] = useState(false);
  const [showTaskHistory, setShowTaskHistory] = useState(false);
  const [loading, setLoading] = useState(false);
  const [showDeleteConfirmation, setShowDeleteConfirmation] = useState(false);

  const dispatch = useDispatch();

  const updateTaskState = useCallback((field: keyof TaskTypes, value: any) => {
    setNewTask(prev => ({
      ...prev,
      [field]: value
    }));
  }, []);

  const onGetSuccess = useCallback((data: any) => {
    setTasks(data);
    fetchUsers();
    setLoading(false);
  }, []);

   const fetchUsers = async (): Promise<void> => {
        try {
          const response = await getAllUsers();
          if (response?.data) {
            dispatch(setUsers(response.data as User[]));
          }
        } catch (error: unknown) {
          console.error('Error fetching users:', error);
        }
      };
  
  const onGetFailed = useCallback((error: any) => {
    console.error('Error fetching tasks:', error);
    setLoading(false);
  }, []);

  useEffect(() => {
    const payload = [0];
    getTasks(payload, setLoading, onGetSuccess, onGetFailed);
  }, []);

  const taskScreenProps: TaskScreenProps = {
    selectedTask,
    tasks,
    newTask,
    updateTaskState,
    setNewTask,
    errors,
    editingStatus,
    newStatus,
    setNewStatus,
    isAddingNewTask,
    setTaskToDelete,
    setDeleteConfirmationVisible,
    taskToDelete,
    deleteConfirmationVisible,
    setRefreshing,
    setSelectedTask,
    setTasks,
    setIsAddingNewTask,
    setEditingStatus,
    setStatusError,
    isDetailsVisible,
    setDetailsVisible,
    refreshing,
    setErrors,
    setShowTaskHistory,
    showTaskHistory,
    setShowDeleteConfirmation,
    showDeleteConfirmation
  };

  return <TaskScreenView {...taskScreenProps} />;
};
export default TaskScreen;
