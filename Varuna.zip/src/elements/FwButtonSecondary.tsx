import React from 'react';
import {StyleSheet} from 'react-native';
import {Button} from 'react-native-paper';
import {COLORS} from '../constants/colors';

export default function FwButtonSecondary(props: any) {
  const {children, mode, icon} = props;

  return (
    <Button
      {...props}
      icon={icon}
      mode={mode}
      uppercase={false}
      style={[
        styles.buttonStyle,
        {
          borderWidth: mode == 'outlined' ? 1 : 0,
          borderColor: COLORS.LIGHTGRAY,
          height: mode == 'outlined' ? 40 : 50,
          borderRadius: mode == 'outlined' ? 20 : 8,
          paddingHorizontal: mode == 'outlined' && 10,
          marginHorizontal: mode != 'outlined' && 8,
          backgroundColor:
            mode == 'outlined' ? COLORS.TRANSPARENT : COLORS.SECONDARY,

          ...props.style,
        },
      ]}>
      {children}
    </Button>
  );
}
const styles = StyleSheet.create({
  buttonStyle: {
    textAlign: 'center',
    justifyContent: 'center',
  },
});
