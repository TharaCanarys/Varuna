import React from 'react';
import {View} from 'react-native';
import {commonStyle} from '../../constants/theme';
import {FwButtonPrimary, FwTextPrimary, FwTextSecondary} from '../../elements';
import {LanguageString} from '../../constants/data';
import FWDropdown from '../../elements/FwDropdown';
import {HelperText} from 'react-native-paper';
import FwDateTimePicker from '../../elements/FwDateTimePicker';

interface AddSensorComponentProps {
  sensorNameOptions: any[];
  newSensor: any;
  setNewSensor: (value: any) => void;
  errors: any;
  locationOptions: any[];
  showDatePicker: boolean;
  setShowDatePicker: (value: boolean) => void;
  onDateChange: (date: Date) => void;
  statusOptions: any[];
  handleAddNewSensor: () => void;
  closeAddNewSensor: () => void;
}

const AddSensorComponent = ({
  sensorNameOptions,
  newSensor,
  setNewSensor,
  errors,
  locationOptions,
  showDatePicker,
  setShowDatePicker,
  onDateChange,
  statusOptions,
  handleAddNewSensor,
  closeAddNewSensor,
}: AddSensorComponentProps) => {
  return (
    <>
      <View style={commonStyle.modalHeader}>
        <FwTextPrimary style={commonStyle.modalTitle}>
          {LanguageString('Add New Sensor')}
        </FwTextPrimary>
      </View>
      <FWDropdown
        multiple={false}
        label={LanguageString('Select Sensor')}
        options={sensorNameOptions}
        value={newSensor.sensorName}
        onSelect={(value: string | undefined) => {
          if (value !== undefined) {
            setNewSensor({...newSensor, sensorName: value});
          }
        }}
      />
      <HelperText type="error" visible={!!errors.sensorName}>
        {errors.sensorName}
      </HelperText>
      <FWDropdown
        multiple={false}
        label={LanguageString('Select Location')}
        options={locationOptions}
        value={newSensor.locationName}
        onSelect={(value: string | undefined) => {
          if (value !== undefined) {
            setNewSensor({...newSensor, locationName: value});
          }
        }}
      />

      <HelperText type="error" visible={!!errors.location}>
        {errors.location}
      </HelperText>

      <FwDateTimePicker
        isVisible={showDatePicker && showDatePicker}
        label="Installation Date"
        onPress={() => setShowDatePicker(true)}
        onConfirm={onDateChange}
        onCancel={() => setShowDatePicker(false)}
        value={newSensor.installedDate}
        mode="date"
        minimumDate={new Date()}
      />
      <HelperText type="error" visible={!!errors.installedDate}>
        {errors.installedDate}
      </HelperText>

      <FWDropdown
        multiple={false}
        label={LanguageString('Select Status')}
        options={statusOptions.map(option => ({
          ...option,
          value: option.value.toString(),
        }))}
        value={newSensor.status}
        onSelect={(value: string | undefined) => {
          if (value !== undefined) {
            setNewSensor({...newSensor, status: value});
          }
        }}
      />
      <HelperText type="error" visible={!!errors.status}>
        {errors.status}
      </HelperText>
      <FwButtonPrimary
        onPress={handleAddNewSensor}
        style={commonStyle.saveButton}>
        <FwTextSecondary>{LanguageString('Save')}</FwTextSecondary>
      </FwButtonPrimary>
      <FwButtonPrimary
        onPress={closeAddNewSensor}
        style={commonStyle.closeButton}>
        <FwTextSecondary>{LanguageString('Cancel')}</FwTextSecondary>
      </FwButtonPrimary>
    </>
  );
};

export default AddSensorComponent;
