import React from 'react';
import {Text, TouchableOpacity} from 'react-native';
import {COLORS} from '../constants/colors';
import {FwLinkPrimaryProps} from '../types/commonTypes';

/**
 * FwLinkPrimary component
 * Renders a primary link as a touchable text
 * @param {FwLinkPrimaryProps} props - Component props
 * @returns {React.ReactElement} Rendered component
 */

const FwLinkPrimary: React.FC<FwLinkPrimaryProps> = ({
  children,
  style,
  onPress,
}) => {
  return (
    <TouchableOpacity onPress={onPress}>
      <Text style={[style, {color: COLORS.PRIMARY}]}>{children}</Text>
    </TouchableOpacity>
  );
};

export default FwLinkPrimary;
