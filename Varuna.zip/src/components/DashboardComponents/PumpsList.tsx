import React from 'react';
import {View} from 'react-native';
import {Card, Paragraph} from 'react-native-paper';
import {ICONS} from '../../assets';
import {COLORS} from '../../constants/colors';
import {LanguageString} from '../../constants/data';
import {commonStyle} from '../../constants/theme';

const PumpsList = ({data, renderIcon}: {data: any; renderIcon: any}) => {
  const pumpsData = [
    {
      icon: ICONS.ELECTRICPUMP,
      value: data?.waterPumpCount,
      label: 'Water Pump',
    },
    {
      icon: ICONS.PUMPLIST,
      value: data?.vacuumPumpCount,
      label: 'Vaccume Pump',
    },
    {
      icon: ICONS.MUDPUMP,
      value: data?.mudPumpCount,
      label: 'Mud Pump'
    },
  ];

  return (
    <Card style={commonStyle.card}>
      <Card.Content>
        <View style={commonStyle.cardContainer}>
          {pumpsData.map((pump, index) => (
            <View key={index} style={commonStyle.metric}>
              {renderIcon(pump.icon, COLORS.PRIMARY)}
              <Paragraph style={commonStyle.metricTitle}>
                {pump.value}
              </Paragraph>
              <Paragraph style={commonStyle.metricValue}>
                {LanguageString(pump.label)}
              </Paragraph>
            </View>
          ))}
        </View>
      </Card.Content>
    </Card>
  );
};
export default PumpsList;
