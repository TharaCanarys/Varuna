import React, {useEffect, useCallback} from 'react';
import {View, StyleSheet} from 'react-native';
import {COLORS} from '../../constants/colors';
import {
  FwButtonPrimary,
  FwDialog,
  FwLinkPrimary,
  FwTextInputPrimary,
  FwTextPrimary,
  FwTextSecondary,
} from '../../elements';
import {PAGES} from '../../components/pages';
import {IMAGES} from '../../assets';
import Loader from '../../components/loader';
import {LanguageString} from '../../constants/data';
import {normalized} from '../../constants/platform';
import FwImage from '../../elements/FwImage';
import OtpVerificationModal from '../../components/SignupComponents/OtpModal';
import CreatePasswordModal from '../../components/SignupComponents/CreatePasswordModal';
import {HandleSendOtp} from '../../services/apiServices';

interface SignupViewProps {
  formState: {
    email: string;
    // fullname: string;
    // area: string;
    phone: number | string;
    // city: string;
    // pincode: number | undefined;
    password: string;
    confirmPassword: string;
    otp: number | undefined;
  };
  uiState: {
    showNextFields: boolean;
    showPassword: boolean;
    showConfirmPassword: boolean;
    showOtpInput: boolean;
    isFormValid: boolean;
    loading: boolean;
    showCreatePasswordModal: boolean;
  };
  modalState: {
    visible: boolean;
    dialogTitle: string;
    dialogDescription: string;
  };
  updateFormState: (field: string, value: string) => void;
  handleOtpVerification: () => void;
  updateModalState: (field: string, value: boolean | string) => void;
  updateUiState: (field: string, value: boolean | number) => void;

  navigation: any;
  hideDialog: () => void;
  errorState: {
    // emailError: string;
    // fullnameError: string;
    phoneError: string;
    // areaError: string;
    // cityError: string;
    // pincodeError: string;
    // passwordError: string;
    // confirmPasswordError: string;
    otpError: string;
    handleResendOTP: () => void;
  };
}

const SignupScreenView: React.FC<SignupViewProps> = ({
  formState,
  uiState,
  errorState,
  modalState,
  updateFormState,
  updateModalState,
  updateUiState,
  handleOtpVerification,
  navigation,
  // handleResendOTP,
}) => {
  const validatePhone = (phone: number) => {
    if (!phone) {
      errorState.phoneError =
        LanguageString('Phone') + ' ' + LanguageString('is required');
    } else if (phone.toString().length < 10) {
      errorState.phoneError = LanguageString(
        'Phone number must be at least 10 digits',
      );
    } else {
      errorState.phoneError = '';
    }
  };

  // Effect to check form validity
  useEffect(() => {
    if (uiState.showNextFields) {
      updateUiState(
        'isFormValid',
        // errorState.emailError === '' &&
        //   // formState.email !== '' &&
        //   errorState.fullnameError === '' &&
        //   // formState.fullname !== '' &&
        errorState.phoneError === '' && formState.phone !== undefined,
        // errorState.pincodeError === '' &&
        // formState.pincode !== undefined,
      );
    } else {
      updateUiState('isFormValid', false);
    }
  }, [
    uiState.showNextFields,
    // formState.fullname,
    // formState.email,
    formState.phone,
    // formState.pincode,
    // errorState.fullnameError,
    // errorState.emailError,
    // errorState.phoneError,
    // errorState.pincodeError,
  ]); // Show error dialog  const showDialog = useCallback((title: string, description: string) => {

  const showDialog = useCallback((title: string, description: string) => {
    updateModalState('dialogTitle', title);
    updateModalState('dialogDescription', description);
    updateModalState('visible', true);
  }, []);
  const hideDialog = useCallback(() => {
    updateModalState('visible', false);
  }, []);

  // Handle signup button press
  const handleSignupPress = async () => {
    const payload = {
      mobileNumber: formState.phone?.toString(),
    };
    console.log('Call API Of Otp Sending', payload);
    HandleSendOtp(payload, onSuccessSentOtp, onFailedSendOtp);
  };

  const onSuccessSentOtp = (data: string) => {
    console.log('Otp sent successfully', data);
    showDialog(
      LanguageString('OTP Sent'),
      LanguageString('OTP has been sent to your registered mobile number'),
    );
    updateUiState('showNextFields', false);
    updateUiState('showOtpInput', true);
  };
  const onFailedSendOtp = (error: string) => {
    console.log('Could not send otp', error);
  };

  const handleCreateAccount = async () => {
    console.log('Create Account Pressed', formState);
    // updateUiState('showCreatePasswordModal', false);
    // updateUiState('showNextFields', true);
    // navigation.navigate(PAGES.DASHBOARD_NAV);
  };
  return uiState.loading ? (
    <Loader />
  ) : (
    <View style={styles.container}>
      <FwImage source={IMAGES.LOGO} style={styles.logo} resizeMode="contain" />
      <FwTextPrimary type="title_1" style={styles.title}>
        {uiState.showOtpInput
          ? LanguageString('Verify OTP')
          : uiState.showCreatePasswordModal
          ? LanguageString('New Password')
          : LanguageString('Signup')}
      </FwTextPrimary>

      {uiState.showOtpInput && (
        <>
          <OtpVerificationModal
            updateFormState={updateFormState}
            otp={formState.otp}
            errorState={errorState}
            handleOtpVerification={() => handleOtpVerification()}
            handleEditNumber={() => {
              updateUiState('showOtpInput', false);
              updateUiState('showNextFields', true);
            }}
          />
        </>
      )}

      {uiState.showCreatePasswordModal && (
        <CreatePasswordModal
          formState={formState}
          uiState={{
            ...uiState,
            handleCreateAccount, // Add handleCreateAccount to uiState
          }}
          errorState={errorState}
          updateFormState={updateFormState}
          updateUiState={updateUiState}
        />
      )}

      {uiState.showNextFields && (
        <>
          <FwTextInputPrimary
            label={
              LanguageString('Enter') + ' ' + LanguageString('Phone Number')
            }
            value={formState.phone?.toString()}
            mode="outlined"
            onChangeText={(text: string) => {
              updateFormState('phone', text);
              validatePhone(Number(text));
            }}
            keyboardType="numeric"
            maxLength={10}
            error={!!errorState.phoneError}
            style={styles.inputField}
          />
          {errorState.phoneError ? (
            <FwTextPrimary style={styles.errorText}>
              {errorState.phoneError}
            </FwTextPrimary>
          ) : null}

          <FwButtonPrimary
            mode="contained"
            disabled={!formState.phone}
            onPress={handleSignupPress}>
            {uiState.loading ? (
              <Loader />
            ) : (
              <FwTextSecondary type="buttonText">
                {LanguageString('Signup')}
              </FwTextSecondary>
            )}
          </FwButtonPrimary>
        </>
      )}

      {!uiState.showCreatePasswordModal && (
        <FwLinkPrimary
          onPress={() => navigation.navigate(PAGES.LOGIN as never)}
          style={styles.loginLink}>
          <FwTextPrimary type="buttonText" style={styles.loginLinkText}>
            {LanguageString('Existing Account? Go to Login')}
          </FwTextPrimary>
        </FwLinkPrimary>
      )}
      <FwDialog
        visible={modalState.visible}
        hideDialog={hideDialog}
        title={LanguageString(modalState.dialogTitle)}
        description={modalState.dialogDescription}></FwDialog>
    </View>
  );
};
const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    padding: normalized(16),
    backgroundColor: COLORS.SECONDARY,
  },
  signupBtnStyle: {
    marginTop: normalized(20),
    minWidth: normalized(200),
    backgroundColor: COLORS.PRIMARY,
    alignSelf: 'center',
  },
  disabledButton: {
    backgroundColor: COLORS.DARKGRAY,
  },
  title: {
    textAlign: 'center',
    marginBottom: normalized(24),
  },
  logo: {
    width: normalized(120),
    height: normalized(120),
    alignSelf: 'center',
    marginBottom: normalized(20),
  },
  errorText: {
    color: COLORS.ERROR,
    marginBottom: normalized(10),
  },
  loginLink: {
    marginTop: normalized(20),
    alignSelf: 'center',
  },
  loginLinkText: {
    color: COLORS.PRIMARY,
  },
  inputField: {
    marginBottom: normalized(20),
  },
});
export default SignupScreenView;
