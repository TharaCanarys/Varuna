import React, { useCallback } from 'react';
import { View, StyleSheet, RefreshControl, FlatList, TouchableOpacity, Pressable } from 'react-native';
import { Card, IconButton } from 'react-native-paper';
import { COLORS } from '../../constants/colors';
import { FwTextPrimary, FwButtonPrimary } from '../../elements';
import { LanguageString } from '../../constants/strings';
import { Escalation } from '../../types/escalationTypes';
import { RootState } from '../../store/store';
import { useSelector } from 'react-redux';
import EscalationDetailsModal from './EscalationDetailsModal';
import { commonStyle } from '../../styles/common';
import { User } from '../../types/userTypes';
import PageHeader from '../../components/PageHeader';
import FwModal from '../../elements/FwModal';
import { normalized } from '../../constants/platform';

interface EscalationScreenViewProps {
  refreshing: boolean;
  setRefreshing: (refreshing: boolean) => void;
  escalations: Escalation[];
  selectedEscalation: Escalation | null;
  setSelectedEscalation: (escalation: Escalation | null) => void;
  onRefresh: () => void;
  isAddingNewEscalation: boolean;
  openAddNewEscalation: () => void;
  closeAddNewEscalation: () => void;
}

export default function EscalationScreenView({
  refreshing,
  setRefreshing,
  escalations,
  selectedEscalation,
  setSelectedEscalation,
  onRefresh,
  isAddingNewEscalation,
  openAddNewEscalation,
  closeAddNewEscalation
}: EscalationScreenViewProps) {
  const selectedLanguage = useSelector((state: RootState) => state.app.selectedLanguage);
  const users = useSelector((state: RootState) => state.app.users.data);
  const role = useSelector((state: RootState) => state.auth.userRole);
  const getEscalationTypeName = useCallback((type: number) => {
    switch (type) {
      case 0:
        return LanguageString('Task');
      case 1:
        return LanguageString('Maintenance');
      case 2:
        return LanguageString('Complaint');
      case 3:
        return LanguageString('Safety');
      default:
        return LanguageString('Unknown');
    }
  }, []);

  const getStatusName = useCallback((status: number) => {
    switch (status) {
      case 0:
        return LanguageString('Pending');
      case 1:
        return LanguageString('In Progress');
      case 2:
        return LanguageString('Completed');
      case 3:
        return LanguageString('Rejected');
      default:
        return LanguageString('Unknown');
    }
  }, []);

  const getUserName = useCallback((userId: string) => {
    const user = users?.find((user: User) => user.userID === userId);
    return user ? user.userName : LanguageString('Unknown');
  }, [users]);

  const openEscalationDetails = useCallback(
    (escalation: Escalation) => {
      setSelectedEscalation(escalation);
    },
    [setSelectedEscalation]
  );

  const closeEscalationDetails = useCallback(() => {
    setSelectedEscalation(null);
  }, [setSelectedEscalation]);

  const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: COLORS.BG_WHITE,
    },
    addButtonContainer: {
      padding: normalized(10),
      backgroundColor: COLORS.BG_WHITE,
    },
    modalContainer: {
      backgroundColor: COLORS.BG_WHITE,
      padding: normalized(10),
      margin: normalized(10),
    },
    escalationCard: {
      marginBottom: normalized(20),
      elevation: 4,
      backgroundColor: COLORS.BG_WHITE,
    },
    cardContent: {
      marginLeft: normalized(30),
      marginTop: normalized(30),
      paddingBottom: normalized(20),
    },
    cardActions: {
      flexDirection: 'row',
      justifyContent: 'flex-end',
      marginTop: normalized(10),
    },
  });

  const renderEscalationCard = useCallback(
    (escalation: Escalation, index: number) => (
      <Pressable
        onPress={() => openEscalationDetails(escalation)}
        style={styles.escalationCard}
      >
        <Card>
          <View style={styles.cardContent}>
            <View style={commonStyle.modalRow}>
              <FwTextPrimary style={commonStyle.boldText}>
                {LanguageString('Escalation ID') + ' : '}
              </FwTextPrimary>
              <FwTextPrimary style={commonStyle.normalText}>
                {escalation.escalationID}
              </FwTextPrimary>
            </View>
            <View style={commonStyle.modalRow}>
              <FwTextPrimary style={commonStyle.boldText}>
                {LanguageString('Escalated By') + ' : '}
              </FwTextPrimary>
              <FwTextPrimary style={commonStyle.normalText}>
                {getUserName(escalation.escalatedByUserID)}
              </FwTextPrimary>
            </View>
            <View style={commonStyle.modalRow}>
              <FwTextPrimary style={commonStyle.boldText}>
                {LanguageString('Escalation Type') + ' : '}
              </FwTextPrimary>
              <FwTextPrimary style={commonStyle.normalText}>
                {getEscalationTypeName(escalation.escalationType)}
              </FwTextPrimary>
            </View>
            <View style={commonStyle.modalRow}>
              <FwTextPrimary style={commonStyle.boldText}>
                {LanguageString('Status') + ' : '}
              </FwTextPrimary>
              <FwTextPrimary style={commonStyle.normalText}>
                {getStatusName(escalation.status)}
              </FwTextPrimary>
            </View>
            <View style={commonStyle.modalRow}>
              <FwTextPrimary style={commonStyle.boldText}>
                {LanguageString('Escalation Time') + ' : '}
              </FwTextPrimary>
              <FwTextPrimary style={commonStyle.normalText}>
                {new Date(escalation.escalationTime).toLocaleString('en-US', {
                  timeZone: 'Asia/Kolkata'
                })}
              </FwTextPrimary>
            </View>
            <View style={commonStyle.modalRow}>
              <FwTextPrimary style={commonStyle.boldText}>
                {LanguageString('Resolution Time') + ' : '}
              </FwTextPrimary>
              <FwTextPrimary style={commonStyle.normalText}>
                {escalation.resolutionTime ?
                  new Date(escalation.resolutionTime).toLocaleString('en-US', {
                    timeZone: 'Asia/Kolkata'
                  }) :
                  LanguageString('Not resolved yet')
                }
              </FwTextPrimary>
            </View>
          </View>
        </Card>
      </Pressable>
    ),
    [openEscalationDetails]
  );

  const isAnyModalActive = isAddingNewEscalation || selectedEscalation !== null;

  return (
    <>
      <PageHeader title="Escalations" />
      {/* <View style={styles.addButtonContainer}>
        {!isAnyModalActive && (
          <FwButtonPrimary
            mode="outlined"
            onPress={openAddNewEscalation}
            icon="plus">
            <FwTextPrimary>{LanguageString('Add New')}</FwTextPrimary>
          </FwButtonPrimary>
        )}
      </View> */}
      <FlatList
        style={styles.container}
        data={escalations}
        renderItem={({ item }) => renderEscalationCard(item, item.id)}
        keyExtractor={item => item?.id}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
        }
        ListEmptyComponent={
          <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
            <FwTextPrimary style={styles.escalationCardText}>
              {LanguageString('No escalations found')}
            </FwTextPrimary>
          </View>
        }
      />
      {/* Escalation Details Modal */}
      <FwModal
        visible={selectedEscalation !== null}
        onDismiss={closeEscalationDetails}
        contentContainerStyle={styles.modalContainer}>
        <EscalationDetailsModal
          visible={!!selectedEscalation}
          onClose={closeEscalationDetails}
          escalation={selectedEscalation}
          getUserName={getUserName}
          getEscalationTypeName={getEscalationTypeName}
          getStatusName={getStatusName}
        />
      </FwModal>
      {/* Add New Escalation Modal */}
      <FwModal
        visible={isAddingNewEscalation}
        onDismiss={closeAddNewEscalation}
        contentContainerStyle={styles.modalContainer}>
        {/* Add escalation form component here */}
      </FwModal>
    </>
  );
}
