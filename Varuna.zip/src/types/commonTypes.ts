export interface FwDialogProps {
  children?: React.ReactNode;
  title: string;
  // description: string;
  visible: boolean;
  hideDialog: () => void;
  [key: string]: any; // For any additional props
}

export interface FwLinkPrimaryProps {
  children: React.ReactNode;
  style: any;
  onPress: () => void;
}

export interface FwLinkSecondaryProps {
  children: React.ReactNode;
  style: any; // Consider using a more specific type like ViewStyle or TextStyle
  onPress: () => void;
}

export interface SensorPropTypes {
  sensorId: number;
  sensorName: string;
  type: number;
  status: string | number;
  locationName: string;
  sensorType: number | string;
  locationId: number;
  installedDate: string;
}

export interface SensorScreenProps {
  selectedSensor: SensorPropTypes | null;
  refreshing: boolean;
  sensors: SensorPropTypes[];
  newStatus: string;
  setNewStatus: (status: string) => void;
  editingStatus: boolean;
  isAddingNewSensor: boolean;
  newSensor: SensorPropTypes;
  setNewSensor: (sensor: SensorPropTypes) => void;
  errors: {
    sensorName: string;
    location: string;
    installedDate: string;
    status: string;
  };
  showDatePicker: boolean;
  isSwitchOn: boolean;
  setIsSwitchOn: (isSwitchOn: boolean) => void;
  setShowDatePicker: (show: boolean) => void;
  onRefresh: () => void;
  openSensorDetails: (sensor: SensorPropTypes) => void;
  startEditingStatus: () => void;
  handleUpdateSensor: (sensor: SensorPropTypes) => void;
  handleDeleteSensor: (sensor: SensorPropTypes) => void;
  openAddNewSensor: () => void;
  closeSensorDetails: () => void;
  validateStatus: (newStatus: string) => void;
  saveStatus: () => void;
  closeAddNewSensor: () => void;
  handleAddNewSensor: () => void;
  onDateChange: (date: Date) => void;
  isLoading: boolean;
  sensorNameOptions: string[];
  locationOptions: string[];
  snackbarVisible: boolean;
  setSnackbarVisible: (visible: boolean) => void;
}

export interface PumpStationPropTypes {
  id: number;
  pumpId: string;
  locationName: string;
  stationId: string;
  pumpTypeName: string;
  fuelTypeName: string;
  ratedPower: number;
  energyUnitsConsumed: number;
  pumpOnTimeHours: number;
  pumpOnTimeMinutes: number;
  pumpOnTimeTotalHours: number;
  pumpOnTimeTotalMinutes: number;
  // Keeping old fields for backward compatibility
  PumpHouseName?: string;
  inspectionDate?: string;
  Location?: string;
  PipeDetails?: string;
  PumpOperationRawData?: string;
}
export interface PumpOperationScreenProps {
  selectedPumpStation: PumpStationPropTypes | null;
  pumpStations: PumpStationPropTypes[];
  refreshing: boolean;
  onRefresh: () => void;
  openPumpStationDetails: (pumpStation: PumpStationPropTypes) => void;
  closePumpStationDetails: () => void;
}

export interface PumpStationScreenProps {
  selectedPumpStation: PumpStationPropTypes | null;
  setSelectedPumpStation: (pumpStation: PumpStationPropTypes) => void;
  refreshing: boolean;
  pumpStations: PumpStationPropTypes[];
  isAddingNewPumpStation: boolean;
  newPumpStation: PumpStationPropTypes;
  setNewPumpStation: (pumpStation: PumpStationPropTypes) => void;
  errors: {
    PumpStationid: number;
    PumpHouseName: string;
    inspectionDate: string;
    Locationid: number;
    Elevation: number;
    PumpType: string;
    PumpNumber: number;
    RatedPower: number;
  };
  showDatePicker: boolean;
  setShowDatePicker: (show: boolean) => void;
  onRefresh: () => void;
  openPumpStationDetails: (pumpStation: PumpStationPropTypes) => void;
  handleUpdatePumpStation: (pumpStation: PumpStationPropTypes) => void;
  handleDeletePumpStation: (pumpStation: PumpStationPropTypes) => void;
  openAddNewPumpStation: () => void;
  closePumpStationDetails: () => void;
  closeAddNewPumpStation: () => void;
  handleAddNewPumpStation: () => void;
  onDateChange: (date: Date) => void;
  isLoading: boolean;
}

export interface AlertPropTypes {
  id: number;
  sensor: string;
  severity: string;
  status: string;
  createdDate: string;
}

export enum TaskStatus {
  ESCALATED = 6,
  ASSIGNED = 2,
  IN_PROGRESS = 1
}

export interface TaskTypes {
  taskID: string;
  description: string;
  assignedToUserID: string;
  createdByUserID: string;
  status: string | TaskStatus;
  creationDate: string;
  manualIncidentEntryId: string;
  taskHistory: TaskHistoryTypes[];
}

export interface User {
  id: number;
  name: string;
}

export interface TaskHistoryTypes {
  id: number;
  changedDate: string;
  changedBy: string;
  oldStatus: string;
  newStatus: string;
  comments: string;
}

export interface ErrorState {
  createdByUserID: string;
  assignedToUserID: string;
  status: string;
  creationDate: string;
  description: string;
  manualIncidentEntryId: string;
  taskHistory: TaskHistoryTypes[];
}

export interface TaskScreenProps {
  selectedTask: TaskTypes | null;
  refreshing: boolean;
  tasks: TaskTypes[];
  newStatus: string;
  setNewStatus: (status: string) => void;
  updateTaskState: (field: string, value: string) => void;
  editingStatus: boolean;
  isAddingNewTask: boolean;
  newTask: TaskTypes;
  setNewTask: (task: TaskTypes) => void;
  errors: {
    createdByUserID: string;
    assignedToUserID: string;
    status: string;
    creationDate: string;
    description: string;
    manualIncidentEntryId: string;
    taskHistory: TaskHistoryTypes[];
  };
  setRefreshing: (refreshing: boolean) => void;
  setTaskToDelete: (id: number) => void;
  deleteConfirmationVisible: boolean;
  setDeleteConfirmationVisible: (visible: boolean) => void;
  setSelectedTask: (task: TaskTypes) => void | null;
  taskToDelete: number | null;
  setTasks: (tasks: TaskTypes[]) => void;
  setEditingStatus: (editingStatus: boolean) => void | boolean;
  setIsAddingNewTask: (isAddingNewTask: boolean) => void;
  setErrors: (errors: any) => void;
  setStatusError: (statusError: string) => void;
  isDetailsVisible: boolean;
  setDetailsVisible: (isDetailsVisible: boolean) => void;
}
export interface MaintenancePropTypes {
  Technician: any;
  location: any;
  maintenanceType: any;
  id: number;
  status: number | string;
  description: string;
  scheduledDate: string;
  dueDate: string;
  completedDate: string;
  Remarks: string;
  assetsType: string;
  facilityType: number;
  isActive: boolean;
  locationID: number;
  maintenanceID: number;
  raisedByUserID: number;
  remarks: string | null;
  technicianID: number;
  type: number;
}

export interface MaintenanceScreenProps {
  selectedMaintenance: MaintenancePropTypes | null;
  refreshing: boolean;
  maintenances: MaintenancePropTypes[];
  newStatus: string;
  setNewStatus: (status: string) => void;
  editingStatus: boolean;
  isAddingNewMaintenance: boolean;
  newMaintenance: MaintenancePropTypes;
  setNewMaintenance: (maintenance: MaintenancePropTypes) => void;
  errors: {
    status: string;
    location: string;
    maintenanceType: string;
    description: string;
    scheduledDate: string;
    dueDate: string;
    completedDate: string;
    Technician: string;
    Remarks: string;
    assetsType: string;
  };
  showDatePicker: boolean;
  setShowDatePicker: (show: boolean) => void;
  openMaintenanceDetails: (maintenance: MaintenancePropTypes) => void;
  onRefresh: () => void;
  startEditingStatus: () => void;
  handleDeleteMaintenance: (id: number) => void;
  openAddNewMaintenance: () => void;
  closeMaintenanceDetails: () => void;
  validateStatus: (newStatus: string) => void;
  saveStatus: () => void;
  closeAddNewMaintenance: () => void;
  handleAddNewMaintenance: () => void;
  remarks: string;
  description: string;
  setDescription: (description: string) => void;
  setRemarks: (remarks: string) => void;
}

export interface CityAdminScreenProps {
  selectedCityAdmin: CityAdminPropTypes | null;
  refreshing: boolean;
  cityAdmins: CityAdminPropTypes[];
  newStatus: string;
  setNewStatus: (status: string) => void;
  editingStatus: boolean;
  isAddingNewCityAdmin: boolean;
  newCityAdmin: CityAdminPropTypes;
  setNewCityAdmin: (cityAdmin: CityAdminPropTypes) => void;
  errors: {
    cityAdminAreaName: string;
    cityAdminAreaType: string;
    location: string;
    population: number;
    keyFacility: string;
    floodRiskLevel: string;
    contactPerson: string;
    emergencyService: string;
    evolutionPlan: string;
  };
  openCityAdminDetails: (cityAdmin: CityAdminPropTypes) => void;
  onRefresh: () => void;
  startEditingStatus: () => void;
  handleDeleteCityAdmin: (id: number) => void;
  openAddNewCityAdmin: () => void;
  closeCityAdminDetails: () => void;
  validateStatus: (newStatus: string) => void;
  saveStatus: () => void;
  closeAddNewCityAdmin: () => void;
  handleAddNewCityAdmin: () => void;
}

export interface CityAdminPropTypes {
  id: number;
  cityAdminAreaName: string;
  cityAdminAreaType: string;
  location: string;
  population: number;
  keyFacility: string;
  floodRiskLevel: string;
  contactPerson: string;
  emergencyService: string;
  evolutionPlan: string;
}

export interface CityCatchmentScreenProps {
  selectedCityCatchment: CityCatchmentPropTypes | null;
  refreshing: boolean;
  cityCatchments: CityCatchmentPropTypes[];
  newStatus: string;
  setNewStatus: (status: string) => void;
  editingStatus: boolean;
  isAddingNewCityCatchment: boolean;
  newCityCatchment: CityCatchmentPropTypes;
  setNewCityCatchment: (cityCatchment: CityCatchmentPropTypes) => void;
  errors: {
    cityCatchmentAreaName: string;
    location: string;
    areaSize: string;
    waterBodies: string;
    runOfCoeffecient: string;
    avgRainfall: string;
    drainageCapacity: string;
    floodRiskLevel: string;
  };
  openCityCatchmentDetails: (cityCatchment: CityCatchmentPropTypes) => void;
  onRefresh: () => void;
  startEditingStatus: () => void;
  handleDeleteCityCatchment: (id: number) => void;
  openAddNewCityCatchment: () => void;
  closeCityCatchmentDetails: () => void;
  validateStatus: (newStatus: string) => void;
  saveStatus: () => void;
  closeAddNewCityCatchment: () => void;
  handleAddNewCityCatchment: () => void;
}

export interface CityCatchmentPropTypes {
  id: number;
  cityCatchmentAreaName: string;
  location: string;
  areaSize: string;
  waterBodies: string;
  runOfCoeffecient: string;
  avgRainfall: string;
  drainageCapacity: string;
  floodRiskLevel: string;
}
export interface POIScreenProps {
  selectedPOI: POIPropTypes | null;
  refreshing: boolean;
  pois: POIPropTypes[];
  newStatus: string;
  setNewStatus: (status: string) => void;
  editingStatus: boolean;
  isAddingNewPOI: boolean;
  newPOI: POIPropTypes;
  setNewPOI: (poi: POIPropTypes) => void;
  errors: {
    adjescentPois: any;
    poiStatus: any;
    network: any;
    elevation: any;
    //poiType: any;
    poiName: any;
    cityCatchmentAreaName: string;
    location: string;
    areaSize: string;
    waterBodies: string;
    runOfCoeffecient: string;
    avgRainfall: string;
    drainageCapacity: string;
    floodRiskLevel: string;
  };
  openPOIDetails: (poi: POIPropTypes) => void;
  onRefresh: () => void;
  startEditingStatus: () => void;
  handleDeletePOI: (id: number) => void;
  openAddNewPOI: () => void;
  closePOIDetails: () => void;
  validateStatus: (newStatus: string) => void;
  saveStatus: () => void;
  closeAddNewPOI: () => void;
  handleAddNewPOI: () => void;
  language: string;
  isLoading: boolean;
}

export interface POIPropTypes {
  id: number;
  location: string;
  poiName: string;
  //poiType: string;
  elevation: string;
  network: string;
  poiStatus: string;
  floodRiskLevel: string;
  adjescentPois: string;
}

export interface SupportTicketPropTypes {
  id: number;
  location: string;
  category: string;
  priority: string;
  raisedBy: string;
  raisedDate: string;
  status: string;
  assignedTo: string;
  resolvedDate: string;
  assetType: string;
  description: string;
  resolutionDetails: string;
  remarks: string;
}

export interface NotificationPropTypes {
  id: number;
  name: string;
  sentTime: string;
  channel: string;
  deliveryStatus: string;
  message: string;
}

export interface NotificationScreenProps {
  // selectedNotification: NotificationPropTypes | null;
  currentNotification: NotificationPropTypes | null;
  // setCurrentNotification: (notification: NotificationPropTypes) => void;
  // setSelectedNotification: (notification: NotificationPropTypes) => void;
  refreshing: boolean;
  notifications: any;
  openNotificationDetails: (notification: NotificationPropTypes) => void;
  onRefresh: () => void;
  closeNotificationDetails: () => void;
}

export interface Log {
  logId: string;
  loggedTime: string;
  severity: string;
  category: string;
  initiator: string;
  status: string;
  correlationId: string;
  message: string;
  details: string;
}
