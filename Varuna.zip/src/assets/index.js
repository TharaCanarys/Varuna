const logo = require('./logo.png');
const loaderLogo = require('./LoaderLogo.png');
const splashImage = require('./SplashImage.png');
const upGovLogo = require('./upGovLogo.png');
const jalkalLogo = require('./jalkalLogo.jpg');
const rainfallIcon = require('./icons/rainfall.png');
const pointerIcon = require('./icons/pointer.png');
const pumpIcon = require('./icons/pump.png');
const pumpingStationIcon = require('./icons/pumpingStation.png');
const drainIcon = require('./icons/Drains.png');
const pumpListIcon = require('./icons/pumpList.png');
const cityAdminIcon = require('./icons/cityAdmin.png');
const SupportTicketIcon = require('./icons/supportTicket.png');
const floodWarning = require('./icons/Flood_Warning_icon.png');
const dieselpump = require('./icons/Diesel_pump.png');
const electricpump = require('./icons/Electric_pump.png');
const mudpump = require('./icons/Mud_Pump.png');
const maintenanceIcon = require('./icons/maintenance.png');
const translate = require('./icons/translate.png');
const tankImg = require('./icons/tank.png');
// import {ReactComponent as Icon} from './icons/Flood_Warning_icon.svg';

export const IMAGES = {
  LOGO: logo,
  LOADER_LOGO: loaderLogo,
  SPLASH_IMAGE: splashImage,
  UP_GOV_LOGO: upGovLogo,
  JALKAL_LOGO: jalkalLogo,
  CITYADMIN: cityAdminIcon,
  SUPPORTTICKET: SupportTicketIcon,
  FLOOD_WARNING: floodWarning,
  TRANSLATE: require('./icons/translate.png'),
  
};

export const ICONS = {
  RAINFALLICON: rainfallIcon,
  DRAIN: drainIcon,
  PUMP: pumpIcon,
  PUMPINGSTATION: pumpingStationIcon,
  PUMPLIST: pumpListIcon,
  POINTER: pointerIcon,
  // LANGUAGE_SELECTION: Icon,
  DIESELPUMP: dieselpump,
  ELECTRICPUMP: electricpump,
  MUDPUMP: mudpump,
  MAINTENANCE: maintenanceIcon,
  TANK: tankImg,
};
