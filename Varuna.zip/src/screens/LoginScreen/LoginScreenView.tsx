import {useNavigation} from '@react-navigation/native';
import React, {useState, useEffect, useCallback} from 'react';

import {View, StyleSheet} from 'react-native';
// import {TextInput, Modal} from 'react-native-paper';
import {COLORS} from '../../constants/colors';
import {
  FwButtonPrimary,
  FwTextPrimary,
  FwTextSecondary,
  FwDialog,
  FwTextInputPrimary,
  FwLinkPrimary,
} from '../../elements';
import {PAGES} from '../../components/pages';
import {IMAGES} from '../../assets';
import {LanguageString, width} from '../../constants/data';
import Loader from '../../components/loader';
import {LoginViewProps} from '../../types/loginTypes';
import {normalized} from '../../constants/platform';
import FwImage from '../../elements/FwImage';
import {
  // RenderForgotPassword,
  // RenderNewPassword,
  RenderOtpVerification,
} from '../../components';
import FwModal from '../../elements/FwModal';
import { TextInput } from 'react-native-paper';

const LoginScreenView: React.FC<LoginViewProps> = ({
  formState,
  uiState,
  modalState,
  errorState,
  updateFormState,
  updateUiState,
  updateModalState,
  handleLoginSubmit,
  handleVerifyOTPSubmit,
  handleResendOTP,
  handleSignIn
}) => {
  const [isLoginButtonDisabled, setIsLoginButtonDisabled] = useState(false);
  const [showPasswordField, setShowPasswordField] = useState(false);
  const navigation = useNavigation();

  useEffect(() => {
    const hasErrors = !!errorState.emailError || !!errorState.passwordError;
    const hasEmptyFields = !formState.email || !formState.password;
    setIsLoginButtonDisabled(hasErrors || hasEmptyFields);
  }, [
    formState.email,
    formState.password,
    errorState.emailError,
    errorState.passwordError,
  ]);

  const hideDialog = () => updateModalState('visible', false);

  const validatePhone = (phone: string) => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    const phoneRegex = /^[0-9]{10}$/;
    if (!phone) {
      errorState.confirmMobileError =
        LanguageString('Email/Phone') + ' ' + LanguageString('is required');
    } else if (!emailRegex.test(phone) && !phoneRegex.test(phone)) {
      errorState.confirmMobileError = LanguageString('Invalid email or phone format');
    } else {
      errorState.confirmMobileError = '';
      if (emailRegex.test(phone)) {
        setShowPasswordField(true);
      } else {
        setShowPasswordField(false);
      }
    }
  };

  const validatePassword = (password: string) => {
    if (!password) {
      errorState.passwordError =
        LanguageString('Password') + ' ' + LanguageString('is required');
    } else if (password.length < 6) {
      errorState.passwordError = LanguageString(
        'Password must be at least 6 characters long',
      );
    } else if (!/[a-zA-Z]/.test(password)) {
      errorState.passwordError = LanguageString(
        'Password must contain at least one alphabet character',
      );
    } else {
      errorState.passwordError = '';
    }
  };

  const validateOTP = (otp: string) => {
    if (!otp) {
      errorState.otpError =
        LanguageString('OTP') + LanguageString('is required');
    } else if (otp.length !== 6) {
      errorState.otpError = LanguageString('OTP must be 6 digits long');
    } else {
      errorState.otpError = '';
    }
  };

  const handleLoginPress = () => {
    if (showPasswordField && formState.password) {
      handleSignIn(formState.confirmMobile, formState.password);
    }else{
      handleLoginSubmit(formState.confirmMobile);
    }
  };

  const handleVerifyOTP = async (email: string, otp: string) => {
    handleVerifyOTPSubmit(otp, formState.confirmMobile);
  };

  const closeOtpModal = () => {
    updateModalState('otpModal', false);
    updateFormState('otp', '');
    errorState.otpError = '';
  };
  
  const showErrorDialog = (title: string, description: string) => {
    updateModalState('dialogTitle', title);
    updateModalState('dialogDescription', description);
    updateModalState('visible', true);
    setTimeout(() => updateModalState('visible', false), 2000);
  };

  const renderOtpVerificationModal = useCallback(
    () => (
      <RenderOtpVerification
        updateFormState={updateFormState}
        validateOTP={validateOTP}
        errorState={errorState}
        formState={formState}
        uiState={uiState}
        handleResendOTP={handleResendOTP}
        styles={styles}
        handleVerifyOTP={handleVerifyOTP}
        closeOtpModal={closeOtpModal}
      />
    ),
    [
      closeOtpModal,
      handleResendOTP,
      handleVerifyOTP,
      uiState.isLoading,
      formState.otp,
      uiState.timer,
      validateOTP,
      errorState.otpError,
    ],
  );

  const isAnyModalActive =
    modalState.passwordModal ||
    modalState.otpModal ||
    modalState.newPasswordModal ||
    modalState.visible;

  return uiState.isLoading ? (
    <Loader />
  ) : (
    <View style={styles.container}>
      <FwImage source={IMAGES.LOGO} style={styles.logo} resizeMode="contain" />
      <FwTextPrimary type="title_1" style={styles.title}>
        {LanguageString('Login')}
      </FwTextPrimary>
      <FwTextInputPrimary
        label={LanguageString('Email') + '/' + LanguageString('Phone')}
        value={formState.email}
        onChangeText={(text: string) => {
          updateFormState('confirmMobile', text);
          validatePhone(text);
        }}
        style={styles.input}
        keyboardType="email-address"
        autoCapitalize="none"
        error={!!errorState.emailError}
      />
      {errorState.emailError ? (
        <FwTextPrimary style={styles.errorText}>
          {errorState.emailError}
        </FwTextPrimary>
      ) : null}
      {showPasswordField && (
        <FwTextInputPrimary
          label={LanguageString('Password')}
          value={formState.password}
          onChangeText={(text: string) => {
            updateFormState('password', text);
            validatePassword(text);
          }}
          secureTextEntry={!uiState.showPassword}
          style={{...styles.input, color: COLORS.BLACK}}
          error={!!errorState.passwordError}
          right={
            <TextInput.Icon
              icon={uiState.showPassword ? 'eye' : 'eye-off'}
              onPress={() => updateUiState('showPassword', !uiState.showPassword)}
            />
          }
        />
      )}
      {showPasswordField && errorState.passwordError ? (
        <FwTextPrimary style={styles.errorText}>
          {errorState.passwordError}
        </FwTextPrimary>
      ) : null}

      <View style={styles.linkContainer}>
     
        <FwLinkPrimary
          onPress={() => navigation.navigate(PAGES.SIGNUP as never)}
          style={styles.link}>
          <FwTextPrimary type="buttonText">
            {LanguageString('Go to Signup')}
          </FwTextPrimary>
        </FwLinkPrimary>
      </View>

      {!isAnyModalActive && (
        <>
          <FwButtonPrimary
            mode="contained"
            style={[
              {
                ...styles.loginBtnStyle,
              },
            ]}
            onPress={handleLoginPress}
            // disabled={isLoginButtonDisabled}
            >
            <FwTextSecondary type="buttonText">
              {LanguageString('Login')}
            </FwTextSecondary>
          </FwButtonPrimary>

          <FwButtonPrimary
            mode="contained"
            style={styles.guestBtnStyle}
            onPress={() => navigation.navigate(PAGES.HOME as never)}>
            <FwTextSecondary type="buttonText">
              {LanguageString('Guest View')}
            </FwTextSecondary>
          </FwButtonPrimary>
        </>
      )}
  
      {/* OTP verification modal */}
       <FwModal
        visible={modalState.otpModal}
        contentContainerStyle={styles.modalContainer}
        dismissable={false}>
        {renderOtpVerificationModal()}
      </FwModal>
     
      <FwDialog
        visible={modalState.visible}
        hideDialog={hideDialog}
        description={modalState.dialogDescription}
        title={modalState.dialogTitle}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    padding: normalized(16),
    backgroundColor: COLORS.SECONDARY,
  },
  loginBtnStyle: {
    marginTop: normalized(20),
    width: normalized(width * 0.5),
    alignSelf: 'center',
  },

  guestBtnStyle: {
    marginTop: normalized(20),
    width: normalized(width * 0.5),
    alignSelf: 'center',
  },
  title: {
    textAlign: 'center',
    marginBottom: normalized(24),
  },
  input: {
    marginBottom: normalized(16),
  },
  modalContainer: {
    backgroundColor: COLORS.BG_WHITE,
    padding: normalized(20),
    margin: normalized(20),
    borderRadius: normalized(10),
  },
  modalTitle: {
    textAlign: 'center',
    marginBottom: normalized(16),
  },
  modalButton: {
    marginTop: normalized(10),
    width: normalized(150),
    alignSelf: 'center',
  },
  logo: {
    width: normalized(width * 0.3),
    height: normalized(width * 0.3),
    alignSelf: 'center',
    marginBottom: normalized(20),
  },
  errorText: {
    color: COLORS.ERROR,
    marginBottom: normalized(8),
  },
  linkContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: normalized(10),
  },
  link: {
    marginBottom: normalized(10),
  },
  timerContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: normalized(10),
  },
  timerText: {
    fontSize: normalized(16),
    marginRight: normalized(10),
  },
  resendLink: {
    color: COLORS.DARKBLUE,
    textDecorationLine: 'underline',
  },
});

export default LoginScreenView;
