export const PAGES = {
  ESCALATIONS: 'Escalations'
} as const;

export const LanguageString = (key: string): string => {
  return key;
};
