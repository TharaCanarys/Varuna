import React from 'react';
import {Text, TouchableOpacity} from 'react-native';
import {COLORS} from '../constants/colors';
import {FwLinkSecondaryProps} from '../types/commonTypes';

/**
 * FwLinkSecondary component
 * Renders a secondary link with custom styling
 */
const FwLinkSecondary: React.FC<FwLinkSecondaryProps> = ({
  children,
  style,
  onPress,
}) => {
  return (
    <TouchableOpacity onPress={onPress}>
      <Text style={[style, {color: COLORS.SECONDARY}]}>{children}</Text>
    </TouchableOpacity>
  );
};

export default FwLinkSecondary;
