import React from 'react';
import { View, StyleSheet } from 'react-native';
import { Modal } from 'react-native-paper';
import { FwTextPrimary } from '../../elements';
import { Escalation } from '../../types/escalationTypes';
import { LanguageString } from '../../constants/strings';
import { commonStyle } from '../../styles/common';

interface EscalationDetailsModalProps {
  visible: boolean;
  onClose: () => void;
  escalation: Escalation | null;
}

const EscalationDetailsModal: React.FC<EscalationDetailsModalProps> = ({
  visible,
  onClose,
  escalation,
  getUserName,
  getEscalationTypeName,
  getStatusName
}) => {
  if (!escalation) return null;
console.log('escalation', escalation);
  return (
    <Modal
      visible={visible}
      onDismiss={onClose}
      contentContainerStyle={styles.modalContainer}
    >
      <View style={commonStyle.modalRow}>
        <FwTextPrimary style={commonStyle.boldText}>
          {LanguageString('Escalation ID') + ' : '}
        </FwTextPrimary>
        <FwTextPrimary style={commonStyle.normalText}>
          {escalation.escalationID}
        </FwTextPrimary>
      </View>
      <View style={[commonStyle.modalRow, styles.rowSpacing]}>
        <FwTextPrimary style={commonStyle.boldText}>
          {LanguageString('Escalated By') + ' : '}
        </FwTextPrimary>
        <FwTextPrimary style={commonStyle.normalText}>
          {getUserName(escalation.escalatedByUserID)}
        </FwTextPrimary>
      </View>
      <View style={[commonStyle.modalRow, styles.rowSpacing]}>
        <FwTextPrimary style={commonStyle.boldText}>
          {LanguageString('Escalated To') + ' : '}
        </FwTextPrimary>
        <FwTextPrimary style={commonStyle.normalText}>
          {getUserName(escalation.escalatedToUserID)}
        </FwTextPrimary>
      </View>
      <View style={[commonStyle.modalRow, styles.rowSpacing]}>
        <FwTextPrimary style={commonStyle.boldText}>
          {LanguageString('Escalation Type') + ' : '}
        </FwTextPrimary>
        <FwTextPrimary style={commonStyle.normalText}>
          {getEscalationTypeName(escalation.escalationType)}
        </FwTextPrimary>
      </View>
      <View style={[commonStyle.modalRow, styles.rowSpacing]}>
        <FwTextPrimary style={commonStyle.boldText}>
          {LanguageString('Status') + ' : '}
        </FwTextPrimary>
        <FwTextPrimary style={commonStyle.normalText}>
          {getStatusName(escalation.status)}
        </FwTextPrimary>
      </View>
      <View style={[commonStyle.modalRow, styles.rowSpacing]}>
        <FwTextPrimary style={commonStyle.boldText}>
          {LanguageString('Escalation Time') + ' : '}
        </FwTextPrimary>
        <FwTextPrimary style={commonStyle.normalText}>
          {new Date(escalation.escalationTime).toLocaleString('en-US', {
            timeZone: 'Asia/Kolkata'
          })}
        </FwTextPrimary>
      </View>
      <View style={[commonStyle.modalRow, styles.rowSpacing]}>
        <FwTextPrimary style={commonStyle.boldText}>
          {LanguageString('Triggered By Id') + ' : '}
        </FwTextPrimary>
        <FwTextPrimary style={commonStyle.normalText}>
          {escalation.triggeredByID}
        </FwTextPrimary>
      </View>
      <View style={[commonStyle.modalRow, styles.rowSpacing]}>
        <FwTextPrimary style={commonStyle.boldText}>
          {LanguageString('Description') + ' : '}
        </FwTextPrimary>
        <FwTextPrimary style={commonStyle.normalText}>
          {escalation.description}
        </FwTextPrimary>
      </View>
      <View style={[commonStyle.modalRow, styles.rowSpacing]}>
        <FwTextPrimary style={commonStyle.boldText}>
          {LanguageString('Comments') + ' : '}
        </FwTextPrimary>
        <FwTextPrimary style={commonStyle.normalText}>
          {escalation.comments}
        </FwTextPrimary>
      </View>
    </Modal>
  );
};

const styles = StyleSheet.create({
  modalContainer: {
    backgroundColor: 'white',
    padding: 16,
    borderRadius: 8,
    height: 500,
  },
  rowSpacing: {
    marginBottom: 10,
  },
});

export default EscalationDetailsModal;
