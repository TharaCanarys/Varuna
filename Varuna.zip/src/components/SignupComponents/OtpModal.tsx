import React, {useState, useEffect} from 'react';
import {
  FwButtonPrimary,
  FwTextInputPrimary,
  FwTextPrimary,
  FwTextSecondary,
} from '../../elements';
import {LanguageString} from '../../constants/data';
import {StyleSheet} from 'react-native';
import {normalized} from '../../constants/platform';
import {COLORS} from '../../constants/colors';

interface OtpVerificationModalProps {
  updateFormState: (field: string, value: string) => void;
  otp: number | undefined;
  errorState: any;
  handleOtpVerification: () => void;
  handleEditNumber: () => void;
  handleResendOtp: () => void;
}

const OtpVerificationModal = ({
  updateFormState,
  otp,
  errorState,
  handleOtpVerification,
  handleEditNumber,
  handleResendOtp,
}: OtpVerificationModalProps) => {
  const [timer, setTimer] = useState(60);
  const [canResend, setCanResend] = useState(false);

  useEffect(() => {
    const interval = setInterval(() => {
      setTimer(prevTimer => {
        if (prevTimer <= 1) {
          clearInterval(interval);
          setCanResend(true);
          return 0;
        }
        return prevTimer - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  return (
    <>
      <FwTextInputPrimary
        label={LanguageString('Otp')}
        value={otp?.toString()}
        onChangeText={text => updateFormState('otp', text)}
        keyboardType="numeric"
        error={!!errorState.otpError}
        style={styles.inputField}
      />
      {errorState.otpError ? (
        <FwTextPrimary style={styles.errorText}>
          {LanguageString(errorState.otpError)}
        </FwTextPrimary>
      ) : null}
      <FwButtonPrimary
        mode="contained"
        onPress={handleOtpVerification}
        style={styles.signupBtnStyle}>
        <FwTextSecondary type="buttonText">
          {LanguageString('Verify Otp')}
        </FwTextSecondary>
      </FwButtonPrimary>
      {canResend ? (
        <FwButtonPrimary
          mode="outlined"
          onPress={handleResendOtp}
          style={styles.resendBtnStyle}>
          <FwTextPrimary type="buttonText">
            {LanguageString('Resend OTP')}
          </FwTextPrimary>
        </FwButtonPrimary>
      ) : (
        <FwTextPrimary style={styles.timerText}>
          {`${LanguageString('Resend OTP in')} ${timer}s`}
        </FwTextPrimary>
      )}
      <FwButtonPrimary
        mode="outlined"
        onPress={handleEditNumber}
        style={styles.editBtnStyle}>
        <FwTextPrimary type="buttonText">
          {LanguageString('Edit phone number')}
        </FwTextPrimary>
      </FwButtonPrimary>
    </>
  );
};

export default OtpVerificationModal;

const styles = StyleSheet.create({
  inputField: {
    marginBottom: normalized(20),
  },
  signupBtnStyle: {
    marginTop: normalized(20),
    minWidth: normalized(200),
    alignSelf: 'center',
  },
  editBtnStyle: {
    marginTop: normalized(20),
    maxWidth: normalized(230),
    alignSelf: 'center',
  },
  resendBtnStyle: {
    marginTop: normalized(20),
    maxWidth: normalized(230),
    alignSelf: 'center',
  },
  errorText: {
    color: COLORS.ERROR,
    marginBottom: normalized(10),
  },
  timerText: {
    marginTop: normalized(20),
    textAlign: 'center',
  },
});
