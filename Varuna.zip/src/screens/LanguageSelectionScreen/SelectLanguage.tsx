import React from 'react';
import {View, StyleSheet, ImageBackground, SafeAreaView} from 'react-native';
import {COLORS} from '../../constants/colors';
import {HeaderBanner} from '../../components/HeaderBanner';
import {FwButtonPrimary, FwTextPrimary, FwTextSecondary} from '../../elements';
import i18n from '../../language/i18n';
import {CommonActions, useNavigation} from '@react-navigation/native';
import {PAGES} from '../../components/pages';
import {storeLanguage} from '../../services/authService';
import {IMAGES} from '../../assets';
import Loader from '../../components/loader';
import {normalized} from '../../constants/platform';
import {width} from '../../constants/data';
import FwImage from '../../elements/FwImage';
import {setLanguage} from '../../store/appSlice';
import {useDispatch} from 'react-redux';

interface LanguageButtonProps {
  language: string;
  onPress: () => void;
}

const LanguageButton: React.FC<LanguageButtonProps> = ({language, onPress}) => (
  <>
    <FwButtonPrimary style={styles.button} onPress={onPress}>
      <FwTextSecondary type="buttonText">{language}</FwTextSecondary>
    </FwButtonPrimary>
  </>
);

const SelectLanguageView: React.FC = () => {
  const [loaderVisible, setLoaderVisible] = React.useState(false);
  const navigation = useNavigation();
  const dispatch = useDispatch();

  const handleLanguageSelect = async (language: string) => {
    setLoaderVisible(true);

    i18n.changeLanguage(language);
    await storeLanguage(language);
    dispatch(setLanguage(language));
    navigation.dispatch(
      CommonActions.reset({
        index: 0,
        routes: [{name: PAGES.HOME}],
      }),
    );

    setLoaderVisible(false);
  };

  return (
    <SafeAreaView style={styles.safearea}>
      <ImageBackground
        source={IMAGES.FLOOD_WARNING}
        style={styles.backgroundImage}>
        <HeaderBanner />
        <View style={styles.container}>
          <FwImage source={IMAGES.LOGO} style={styles.menuLogo} />
          <FwTextPrimary type="heading_1" style={styles.mb20}>
            भाषा चुनें
          </FwTextPrimary>
          <FwTextPrimary type="heading_1" style={styles.mb20}>
            Select Language
          </FwTextPrimary>
          {loaderVisible ? (
            <View style={styles.loaderContainer}>
              <Loader />
            </View>
          ) : (
            <View style={styles.buttonContainer}>
              <LanguageButton
                language="हिंदी"
                onPress={() => handleLanguageSelect('hi')}
              />
              <LanguageButton
                language="English"
                onPress={() => handleLanguageSelect('en')}
              />
            </View>
          )}
        </View>
      </ImageBackground>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safearea: {
    flex: 1,
  },
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  mb20: {
    marginBottom: normalized(20),
  },
  buttonContainer: {
    justifyContent: 'space-around',
    alignItems: 'center',
    width: normalized(width * 0.7),
  },
  button: {
    margin: normalized(10),
    borderRadius: normalized(10),
    width: width * 0.7,
  },
  btnText: {
    color: COLORS.SECONDARY,
    lineHeight: normalized(23),
    fontSize: normalized(15),
    fontWeight: 'bold',
  },
  backgroundImage: {
    flex: 1,
    resizeMode: 'cover',
  },
  menuLogo: {
    width: normalized(width * 0.25),
    height: normalized(width * 0.25),
    marginHorizontal: normalized(10),
    marginTop: normalized(20),
    marginBottom: normalized(40),
  },
  loaderContainer: {
    height: normalized(140),
  },
});

export default SelectLanguageView;
