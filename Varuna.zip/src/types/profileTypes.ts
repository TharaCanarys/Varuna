export interface Profile {
    firstName: string | null;
    lastName: string | null;
    address: string;
    city: string;
    state: string;
    zipCode: string;
}
export interface PErrors {
    firstName: string;
    lastName: string;
    address: string;
    city: string;
    state: string;
    zipCode: string;
}

export interface PFields {
    name: keyof Profile;
    label: string;
    icon: string;
}