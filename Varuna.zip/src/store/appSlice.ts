import {createSlice, PayloadAction} from '@reduxjs/toolkit';
import { User } from '../types/userTypes';

export interface AppState {
  notifications: any;
  notificationCount: number;
  selectedLanguage: string | null;
  locations: object | Array<any> | null;
  appLanguage: string;
  languageAlert: boolean;
  incidentModal: boolean;
  incidentHeader: boolean;
  dashboardData: any | null;
  floodData: any | null;
  snackMessage: string;
  notificationVisible: boolean;
  users: User[];
}

const initialState: AppState = {
  selectedLanguage: 'hi',
  languageAlert: false,
  incidentModal: false,
  incidentHeader: false,
  notifications: [],
  notificationCount: 2,
  appLanguage: 'hi',
  locations: [],
  dashboardData: null,
  floodData: null,
  snackMessage: '',
  notificationVisible: false,
  users: [],
};

const appSlice = createSlice({
  name: 'app',
  initialState,
  reducers: {
    setLanguage(state, action: PayloadAction<string | null>) {
      state.selectedLanguage = action.payload;
    },
    changeLanguage(state, action: PayloadAction<string>) {
      state.appLanguage = action.payload;
    },
    // Set Locations
    saveLocation(state, action: PayloadAction<object | Array<any> | null>) {
      state.locations = action.payload;
    },
    // Set Dashboard Data
    saveDashboardData(state, action: PayloadAction<any>) {
      state.dashboardData = action.payload;
    },
    showDialog: state => {
      state.languageAlert = true;
    },
    hideDialog: state => {
      state.languageAlert = false;
    },
    changeIncidentModal(state, action: PayloadAction<boolean>) {
      state.incidentModal = action.payload;
    },
    changeIncidentHeader(state, action: PayloadAction<boolean>) {
      state.incidentHeader = action.payload;
    },
    updateNotificationCount(state) {
      if (state.notificationCount > 0) {
        state.notificationCount -= 1;
      }
      // console.log('notification count Updated', state.notificationCount);
    },
    saveFloodData: (state, action: PayloadAction<any>) => {
      state.floodData = action.payload;
    },
    setNotificationVisible(state, action: PayloadAction<boolean>) {
      state.notificationVisible = action.payload;
      if (action.payload) {
        setTimeout(() => {
          state.notificationVisible = false;
        }, 3000);
      }
    },


    setSnackMessage: (state, action: PayloadAction<any>) => {
      state.snackMessage = action.payload;
    },
    setUsers: (state, action: PayloadAction<User[]>) => {
      // console.log("Users Data in redux",action.payload)
      state.users = action.payload;
    },
  },
});

export const {
  setLanguage,
  changeLanguage,
  saveLocation,
  saveDashboardData,
  showDialog,
  hideDialog,
  changeIncidentModal,
  changeIncidentHeader,
  updateNotificationCount,
  saveFloodData,
  setSnackMessage,
  setNotificationVisible,
  setUsers,
} = appSlice.actions;
export default appSlice.reducer;
