import React from 'react';
import DateTimePickerModal from 'react-native-modal-datetime-picker';
import FwTextInputPrimary from './FwTextInputPrimary';
import {LanguageString, width} from '../constants/data';
import {normalized} from '../constants/platform';
import {StyleSheet, TouchableOpacity, View} from 'react-native';
import Icon from 'react-native-vector-icons/MaterialIcons';
import {COLORS} from '../constants/colors';

interface FwDateTimePickerProps {
  isVisible: any;
  label: string;
  onConfirm: any;
  onCancel: any;
  value: any;
  onPress: any;
  mode: 'date' | 'time' | 'datetime';
  minimumDate?: Date;
}

const FwDateTimePicker = ({
  isVisible,
  label,
  onConfirm,
  onCancel,
  value,
  onPress,
  mode,
  minimumDate,
  ...rest
}: FwDateTimePickerProps) => {
  const displayValue =
    mode === 'date'
      ? new Date(value).toLocaleDateString()
      : new Date(value).toLocaleString();

  return (
    <>
      <View style={styles.container}>
        <FwTextInputPrimary
          label={LanguageString(label)}
          value={value === '' ? LanguageString(label) : displayValue}
          style={styles.input}
          editable={false}
          {...rest}
        />
        <TouchableOpacity
          style={styles.iconContainer}
          onPress={() => onPress()}>
          <Icon name="calendar-today" size={24} color={COLORS.PRIMARY} />
        </TouchableOpacity>
      </View>
      <DateTimePickerModal
        isVisible={isVisible}
        mode={mode}
        onConfirm={onConfirm}
        onCancel={onCancel}
        minimumDate={minimumDate}
        {...rest}
      />
    </>
  );
};
export default FwDateTimePicker;

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: COLORS.SECONDARY,
    marginHorizontal: normalized(8),

    borderRadius: 8,
    // width: '100%',
    height: normalized(50),
  },
  input: {
    marginTop: normalized(-8),
    flex: 1,
    width: width - 115,
    height: 50,
    borderWidth: 0,
    backgroundColor: COLORS.SECONDARY,
  },
  iconContainer: {
    position: 'absolute',
    right: 10,
    // height: '100%',
    justifyContent: 'center',
    paddingHorizontal: 10,
  },
  datePicker: {
    marginHorizontal: normalized(8),
  },
});
