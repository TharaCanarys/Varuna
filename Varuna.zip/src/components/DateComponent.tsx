import {StyleSheet, View} from 'react-native';
import {FwTextPrimary} from '../elements';
import {normalized} from '../constants/platform';
import {COLORS} from '../constants/colors';
import {useEffect, useState} from 'react';

export default function DateComponent() {
  const [currentDate, setCurrentDate] = useState('');
  useEffect(() => {
    const timer = setInterval(() => {
      const date = new Date().toLocaleString('en-US', {
        day: '2-digit',
        month: 'short',
        year: 'numeric',
        weekday: 'short',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
        hour12: true,
      });
      setCurrentDate(date);
    }, 1000);

    return () => clearInterval(timer);
  }, []);
  return (
    <View>
      <FwTextPrimary style={styles.dateText}>{currentDate}</FwTextPrimary>
    </View>
  );
}

const styles = StyleSheet.create({
  dateText: {
    fontSize: normalized(11),
    color: COLORS.SECONDARY,
    marginTop: normalized(0),
    marginBottom: normalized(5),
    textAlign: 'center',
  },
});
