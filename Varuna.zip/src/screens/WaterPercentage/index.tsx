import React, {useRef} from 'react';
import {View, StyleSheet, Dimensions} from 'react-native';
import {WebView} from 'react-native-webview';

const WaterPercentage: React.FC = () => {
  const webViewRef = useRef<WebView | null>(null); // Reference for WebView

  // Script to hide navbar and other elements
  const hideNavbarScript = `
    document.querySelector('nav')?.remove();
    document.querySelector('.navbar')?.remove();
    document.querySelector('header')?.remove();
    document.querySelector('.logos-container').style.display = 'none';
    true;
  `;

  // Optional: If you need more control over the script injection, you can still use onLoadEnd
  const onLoadEnd = () => {
    if (webViewRef.current) {
      webViewRef.current.injectJavaScript(hideNavbarScript); // Inject JS after page load
    }
  };

  return (
    <View style={styles.container}>
      <WebView
        ref={webViewRef} // WebView reference
        source={{uri: 'https://ufews.com:8085/Home/WaterPercentageTrend'}}
        style={styles.webview}
        javaScriptEnabled={true}
        domStorageEnabled={true}
        startInLoadingState={true}
        injectedJavaScript={hideNavbarScript} // Inject the script immediately after page load
        onLoadEnd={onLoadEnd} // Optional, for additional control over when the JS is injected
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  webview: {
    width: Dimensions.get('window').width,
    height: Dimensions.get('window').height,
  },
});

export default WaterPercentage;
