import React, {useEffect, useState} from 'react';
import {View, FlatList, StyleSheet} from 'react-native';
import {LanguageString, logsData} from '../../constants/data';
import {COLORS} from '../../constants/colors';
import {Log} from '../../types/commonTypes';
import {useSelector} from 'react-redux';
import {RootState} from '../../store/store';
import translate from 'google-translate-api-x';
import {normalized} from '../../constants/platform';
import {OperationalLogs, LogDetailsModal} from '../../components';

const LogsScreenView = () => {
  const [logs, setLogs] = useState<Log[]>(logsData);
  const [selectedLog, setSelectedLog] = useState<Log | null>(null);
  const [visible, setVisible] = useState(false);

  const showModal = (log: Log) => {
    setSelectedLog(log);
    setVisible(true);
  };

  const language = useSelector(
    (state: RootState) => state.app.selectedLanguage,
  );

  const TranslateData = React.useCallback(async () => {
    try {
      const translatedData = await Promise.all(
        logsData.map(async (data: Log) => {
          if (language === 'hi') {
            const translated = await translate(data.details, {
              from: 'en',
              to: 'hi',
              autoCorrect: true,
            });
            return {
              ...data,
              details: translated.text,
            };
          } else {
            const translated = await translate(data.details, {
              from: 'hi',
              to: 'en',
              autoCorrect: true,
            });
            return {
              ...data,
              details: translated.text,
            };
          }
        }),
      );
      setLogs(translatedData);

      return translatedData;
    } catch (error) {
      console.error('Translation error:', error);
      return logsData;
    }
  }, [language]);
  useEffect(() => {
    TranslateData();
  }, [language, TranslateData]);
  const hideModal = () => {
    setVisible(false);
    setSelectedLog(null);
  };

  const getSeverityStyle = (severity: string) => {
    switch (severity.toLowerCase()) {
      case 'critical':
        return {backgroundColor: COLORS.CRITICAL_BG, color: COLORS.CRITICAL};
      case 'high':
        return {backgroundColor: COLORS.ERROR_BG, color: COLORS.ERROR};
      case 'medium':
        return {backgroundColor: COLORS.WARNING_BG, color: COLORS.WARNING};
      case 'low':
        return {backgroundColor: COLORS.LOW_BG, color: COLORS.LOW};
      case 'info':
        return {backgroundColor: COLORS.INFO_BG, color: COLORS.INFO};
      default:
        return {backgroundColor: COLORS.BG_WHITE, color: COLORS.DARKGRAY};
    }
  };

  const renderItem = ({item}: {item: Log}) => (
    <OperationalLogs
      item={item}
      getSeverityStyle={getSeverityStyle}
      showModal={showModal}
    />
  );

  return (
    <View style={styles.container}>
      <FlatList
        data={logs}
        renderItem={renderItem}
        keyExtractor={item => LanguageString(item.logId)}
        contentContainerStyle={styles.listContainer}
      />
      <LogDetailsModal
        visible={visible}
        selectedLog={selectedLog}
        onDismiss={hideModal}
        getSeverityStyle={getSeverityStyle}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.OFF_WHITE,
    // marginTop: normalized(width * 0.28),
  },
  listContainer: {
    padding: normalized(16),
  },
  boldText: {
    fontWeight: 'bold',
    flex: 0.7,
    letterSpacing: normalized(1.2),
    fontSize: normalized(16),
    color: COLORS.PRIMARY,
  },
  tag: {
    paddingHorizontal: normalized(8),
    paddingVertical: normalized(2),
    borderRadius: normalized(4),
    overflow: 'hidden',
  },
  status: {
    fontWeight: 'bold',
  },
  success: {
    color: COLORS.MEDIUMGREEN,
  },
  error: {
    color: COLORS.ERROR,
  },
});

export default LogsScreenView;
