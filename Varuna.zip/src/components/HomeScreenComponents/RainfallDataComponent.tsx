import React from 'react';
import {View} from 'react-native';
import {Card} from 'react-native-paper';
import {FwTextPrimary} from '../../elements';
import {LanguageString} from '../../constants/data';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import {normalized} from '../../constants/platform';
import {COLORS} from '../../constants/colors';
import { useSelector } from 'react-redux';
import { RootState } from '../../store/store';


const RainfallRiskComponent = ({styles}: any) => {
    const floodData = useSelector((state: RootState) => state.app.floodData);

  const rainfallDetails = [
    {
      icon: "weather-rainy",
      label: "Rainfall (mm)",
      value: floodData?.latestRainfall2 || 0
    },
    {
      icon: "weather-rainy",
      label: "Rainfall last 3 hours",
      value: floodData?.last3HrsRainfall1 || 0
    },
    {
      icon: "weather-rainy",
      label: "Rainfall Previous day",
      value: floodData?.previousDayRainfall2 || 0
    },
    {
      icon: "map-marker-multiple", 
      label: "POI Affected",
      value: floodData?.affectedPOICount || 0
    },
    {
      icon: "alert",
      label: "Wards Affected", 
      value: floodData?.wardsAffectedCount || 0
    }
  ];

  const wardDetails = [
    {
      icon: "check-circle",
      label: "No Risk",
      value: floodData?.noRiskWardCount || 0,
      color: "green"
    },
    {
      icon: "alert-circle",
      label: "High Risk", 
      value: floodData?.highRiskWardCount || 0,
      color: "red"
    },
    {
      icon: "alert",
      label: "Medium Risk",
      value: floodData?.mediumRiskWardCount || 0,
      color: COLORS.WARNING
    },
    {
      icon: "alert-outline",
      label: "Low Risk",
      value: floodData?.lowRiskWardCount || 0,
      color: COLORS.LOW_PRIORITY
    }
  ];

  return (
    <View >
      <Card style={[styles.card, styles.halfCard]}>
        <Card.Content>
          <FwTextPrimary style={styles.cardTitle}>
            {LanguageString('Rainfall Data')}
          </FwTextPrimary>
          {rainfallDetails.map((detail, index) => (
            <View key={index} style={styles.detailRow}>
              <MaterialCommunityIcons
                name={detail.icon}
                size={normalized(20)}
                color={COLORS.PRIMARY}
              />
              <FwTextPrimary style={styles.detailText}>
                {LanguageString(detail.label)}:
              </FwTextPrimary>
              <FwTextPrimary style={styles.valueText}>
                {detail.value}
              </FwTextPrimary>
            </View>
          ))}
        </Card.Content>
      </Card>

      <Card style={[styles.card, styles.halfCard]}>
        <Card.Content>
          <FwTextPrimary style={styles.cardTitle}>
            {LanguageString('Total Wards')} {floodData?.zoneData?.totalWards || "(80)"}
          </FwTextPrimary>
          {wardDetails.map((detail, index) => (
            <View key={index} style={styles.detailRow}>
              <MaterialCommunityIcons
                name={detail.icon}
                size={normalized(20)}
                color={detail.color}
              />
              <FwTextPrimary style={{...styles.detailText, color: detail.color}}>
                {LanguageString(detail.label)}:
              </FwTextPrimary>
              <FwTextPrimary style={{...styles.valueText, color: detail.color}}>
                {detail.value}
              </FwTextPrimary>
            </View>
          ))}
        </Card.Content>
      </Card>
    </View>
  );
};

export default RainfallRiskComponent;
