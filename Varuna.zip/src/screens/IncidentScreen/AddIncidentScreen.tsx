import React, {useCallback, useEffect, useState} from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  Image,
  Alert,
  Modal,
  ScrollView,
  Dimensions,
  ActivityIndicator,
} from 'react-native';
import {launchCamera} from 'react-native-image-picker';
import Geolocation from '@react-native-community/geolocation';
import {FwTextInputPrimary, FwTextPrimary} from '../../elements';
import Loader from '../../components/loader';
import TopBar from '../../navigation/TopBar';
import {PAGES} from '../../components/pages';
import {useNavigation} from '@react-navigation/native';
import {LanguageString} from '../../constants/data';
import {useDispatch, useSelector} from 'react-redux';
import {RootState} from '../../store/store';
import {
  changeIncidentModal,
  // setNotificationVisible,
  setSnackMessage,
} from '../../store/appSlice';
import {isIos, normalized} from '../../constants/platform';
import {COLORS} from '../../constants/colors';
import {HeaderBanner} from '../../components/HeaderBanner';
import {request, PERMISSIONS, RESULTS} from 'react-native-permissions';
import {getIncidentData, uploadIncident} from '../../services/apiServices';
import FWDropdown from '../../elements/FwDropdown';

interface Incident {
  id: number;
  description: string;
  comments: string;
  PictureData: string[];
  latitude: number;
  longitude: number;
  timestamp: string;
  location: string;
  reportedByUserID: number;
}

interface Location {
  latitude: number;
  longitude: number;
}

const {width} = Dimensions.get('window');

const AddIncident: React.FC = () => {
  const [_incidents, _setIncidents] = useState<Incident[]>([]);
  const [_location, setLocation] = useState<Location | null>(null);
  const [description, setDescription] = useState('');
  const [comments, setComments] = useState('');
  const [selectedPictureData, setSelectedPictureData] = useState<string[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [incidentStatus, setIncidentStatus] = useState(0);
  const [incidentCategory, setIncidentCategory] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const dispatch = useDispatch();
  const incidentModal = useSelector(
    (state: RootState) => state.app.incidentModal,
  );
  const incidentHeader = useSelector(
    (state: RootState) => state.app.incidentHeader,
  );
  const UserId = useSelector((state: RootState) => state.auth.userId);

  const getAddressFromCoords = async (
    latitude: number,
    longitude: number,
  ): Promise<string> => {
    try {
      const response = await fetch(
        `https://nominatim.openstreetmap.org/reverse?format=json&lat=${latitude}&lon=${longitude}&zoom=18&addressdetails=1`,
      );
      const data = await response.json();
      return data.display_name || 'Location not found';
    } catch (error) {
      console.error('Error fetching address:', error);
      return 'Location not found';
    }
  };

  const statusOptions = [
    {
      label: LanguageString('Open'),
      value: 0,
    },
    {
      label: LanguageString('Reported'),
      value: 1,
    },
    {
      label: LanguageString('In progress'),
      value: 2,
    },
    {
      label: LanguageString('Resolved'),
      value: 3,
    },
    {
      label: LanguageString('Completed'),
      value: 4,
    },
  ];

  const incidentCategories = [
    {
      label: LanguageString('Nala Block'),
      value: 0,
    },
    {
      label: LanguageString('Overflow'),
      value: 1,
    },
    {
      label: LanguageString('Other'),
      value: 2,
    },
  ];

  const requestPermissions = async () => {
    try {
      if (isIos()) {
        const cameraStatus = await request(PERMISSIONS.IOS.CAMERA);
        const locationStatus = await request(
          PERMISSIONS.IOS.LOCATION_WHEN_IN_USE,
        );

        if (cameraStatus === RESULTS.DENIED) {
          Alert.alert(
            'Camera Permission Required',
            'Camera permission is required to proceed. Please enable it in your device settings.',
          );
          return false;
        }

        // if (locationStatus === RESULTS.DENIED) {
        //   Alert.alert(
        //     'Location Permission Required',
        //     'Location permission is required to proceed. Please enable it in your device settings.',
        //   );

        // return false;
        // }

        return true;
      } else {
        const cameraStatus = await request(PERMISSIONS.ANDROID.CAMERA);
        const locationStatus = await request(
          PERMISSIONS.ANDROID.ACCESS_FINE_LOCATION,
        );

        // if (
        //   cameraStatus === RESULTS.DENIED ||
        //   locationStatus === RESULTS.DENIED
        // ) {
        //   Alert.alert(
        //     'Permissions Denied',
        //     'Camera and location permissions are required to proceed.',
        //   );
        //   return false;
        // }
        return true;
      }
    } catch (err) {
      console.warn(err);
      return false;
    }
  };
  const onGetSuccess = (data: Incident[]) => {
    _setIncidents(data);
  };

  const onGetFailed = useCallback((error: any) => {
    // dispatch(setNotificationVisible(true));
    dispatch(setSnackMessage(error.message));

    console.log('Failed to get incident data', error.message);
  }, []);

  useEffect(() => {
    getIncidents();
  }, []);

  const getIncidents = async () => {
    let payload = [0];
    getIncidentData(payload, onGetSuccess, onGetFailed);
  };

  const handleSubmit = async () => {
    console.log('Handle Submit Called');
    if (!selectedPictureData.length) {
      Alert.alert('Error', 'Please capture an image first');
      return;
    }

    setIsLoading(true);
    try {
      // Get location first
      const position = await new Promise((resolve, reject) => {
        Geolocation.getCurrentPosition(
          pos => resolve(pos),
          error => reject(error),
          {enableHighAccuracy: false, timeout: 50000, maximumAge: 10000},
        );
      });

      const {latitude, longitude} = (position as any).coords;

      // Fetch location address using reverse geocoding with better accuracy
      // const response = await fetch(
      //   `https://maps.googleapis.com/maps/api/geocode/json?latlng=${latitude},${longitude}&result_type=street_address&location_type=ROOFTOP&key=AIzaSyCFyUeUpxcfq26noVgC0hd4v8sVACehddo`,
      // );
      // const locationData = await response.json();
      setLocation({
        latitude,
        longitude,
      });
      

      // Get the image URI
      const imageUri = selectedPictureData[0];
      const imageUri1 = selectedPictureData[1];
      const imageUri2 = selectedPictureData[2];
      // Prepare upload payload
      const imageUris = [imageUri, imageUri1, imageUri2].filter(Boolean);
      const uploadPayload = {
        ReportedByUserID: UserId || 0,
        ReportTime: new Date().toISOString(),
        Latitude: latitude,
        Longitude: longitude,
        Description: description,
        IncidentCategory: incidentCategory,
        isActive: true,
        IncidentStatus: incidentStatus,
        Comments: comments || '',
        PictureFile: imageUris,
      };

      console.log('Upload Payload', uploadPayload);
      // Upload incident
      await uploadIncident(
        uploadPayload,
        setIsLoading,
        (_data: any) => {
          getIncidents();
          Alert.alert('Success', 'Incident uploaded successfully');
          dispatch(changeIncidentModal(false));
          navigation.goBack();
          setDescription('');
          setComments('');
          setSelectedPictureData([]);
          setLocation(null);
        },
        (error: string) => {
          Alert.alert('Error', error);
        },
      );
    } catch (error) {
      // dispatch(setNotificationVisible(true));
      dispatch(setSnackMessage(error?.message));
      console.error('Error submitting incident:', error);
      setError('Error submitting incident');
      // Alert.alert('Error', 'Failed to submit incident. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleCancel = () => {
    dispatch(changeIncidentModal(false));
    setSelectedPictureData([]);
    setDescription('');
    setLocation(null);
  };

  const handleOpenCamera = async () => {
    const hasPermission = await requestPermissions();
    if (!hasPermission) return;

    if (selectedPictureData.length >= 3) {
      Alert.alert('Limit Reached', 'You can only capture up to 3 images.');
      return;
    }

    launchCamera({mediaType: 'photo', quality: 0.2}, response => {
      if (response.didCancel) {
        console.log('User cancelled camera');
      } else if (response.errorMessage) {
        console.log('Camera error: ', response.errorMessage);
      } else {
        const {assets} = response;
        if (assets && assets.length > 0) {
          const image = assets[0];
          if (image.uri) {
            setSelectedPictureData((prev: string[]) => [
              ...prev,
              image.uri as string,
            ]);
          }
        }
      }
    });
  };

  const handleDeleteImage = (index: number) => {
    setSelectedPictureData(prev => prev.filter((_, i) => i !== index));
  };
  const navigation = useNavigation();

  const renderIncident = ({item}: {item: Incident}) => (
    <View style={styles.card}>
      <View style={styles.cardHeader}>
        <FwTextPrimary style={styles.status}>
          {LanguageString('Status')}: {LanguageString('Open')}
        </FwTextPrimary>
      </View>
      {item?.description ? (
        <FwTextPrimary style={styles.cardDescription}>
          {LanguageString('Description')}: {item?.description}
        </FwTextPrimary>
      ) : null}
      {item?.comments ? (
        <FwTextPrimary style={styles.cardDescription}>
          {LanguageString('Comment')}: {item?.comments}
        </FwTextPrimary>
      ) : null}
      <FwTextPrimary style={styles.timestamp}>{item?.timestamp}</FwTextPrimary>
      <ScrollView
        horizontal
        pagingEnabled
        showsHorizontalScrollIndicator={true}
        style={styles.imageContainer}>
        {item?.PictureData && (
          <Image
            source={{
              uri: `data:image/jpeg;base64,${item.PictureData}`,
            }}
            style={[styles.image, {width: width - 40, height: 200}]}
            resizeMode="cover"
          />
        )}
      </ScrollView>
      <FwTextPrimary style={styles.titleText}>
        {LanguageString('Location')}:
        <FwTextPrimary style={styles.locationText}>
          {' '}
          {`${item?.latitude}, ${item?.longitude}`}
        </FwTextPrimary>
      </FwTextPrimary>
    </View>
  );

  return (
    <>
      {incidentHeader ? (
        <>
          <HeaderBanner />
          <TopBar navigation={navigation} routeName={PAGES.ADDINCIDENT} />
        </>
      ) : null}
      <View style={styles.container}>
        <FwTextPrimary style={styles.header}>
          {LanguageString('Incidents')}
        </FwTextPrimary>
        {isLoading ? (
          <View style={styles.loaderContainer}>
            <Loader />
          </View>
        ) : (
          <FlatList
            data={_incidents}
            renderItem={renderIncident}
            keyExtractor={item => item?.id?.toString()}
            contentContainerStyle={styles.list}
          />
        )}
        <Modal
          visible={incidentModal}
          animationType="slide"
          transparent={true}
          onRequestClose={() => dispatch(changeIncidentModal(false))}>
          <ScrollView
            contentContainerStyle={styles.modalContainer}
            style={{flex: 1, width: '100%'}}>
            <View style={styles.modalContent}>
              <View style={styles.inputContainer}>
                <FwTextInputPrimary
                  style={{...styles.input, ...styles.descriptionInput}}
                  placeholder={LanguageString('Description')}
                  value={description}
                  onChangeText={(text: string) => {
                    setDescription(text);
                  }}
                  multiline
                />
                <FwTextInputPrimary
                  style={{...styles.input, ...styles.commentsInput}}
                  placeholder={LanguageString('Comments')}
                  value={comments}
                  onChangeText={(text: string) => {
                    setComments(text);
                  }}
                  multiline
                />
                <View style={styles.imageContainer}>
                  {selectedPictureData.map((uri, index) => (
                    <View key={index} style={styles.imageWrapper}>
                      <Image source={{uri: uri}} style={styles.previewImage} />
                      <TouchableOpacity
                        style={styles.deleteButton}
                        onPress={() => handleDeleteImage(index)}>
                        <Text style={styles.deleteButtonText}>×</Text>
                      </TouchableOpacity>
                    </View>
                  ))}
                </View>
                <View style={{marginVertical: 10}}>
                  <FwTextPrimary style={{...styles.titleText, marginLeft: 10}}>
                    {LanguageString('Incident Status')}
                  </FwTextPrimary>
                  <FWDropdown
                    multiple={false}
                    label={LanguageString('Select Status')}
                    options={statusOptions}
                    value={incidentStatus}
                    onSelect={(itemValue: number) =>
                      setIncidentStatus(itemValue)
                    }
                  />
                </View>
                <View style={{marginVertical: 10}}>
                  <FwTextPrimary style={{...styles.titleText, marginLeft: 10}}>
                    {LanguageString('Incident Category')}
                  </FwTextPrimary>
                  <FWDropdown
                    multiple={false}
                    label={LanguageString('Select Category')}
                    options={incidentCategories}
                    value={incidentCategory}
                    onSelect={(itemValue: number) =>
                      setIncidentCategory(itemValue)
                    }
                  />
                </View>

                <TouchableOpacity
                  style={[
                    styles.cameraButton,
                    selectedPictureData.length >= 3 && styles.disabledButton,
                  ]}
                  onPress={handleOpenCamera}
                  disabled={selectedPictureData.length >= 3}>
                  <Text style={styles.cameraButtonText}>
                  {LanguageString('Upload Image')} (
                    {selectedPictureData.length}/3)
                  </Text>
                </TouchableOpacity>
              </View>
              <View style={styles.modalButtons}>
                <TouchableOpacity
                  style={styles.modalButton}
                  onPress={() => {
                    handleCancel();
                  }}>
                  <Text style={styles.modalButtonText}>
                    {LanguageString('Cancel')}
                  </Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={[styles.modalButton, styles.submitButton]}
                  onPress={handleSubmit}
                  disabled={isLoading}>
                  <Text style={styles.modalButtonText}>
                    {isLoading ? (
                      <ActivityIndicator size="small" color="#fff" />
                    ) : (
                      LanguageString('Submit')
                    )}
                  </Text>
                </TouchableOpacity>
              </View>
              {error && (
                <Text style={styles.errorText}>{error}</Text>
              )}
            </View>
          </ScrollView>
        </Modal>
        <TouchableOpacity
          style={styles.addButton}
          onPress={() => dispatch(changeIncidentModal(true))}>
          <Text style={styles.addButtonText}>+</Text>
        </TouchableOpacity>
      </View>
    </>
  );
};
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  loaderContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  header: {
    fontSize: normalized(24),
    fontWeight: 'bold',
    textAlign: 'center',
    marginVertical: normalized(10),
  },
  inputContainer: {
    padding: normalized(10),
  },
  input: {
    backgroundColor: '#fff',
    borderRadius: normalized(5),
    padding: normalized(10),
    marginBottom: normalized(10),
    borderWidth: 1,
    borderColor: '#ddd',
  },
  descriptionInput: {
    height: normalized(80),
    textAlignVertical: 'top',
  },
  commentsInput: {
    height: normalized(80),
    textAlignVertical: 'top',
  },
  list: {
    padding: normalized(10),
  },
  card: {
    backgroundColor: '#fff',
    padding: normalized(15),
    borderRadius: normalized(10),
    marginBottom: normalized(10),
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowRadius: normalized(5),
    elevation: 2,
  },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: normalized(5),
  },
  cardTitle: {
    fontSize: normalized(18),
    fontWeight: 'bold',
    flex: 1,
  },
  cardDescription: {
    fontSize: normalized(14),
    color: '#666',
    marginBottom: normalized(10),
  },
  timestamp: {
    fontSize: normalized(12),
    color: '#888',
    marginBottom: normalized(10),
    fontStyle: 'italic',
  },
  image: {
    width: '100%',
    height: normalized(200),
    borderRadius: normalized(10),
    marginBottom: normalized(10),
  },
  previewImage: {
    width: '100%',
    height: normalized(200),
    borderRadius: normalized(10),
    marginBottom: normalized(10),
  },
  locationText: {
    fontSize: normalized(14),
    color: '#666',
  },
  titleText: {
    fontSize: normalized(16),
    fontWeight: 'bold',
    marginBottom: normalized(5),
  },
  status: {
    fontSize: normalized(18),
    marginLeft: normalized(10),
    marginRight: normalized(10),
    color: COLORS.SUCCESS,
  },
  addButton: {
    position: 'absolute',
    bottom: normalized(20),
    right: normalized(20),
    width: normalized(60),
    height: normalized(60),
    backgroundColor: COLORS.BLUE,
    borderRadius: normalized(30),
    justifyContent: 'center',
    alignItems: 'center',
    elevation: 5,
  },
  addButtonText: {
    fontSize: normalized(36),
    color: '#fff',
    fontWeight: 'bold',
  },
  modalContainer: {
    minHeight: '100%',
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    paddingVertical: normalized(20),
  },
  modalContent: {
    backgroundColor: '#fff',
    width: '90%',
    borderRadius: normalized(10),
    padding: normalized(20),
  },
  modalButtons: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: normalized(20),
  },
  modalButton: {
    flex: 1,
    padding: normalized(10),
    marginHorizontal: normalized(5),
    borderRadius: normalized(5),
    backgroundColor: COLORS.DARKGRAY,
    alignItems: 'center',
  },
  submitButton: {
    backgroundColor: COLORS.SUCCESS,
  },
  modalButtonText: {
    color: '#fff',
    fontSize: normalized(16),
    fontWeight: 'bold',
  },
  cameraButton: {
    backgroundColor: COLORS.PRIMARY,
    width: normalized(200),
    padding: normalized(12),
    borderRadius: normalized(5),
    alignItems: 'center',
    marginTop: normalized(10),
    alignSelf: 'center',
  },
  cameraButtonText: {
    color: COLORS.SECONDARY,
    fontSize: normalized(16),
    fontWeight: 'bold',
    textAlign: 'center',
  },
  imageContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginBottom: normalized(10),
  },
  disabledButton: {
    opacity: 0.5,
  },
  deleteButton: {
    position: 'absolute',
    top: normalized(5),
    right: normalized(5),
    backgroundColor: 'white',
    borderRadius: normalized(12),
    width: normalized(24),
    height: normalized(24),
    justifyContent: 'center',
    alignItems: 'center',
  },
  deleteButtonText: {
    color: 'red',
    fontSize: normalized(20),
    fontWeight: 'bold',
  },
  imageWrapper: {
    position: 'relative',
    width: '100%',
    marginBottom: normalized(10),
  },
  // INcident
  dropdown: {
    width: '100%',
    marginBottom: normalized(10),
  },
});

export default AddIncident;
