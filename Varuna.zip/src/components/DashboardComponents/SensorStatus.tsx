import React from 'react';
import {Card, Divider, List} from 'react-native-paper';
import {LanguageString} from '../../constants/data';
import {StyleSheet} from 'react-native';
import {commonStyle} from '../../constants/theme';

const SensorStatus = ({data}: {data: any}) => {
  const sensorStatus = [
    {id: 1, status: LanguageString('Active')},
    {id: 2, status: LanguageString('Inactive')},
    {id: 3, status: LanguageString('Maintenance')},
  ];
  return (
    <Card style={commonStyle.card}>
      <Card.Content>
        {sensorStatus.map((sensor: any) => (
          <React.Fragment key={sensor.id}>
            <List.Item
              title={
                LanguageString('Sensor') +
                ' ' +
                sensor.id +
                ':' +
                ' ' +
                LanguageString(sensor.status)
              }
              left={props => (
                <List.Icon
                  {...props}
                  icon={
                    sensor.status == LanguageString('Active')
                      ? 'check-circle'
                      : sensor.status === LanguageString('Inactive')
                      ? 'close-circle'
                      : 'progress-wrench'
                  }
                  color={
                    sensor.status == LanguageString('Active')
                      ? 'green'
                      : sensor.status === LanguageString('Inactive')
                      ? 'red'
                      : 'orange'
                  }
                />
              )}
            />
            <Divider />
          </React.Fragment>
        ))}
      </Card.Content>
    </Card>
  );
};
export default SensorStatus;
