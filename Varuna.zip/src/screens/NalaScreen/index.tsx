import React from 'react';
import { Text } from 'react-native-paper';

const NalaScreen: React.FC = () => {
  return (<Text>Nala Screen</Text>);
};

export default NalaScreen;
