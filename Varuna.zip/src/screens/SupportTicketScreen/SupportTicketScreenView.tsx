import React, {useState, useCallback, useEffect} from 'react';
import {
  View,
  StyleSheet,
  RefreshControl,
  FlatList,
  ScrollView,
} from 'react-native';
import {Card, HelperText} from 'react-native-paper';

import {
  FwButtonPrimary,
  FwDialog,
  FwTextInputPrimary,
  FwTextPrimary,
  FwTextSecondary,
} from '../../elements';
import {SupportTicketPropTypes} from '../../types/commonTypes';
import FWDropdown from '../../elements/FwDropdown';
import {COLORS} from '../../constants/colors';
import PageHeader from '../../components/PageHeader';
import {LanguageString, USER_ROLES} from '../../constants/data';
import {IMAGES} from '../../assets';
import {commonStyle} from '../../constants/theme';
import {useSelector} from 'react-redux';
import {RootState} from '../../store/store';
import {normalized} from '../../constants/platform';
import FwImage from '../../elements/FwImage';
import FwModal from '../../elements/FwModal';

interface ErrorState {
  location: '';
  category: '';
  priority: '';
  raisedBy: '';
  raisedDate: '';
  status: '';
  assignedTo: '';
  resolvedDate: '';
  assetType: '';
  description: '';
  resolutionDetails: '';
  remarks: '';
}

const SupportTicketScreenView: React.FC = () => {
  const [selectedSupportTicket, setSelectedSupportTicket] =
    useState<SupportTicketPropTypes | null>(null);
  const [editingStatus, setEditingStatus] = useState<boolean>(false);
  const [newStatus, setNewStatus] = useState<string>('');
  const [statusError, setStatusError] = useState<string>('');
  const [supportTickets, setSupportTickets] =
    useState<SupportTicketPropTypes[]>(supportTicketData);
  const [isAddingNewSupportTicket, setIsAddingNewSupportTicket] =
    useState<boolean>(false);

  const priorityOptions = [
    {label: LanguageString('High'), value: 'High'},
    {label: LanguageString('Medium'), value: 'Medium'},
    {label: LanguageString('Low'), value: 'Low'},
  ];
  const assetsTypeOptions = [
    {label: LanguageString('Application'), value: 'Application'},
    {label: LanguageString('Asset'), value: 'Asset'},
    {label: LanguageString('Sensor'), value: 'Sensor'},
  ];
  const categoryOptions = [
    {label: LanguageString('Technical'), value: 'Technical'},
    {label: LanguageString('Operational'), value: 'Operational'},
    {label: LanguageString('Maintenance'), value: 'Maintenance'},
  ];
  const locationOptions = [
    {label: LanguageString('Rapti Nagar'), value: 'Rapti Nagar'},
    {label: LanguageString('Om Nagar'), value: 'Om Nagar'},
    {label: LanguageString('Rasoolpur'), value: 'Rasoolpur'},
  ];
  const language = useSelector(
    (state: RootState) => state.app.selectedLanguage,
  );
  const [newSupportTicket, setNewSupportTicket] =
    useState<SupportTicketPropTypes>({
      id: 0,
      location: '',
      category: '',
      priority: '',
      raisedBy: '',
      raisedDate: '',
      status: '',
      assignedTo: '',
      resolvedDate: '',
      assetType: '',
      description: '',
      resolutionDetails: '',
      remarks: '',
    });
  // TODO: Translation String
  // useEffect(() => {
  //   if (selectedSupportTicket != null) {
  //     values(selectedSupportTicket.assignedTo);
  //     console.log('New Support :', selectedSupportTicket.assignedTo);
  //   }
  // }, [editingStatus, newStatus, selectedSupportTicket]);

  // const values = async (text: string) => {
  //   try {
  //     const translation = await TranslateString(text);
  //     console.log('Async Translated', translation);
  //     return translation;
  //   } catch (error) {
  //     console.error('Translation error:', error);
  //     return text;
  //   }
  // };
  const [errors, setErrors] = useState<ErrorState>({
    location: '',
    category: '',
    priority: '',
    raisedBy: '',
    raisedDate: '',
    status: '',
    assignedTo: '',
    resolvedDate: '',
    assetType: '',
    description: '',
    resolutionDetails: '',
    remarks: '',
  });

  const [refreshing, setRefreshing] = useState<boolean>(false);
  const [deleteConfirmationVisible, setDeleteConfirmationVisible] =
    useState<boolean>(false);
  const [supportTicketToDelete, setSupportTicketToDelete] = useState<
    number | null
  >(null);

  // Memoized status options
  const statusOptions = [
    {label: LanguageString('Open'), value: 'Open'},
    {label: LanguageString('In progress'), value: 'In progress'},
    {label: LanguageString('Completed'), value: 'Completed'},
  ];

  // Memoized assigned to options
  const assignedToOptions = [
    {label: LanguageString('Rahul Sharma'), value: 'Rahul Sharma'},
    {label: LanguageString('Amit Patel'), value: 'Amit Patel'},
    {label: LanguageString('Vikram Singh'), value: 'Vikram Singh'},
    {label: LanguageString('Rajesh Kumar'), value: 'Rajesh Kumar'},
  ];

  useEffect(() => {
    onRefresh();
  }, [language]);
  const onRefresh = useCallback(() => {
    setRefreshing(true);
    // Simulate fetching new data
    setTimeout(() => {
      setSupportTickets([...supportTicketData]); // Reset supportTickets to initial data for demonstration
      setRefreshing(false);
    }, 2000);
  }, []);

  const openSupportTicketDetails = useCallback(
    (supportTicket: SupportTicketPropTypes) => {
      setSelectedSupportTicket(supportTicket);
      setNewStatus(supportTicket.status);
    },
    [],
  );

  const closeSupportTicketDetails = useCallback(() => {
    setSelectedSupportTicket(null);
    setEditingStatus(false);
  }, []);
  const role = useSelector((state: RootState) => state.auth.userRole);

  const validateRole =
    role == USER_ROLES.ADMIN ||
    role == USER_ROLES.SUPER_ADMIN ||
    role == USER_ROLES.IT_SUPPORT;
  const startEditingStatus = useCallback(() => {
    if (
      selectedSupportTicket &&
      selectedSupportTicket.status !== LanguageString('Completed')
    ) {
      setEditingStatus(prev => !prev);
    }
  }, [selectedSupportTicket]);

  const saveStatus = useCallback(() => {
    if (selectedSupportTicket) {
      const currentDate = new Date().toLocaleString('en-US', {
        timeZone: 'Asia/Kolkata',
      });
      const updatedSupportTicket = {
        ...selectedSupportTicket,
        status: newStatus,
        resolvedDate:
          newStatus === LanguageString('Completed')
            ? currentDate
            : selectedSupportTicket.resolvedDate,
      };
      setSupportTickets(prevSupportTickets =>
        prevSupportTickets.map(supportTicket =>
          supportTicket.id === selectedSupportTicket.id
            ? updatedSupportTicket
            : supportTicket,
        ),
      );
      setSelectedSupportTicket(updatedSupportTicket);
      setEditingStatus(false);
    }
  }, [selectedSupportTicket, newStatus]);

  const validateStatus = useCallback((status: string) => {
    if (!status) {
      setStatusError(LanguageString('Status') + LanguageString('is required'));
    } else {
      setStatusError('');
    }
  }, []);

  const openAddNewSupportTicket = useCallback(() => {
    setIsAddingNewSupportTicket(true);
    const currentDate = new Date().toLocaleString('en-US', {
      timeZone: 'Asia/Kolkata',
    });
    setNewSupportTicket(prev => ({
      ...prev,
      raisedDate: currentDate,
    }));
  }, []);

  const closeAddNewSupportTicket = useCallback(() => {
    setIsAddingNewSupportTicket(false);
    setNewSupportTicket({
      id: 0,
      location: '',
      category: '',
      priority: '',
      raisedBy: '',
      raisedDate: '',
      status: '',
      assignedTo: '',
      resolvedDate: '',
      assetType: '',
      description: '',
      resolutionDetails: '',
      remarks: '',
    });
    setErrors({
      location: '',
      category: '',
      priority: '',
      raisedBy: '',
      raisedDate: '',
      status: '',
      assignedTo: '',
      resolvedDate: '',
      assetType: '',
      description: '',
      resolutionDetails: '',
      remarks: '',
    });
  }, []);

  const validateNewSupportTicket = useCallback(() => {
    let isValid = true;
    const newErrors: ErrorState = {
      location: '',
      category: '',
      priority: '',
      raisedBy: '',
      raisedDate: '',
      status: '',
      assignedTo: '',
      resolvedDate: '',
      assetType: '',
      description: '',
      resolutionDetails: '',
      remarks: '',
    };

    if (!newSupportTicket.location) {
      newErrors.location = (LanguageString('Location') +
        ' ' +
        LanguageString('is required')) as '';
      isValid = false;
    }
    if (!newSupportTicket.category) {
      newErrors.category = (LanguageString('Category') +
        ' ' +
        LanguageString('is required')) as '';
      isValid = false;
    }
    if (!newSupportTicket.priority) {
      newErrors.priority = (LanguageString('Priority') +
        ' ' +
        LanguageString('is required')) as '';
      isValid = false;
    }
    if (!newSupportTicket.assignedTo) {
      newErrors.assignedTo = (LanguageString('Assigned To') +
        ' ' +
        LanguageString('is required')) as '';
      isValid = false;
    }
    if (!newSupportTicket.assetType) {
      newErrors.assetType = (LanguageString('Asset Type') +
        ' ' +
        LanguageString('is required')) as '';
      isValid = false;
    }
    if (!newSupportTicket.description) {
      newErrors.description = (LanguageString('Description') +
        ' ' +
        LanguageString('is required')) as '';
      isValid = false;
    }
    if (!newSupportTicket.resolutionDetails) {
      newErrors.resolutionDetails = (LanguageString('Resolution Details') +
        ' ' +
        LanguageString('is required')) as '';
      isValid = false;
    }
    if (!newSupportTicket.remarks) {
      newErrors.remarks = (LanguageString('Remarks') +
        ' ' +
        LanguageString('is required')) as '';
      isValid = false;
    }

    setErrors(newErrors);
    return isValid;
  }, [newSupportTicket]);
  const handleAddNewSupportTicket = useCallback(() => {
    if (validateNewSupportTicket()) {
      const newId = Math.max(...supportTickets.map(s => s.id), 0) + 1;
      const supportTicketToAdd = {
        ...newSupportTicket,
        id: newId,
        status: 'Open',
        raisedDate: new Date().toLocaleString('en-US', {
          timeZone: 'Asia/Kolkata',
        }),
      };
      setSupportTickets(prev => [...prev, supportTicketToAdd]);
      closeAddNewSupportTicket();
    }
  }, [
    newSupportTicket,
    supportTickets,
    validateNewSupportTicket,
    closeAddNewSupportTicket,
  ]);

  const showDeleteConfirmation = useCallback((id: number) => {
    setSupportTicketToDelete(id);
    setDeleteConfirmationVisible(true);
  }, []);

  const hideDeleteConfirmation = useCallback(() => {
    setDeleteConfirmationVisible(false);
    setSupportTicketToDelete(null);
  }, []);

  const handleDeleteSupportTicket = useCallback(() => {
    if (supportTicketToDelete !== null) {
      setSupportTickets(prev =>
        prev.filter(
          supportTicket => supportTicket.id !== supportTicketToDelete,
        ),
      );
      hideDeleteConfirmation();
    }
  }, [supportTicketToDelete, hideDeleteConfirmation]);

  // Memoized render item for FlatList
  const renderItem = useCallback(
    ({item: supportTicket}: {item: SupportTicketPropTypes}) => (
      <Card
        style={styles.supportTicketCard}
        onPress={() => openSupportTicketDetails(supportTicket)}>
        <Card.Title
          title={LanguageString('Support Ticket') + ' ' + supportTicket.id}
          titleStyle={commonStyle.cardHeaderText}
          left={() => (
            <View style={styles.cardImage}>
              <FwImage
                source={IMAGES.SUPPORTTICKET}
                style={styles.cardImageIcon}
              />
            </View>
          )}
          right={props =>
            validateRole ? (
              <View style={styles.cardActions}>
                {/* <IconButton
                  {...props}
                  icon="pencil"
                  onPress={() => {
                    openSupportTicketDetails(supportTicket);
                    setEditingStatus(true);
                    startEditingStatus();
                  }}
                  disabled={
                    supportTicket.status === LanguageString('Completed')
                  }
                />
                <IconButton
                  {...props}
                  icon="delete"
                  onPress={() => showDeleteConfirmation(supportTicket.id)}
                /> */}
              </View>
            ) : null
          }
        />
        <Card.Content style={styles.cardContent}>
          <View style={commonStyle.modalRow}>
            <FwTextPrimary style={commonStyle.boldText}>
              {LanguageString('Location') + ' : '}
            </FwTextPrimary>
            <FwTextPrimary style={commonStyle.normalText}>
              {LanguageString(supportTicket.location)}
            </FwTextPrimary>
          </View>
          <View style={commonStyle.modalRow}>
            <FwTextPrimary style={commonStyle.boldText}>
              {LanguageString('Priority') + ' : '}
            </FwTextPrimary>
            <FwTextPrimary style={commonStyle.normalText}>
              {LanguageString(supportTicket.priority)}
            </FwTextPrimary>
          </View>
          <View style={commonStyle.modalRow}>
            <FwTextPrimary style={commonStyle.boldText}>
              {LanguageString('Status') + ' : '}
            </FwTextPrimary>
            <FwTextPrimary style={commonStyle.normalText}>
              {LanguageString(supportTicket.status)}
            </FwTextPrimary>
          </View>
        </Card.Content>
      </Card>
    ),
    [openSupportTicketDetails, showDeleteConfirmation, startEditingStatus],
  );

  return (
    <>
      <PageHeader title="Support Ticket" />
      <View style={commonStyle.addButtonContainer}>
        {validateRole ? (
          <FwButtonPrimary
            mode="outlined"
            onPress={openAddNewSupportTicket}
            icon="plus">
            <FwTextPrimary> {LanguageString('Add New')}</FwTextPrimary>
          </FwButtonPrimary>
        ) : null}
      </View>
      <FlatList
        data={supportTickets}
        renderItem={renderItem}
        keyExtractor={item => item.id.toString()}
        contentContainerStyle={styles.container}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
        }
      />
      {/* SupportTicket Details Modal */}
      <FwModal
        visible={selectedSupportTicket !== null}
        onDismiss={closeSupportTicketDetails}
        contentContainerStyle={styles.modalContainer}>
        {selectedSupportTicket && (
          <ScrollView>
            <View style={commonStyle.modalHeader}>
              <FwTextPrimary style={commonStyle.modalTitle}>
                {LanguageString('Support Ticket') +
                  ' ' +
                  LanguageString('Details')}
              </FwTextPrimary>
              {/* {validateRole ? (
                  <IconButton
                    icon="pencil"
                    size={24}
                    onPress={startEditingStatus}
                    disabled={
                      selectedSupportTicket.status ===
                      LanguageString('Completed')
                    }
                  />
                ) : null} */}
            </View>

            <View style={commonStyle.modalRow}>
              <FwTextPrimary style={commonStyle.boldText}>
                {LanguageString('Location') + ' '}:
              </FwTextPrimary>
              <FwTextPrimary style={commonStyle.normalText}>
                {LanguageString(selectedSupportTicket.location)}
              </FwTextPrimary>
            </View>
            <View style={commonStyle.modalRow}>
              <FwTextPrimary style={commonStyle.boldText}>
                {LanguageString('Category') + ' '}:
              </FwTextPrimary>
              <FwTextPrimary style={commonStyle.normalText}>
                {LanguageString(selectedSupportTicket.category)}
              </FwTextPrimary>
            </View>
            <View style={commonStyle.modalRow}>
              <FwTextPrimary style={commonStyle.boldText}>
                {LanguageString('Priority') + ' '}:
              </FwTextPrimary>
              <FwTextPrimary style={commonStyle.normalText}>
                {LanguageString(selectedSupportTicket.priority)}
              </FwTextPrimary>
            </View>
            <View style={commonStyle.modalRow}>
              <FwTextPrimary style={commonStyle.boldText}>
                {LanguageString('Raised By') + ' '}:
              </FwTextPrimary>
              <FwTextPrimary style={commonStyle.normalText}>
                {LanguageString(selectedSupportTicket.raisedBy)}
              </FwTextPrimary>
            </View>
            <View style={commonStyle.modalRow}>
              <FwTextPrimary style={commonStyle.boldText}>
                {LanguageString('Raised Date') + ' '}:
              </FwTextPrimary>
              <FwTextPrimary style={commonStyle.normalText}>
                {LanguageString(selectedSupportTicket.raisedDate)}
              </FwTextPrimary>
            </View>
            <View style={commonStyle.modalRow}>
              <FwTextPrimary style={commonStyle.boldText}>
                {LanguageString('Status') + ' '}:
              </FwTextPrimary>
              <FwTextPrimary style={commonStyle.normalText}>
                {LanguageString(selectedSupportTicket.status)}
              </FwTextPrimary>
            </View>
            <View style={commonStyle.modalRow}>
              <FwTextPrimary style={commonStyle.boldText}>
                {LanguageString('Assigned To') + ' '}:
              </FwTextPrimary>
              <FwTextPrimary style={commonStyle.normalText}>
                {LanguageString(selectedSupportTicket.assignedTo)}
              </FwTextPrimary>
            </View>
            <View style={commonStyle.modalRow}>
              <FwTextPrimary style={commonStyle.boldText}>
                {LanguageString('Resolved Date') + ' '}:
              </FwTextPrimary>
              <FwTextPrimary style={commonStyle.normalText}>
                {LanguageString(selectedSupportTicket.resolvedDate)}
              </FwTextPrimary>
            </View>
            <View style={commonStyle.modalRow}>
              <FwTextPrimary style={commonStyle.boldText}>
                {LanguageString('Asset Type') + ' '}:
              </FwTextPrimary>
              <FwTextPrimary style={commonStyle.normalText}>
                {LanguageString(selectedSupportTicket.assetType)}
              </FwTextPrimary>
            </View>
            <View style={commonStyle.modalRow}>
              <FwTextPrimary style={commonStyle.boldText}>
                {LanguageString('Description') + ' '}:
              </FwTextPrimary>
              <FwTextPrimary style={commonStyle.normalText}>
                {LanguageString(selectedSupportTicket.description)}
              </FwTextPrimary>
            </View>
            <View style={commonStyle.modalRow}>
              <FwTextPrimary style={commonStyle.boldText}>
                {LanguageString('Resolution Details') + ' '}:
              </FwTextPrimary>
              <FwTextPrimary style={commonStyle.normalText}>
                {LanguageString(selectedSupportTicket.resolutionDetails)}
              </FwTextPrimary>
            </View>
            <View style={commonStyle.modalRow}>
              <FwTextPrimary style={commonStyle.boldText}>
                {LanguageString('Remarks') + ' '}:
              </FwTextPrimary>
              <FwTextPrimary style={commonStyle.normalText}>
                {LanguageString(selectedSupportTicket.remarks)}
              </FwTextPrimary>
            </View>
            {editingStatus && (
              <FWDropdown
                multiple={false}
                label={LanguageString('Select Status')}
                options={statusOptions}
                value={newStatus}
                onSelect={(value: string | undefined) => {
                  if (value !== undefined) {
                    setNewStatus(value);
                    validateStatus(value);
                  }
                }}
              />
            )}
            {editingStatus && (
              <FwButtonPrimary
                onPress={saveStatus}
                style={commonStyle.saveButton}>
                <FwTextSecondary>{LanguageString('Save')}</FwTextSecondary>
              </FwButtonPrimary>
            )}
            <FwButtonPrimary
              onPress={closeSupportTicketDetails}
              style={commonStyle.closeButton}>
              <FwTextSecondary>{LanguageString('Cancel')}</FwTextSecondary>
            </FwButtonPrimary>
          </ScrollView>
        )}
      </FwModal>
      {/* Add New SupportTicket Modal */}
      <FwModal
        visible={isAddingNewSupportTicket}
        onDismiss={closeAddNewSupportTicket}
        contentContainerStyle={styles.modalContainer}>
        <ScrollView>
          <View style={commonStyle.modalHeader}>
            <FwTextPrimary style={commonStyle.modalTitle}>
              {LanguageString('Add New Support Ticket')}
            </FwTextPrimary>
          </View>

          <FWDropdown
            multiple={false}
            label={LanguageString('Select Location')}
            options={locationOptions}
            value={newSupportTicket.location}
            onSelect={(value: string | undefined) => {
              if (value !== undefined) {
                setNewSupportTicket({...newSupportTicket, location: value});
              }
            }}
          />

          <HelperText type="error" visible={!!errors.location}>
            {errors.location}
          </HelperText>

          <FWDropdown
            multiple={false}
            label={LanguageString('Select Category')}
            options={categoryOptions}
            value={newSupportTicket.category}
            onSelect={(value: string | undefined) => {
              if (value !== undefined) {
                setNewSupportTicket({...newSupportTicket, category: value});
              }
            }}
          />

          <HelperText type="error" visible={!!errors.category}>
            {errors.category}
          </HelperText>

          <FwTextInputPrimary
            label={LanguageString('Enter description')}
            value={newSupportTicket.description}
            onChangeText={(text: string) => {
              setNewSupportTicket({
                ...newSupportTicket,
                description: text,
              });
            }}
            style={{...styles.input, ...styles.descriptionInput}}
            multiline
          />
          <HelperText type="error" visible={!!errors.description}>
            {errors.description}
          </HelperText>

          <FWDropdown
            multiple={false}
            label={LanguageString('Select Priority')}
            options={priorityOptions}
            value={newSupportTicket.priority}
            onSelect={(value: string | undefined) => {
              if (value !== undefined) {
                setNewSupportTicket({...newSupportTicket, priority: value});
              }
            }}
          />

          <HelperText type="error" visible={!!errors.priority}>
            {errors.priority}
          </HelperText>
          <FWDropdown
            multiple={false}
            label={LanguageString('Select Assigned To')}
            options={assignedToOptions}
            value={newSupportTicket.assignedTo}
            onSelect={(value: string | undefined) => {
              if (value !== undefined) {
                setNewSupportTicket({...newSupportTicket, assignedTo: value});
              }
            }}
          />

          <HelperText type="error" visible={!!errors.assignedTo}>
            {errors.assignedTo}
          </HelperText>

          <FwTextInputPrimary
            label={LanguageString('Resolution Details')}
            value={newSupportTicket.resolutionDetails}
            onChangeText={(text: string) =>
              setNewSupportTicket({
                ...newSupportTicket,
                resolutionDetails: text,
              })
            }
            style={styles.input}
            multiline
          />
          <HelperText type="error" visible={!!errors.resolutionDetails}>
            {errors.resolutionDetails}
          </HelperText>

          <FwTextInputPrimary
            label={LanguageString('Remarks')}
            value={newSupportTicket.remarks}
            onChangeText={(text: string) => {
              setNewSupportTicket({
                ...newSupportTicket,
                remarks: text,
              });
            }}
            style={{...styles.input, ...styles.descriptionInput}}
            multiline
          />
          <HelperText type="error" visible={!!errors.remarks}>
            {errors.remarks}
          </HelperText>
          <FWDropdown
            multiple={false}
            label={LanguageString('Select Asset Type')}
            options={assetsTypeOptions}
            value={newSupportTicket.assetType}
            onSelect={(value: string | undefined) => {
              if (value !== undefined) {
                setNewSupportTicket({...newSupportTicket, assetType: value});
              }
            }}
          />

          <HelperText type="error" visible={!!errors.assetType}>
            {errors.assetType}
          </HelperText>
          <FwTextInputPrimary
            label={LanguageString('Status')}
            value={LanguageString('Open')}
            editable={false}
            style={styles.input}
          />

          <FwButtonPrimary
            onPress={handleAddNewSupportTicket}
            style={commonStyle.saveButton}>
            <FwTextSecondary>{LanguageString('Save')}</FwTextSecondary>
          </FwButtonPrimary>
          <FwButtonPrimary
            onPress={closeAddNewSupportTicket}
            style={commonStyle.closeButton}>
            <FwTextSecondary>{LanguageString('Cancel')}</FwTextSecondary>
          </FwButtonPrimary>
        </ScrollView>
      </FwModal>
      {/* Delete Confirmation Dialog */}
      <FwDialog
        visible={deleteConfirmationVisible}
        hideDialog={hideDeleteConfirmation}
        title={LanguageString('Delete this Support Ticket?')}>
        <FwButtonPrimary mode="outlined" onPress={hideDeleteConfirmation}>
          <FwTextPrimary>{LanguageString('Cancel')}</FwTextPrimary>
        </FwButtonPrimary>
        <FwButtonPrimary mode="outlined" onPress={handleDeleteSupportTicket}>
          <FwTextPrimary>{LanguageString('Delete')}</FwTextPrimary>
        </FwButtonPrimary>
      </FwDialog>
    </>
  );
};

// SupportTicket data (moved outside component to prevent unnecessary re-renders)
const supportTicketData: SupportTicketPropTypes[] = [
  {
    id: 1,
    location: 'Om Nagar',
    category: 'Technical',
    priority: 'High',
    raisedBy: 'Rajesh',
    raisedDate: '20-09-2024',
    status: 'In progress',
    assignedTo: 'Ramesh',
    resolvedDate: '21-09-2024',
    assetType: 'Pumping Station',
    description: 'Short description Saved in the logs',
    resolutionDetails: 'Issue is Resolved by initiating the Engine',
    remarks:
      'Reference site about giving information on its origins, as well as a random Lipsum generator.',
  },
  {
    id: 2,
    location: 'Om Nagar',
    category: 'Technical',
    priority: 'High',
    raisedBy: 'Rajesh',
    raisedDate: '20-09-2024',
    status: 'In progress',
    assignedTo: 'Ramesh',
    resolvedDate: '21-09-2024',
    assetType: 'Pumping Station',
    description: 'Short description Saved in the logs',
    resolutionDetails: 'Issue is Resolved by initiating the Engine',
    remarks:
      'Reference site about giving information on its origins, as well as a random Lipsum generator.',
  },
  {
    id: 3,
    location: 'Om Nagar',
    category: 'Technical',
    priority: 'High',
    raisedBy: 'Rajesh',
    raisedDate: '20-09-2024',
    status: 'In progress',
    assignedTo: 'Ramesh',
    resolvedDate: '21-09-2024',
    assetType: 'Pumping Station',
    description: 'Short description Saved in the logs',
    resolutionDetails: 'Issue is Resolved by initiating the Engine',
    remarks:
      'Reference site about giving information on its origins, as well as a random Lipsum generator.',
  },
];

const styles = StyleSheet.create({
  container: {
    padding: normalized(16),
    backgroundColor: COLORS.OFF_WHITE,
  },
  title: {
    fontSize: normalized(24),
    fontWeight: 'bold',
    marginBottom: normalized(16),
    color: COLORS.BLACK,
  },
  subtitle: {
    fontSize: normalized(18),
    marginBottom: normalized(16),
    color: COLORS.BLACK,
  },
  supportTicketCard: {
    marginBottom: normalized(16),
    elevation: 2,
    backgroundColor: COLORS.BG_WHITE,
  },
  cardText: {
    color: COLORS.BLACK,
  },
  cardImage: {
    width: normalized(50),
    height: normalized(50),
    borderRadius: normalized(50),
    marginRight: normalized(16),
    marginTop: normalized(80),
  },
  cardImageIcon: {
    width: normalized(40),
    height: 30,
    marginRight: normalized(16),
    marginTop: normalized(20),
  },
  cardContent: {
    marginLeft: normalized(58),
    marginTop: normalized(-16),
  },
  modalContainer: {
    backgroundColor: COLORS.BG_WHITE,
    padding: normalized(24),
    margin: normalized(24),
    borderRadius: 8,
    elevation: 4,
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: normalized(24),
  },
  modalTitle: {
    fontSize: normalized(20),
    fontWeight: 'bold',
    color: COLORS.BLACK,
  },

  modalContent: {
    color: COLORS.BLACK,
    lineHeight: 24,
    fontSize: normalized(16),
  },
  statusInput: {
    backgroundColor: COLORS.OFF_WHITE,
    padding: normalized(8),
    borderRadius: 4,
  },

  dropdownContainer: {
    marginTop: normalized(16),
    marginLeft: normalized(20),
  },
  input: {
    marginBottom: normalized(8),
    height: normalized(50),
    marginHorizontal: normalized(8),
  },
  descriptionInput: {
    height: normalized(80),
    textAlignVertical: 'top',
  },
  cardActions: {
    flexDirection: 'row',
  },
});
export default SupportTicketScreenView;
