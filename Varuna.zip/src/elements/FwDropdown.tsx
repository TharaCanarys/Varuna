import React from 'react';
import {StyleSheet, ViewStyle} from 'react-native';
import {MultiSelect, Dropdown} from 'react-native-element-dropdown';
import {COLORS} from '../constants/colors';
import {normalized} from '../constants/platform';

interface Option {
  label: string;
  value: string;
}

interface FWDropdownProps {
  multiple: boolean;
  value: any;
  label: string;
  options: Option[];
  onSelect: (value: any) => void;
  menuContentStyle?: ViewStyle;
}

export default function FWDropdown(props: FWDropdownProps) {
  const {
    multiple,
    options,
    onSelect,
    label,
    value,
    menuContentStyle,
    ...restProps
  } = props;

  const customStyle = {
    backgroundColor: COLORS.SECONDARY,
    borderColor: COLORS.PRIMARY,
    borderWidth: 1,
    borderRadius: normalized(4),
    marginHorizontal: normalized(8),
    height: normalized(50),
    paddingHorizontal: normalized(8),
  };

  return multiple ? (
    <MultiSelect
      style={customStyle}
      data={options}
      labelField="label"
      valueField="value"
      placeholder={label}
      value={value}
      onChange={onSelect}
      selectedTextStyle={{
        color: COLORS.PRIMARY,
        marginLeft: normalized(15),
      }}
      placeholderStyle={{
        color: COLORS.PRIMARY,
        marginLeft: normalized(15),
      }}
      containerStyle={{
        backgroundColor: COLORS.OFF_WHITE,
      }}
    />
  ) : (
    <Dropdown
      style={{...customStyle}}
      data={options}
      labelField="label"
      valueField="value"
      placeholder={label}
      value={value}
      onChange={item => onSelect(item.value)}
      selectedTextStyle={{
        color: COLORS.PRIMARY,
        marginLeft: normalized(15),
      }}
      placeholderStyle={{
        color: COLORS.PRIMARY,
        marginLeft: normalized(15),
      }}
      containerStyle={{
        backgroundColor: COLORS.OFF_WHITE,
      }}
      {...restProps}
    />
  );
}
const styles = StyleSheet.create({});
