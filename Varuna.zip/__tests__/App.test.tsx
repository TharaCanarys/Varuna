import 'react-native';
import React from 'react';
import App from '../App';
import {it, describe, expect} from '@jest/globals';
import renderer from 'react-test-renderer';

describe('App Component', () => {
  it('renders without crashing', () => {
    const component = renderer.create(<App />);
    expect(component).toBeTruthy();
  });

  it('matches snapshot', () => {
    const tree = renderer.create(<App />).toJSON();
    expect(tree).toMatchSnapshot();
  });

  it('maintains component structure', () => {
    const component = renderer.create(<App />);
    const instance = component.root;
    expect(instance).toBeDefined();
  });

  it('can be unmounted properly', () => {
    const component = renderer.create(<App />);
    renderer.act(() => {
      component.unmount();
    });
    expect(true).toBeTruthy();
  });
});
