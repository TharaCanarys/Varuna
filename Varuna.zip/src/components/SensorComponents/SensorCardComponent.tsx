import React from 'react';
import {Card, IconButton} from 'react-native-paper';
import {LanguageString} from '../../constants/data';
import {commonStyle} from '../../constants/theme';
import {normalized} from '../../constants/platform';
import {View} from 'react-native';
import {FwTextPrimary} from '../../elements';
interface SensorCardComponentProps {
  index: number;
  styles: any;
  openSensorDetails: (sensor: any) => void;
  sensor: any;
  validateRole: boolean;
  startEditingStatus: () => void;
  openDeleteDialog: (sensor: any) => void;
}
const SensorCardComponent = ({
  index,
  styles,
  openSensorDetails,
  sensor,
  validateRole,
  startEditingStatus,
  openDeleteDialog,
}: SensorCardComponentProps) => {
  return (
    <Card
      key={index}
      style={{
        ...styles.sensorCard,
        // backgroundColor: !sensor.enabled
        //   ? COLORS.LIGHTGRAY
        //   : COLORS.OFF_WHITE,
      }}
      onPress={() => openSensorDetails && openSensorDetails(sensor)}>
      <Card.Title
        title={LanguageString(sensor.sensorName)}
        titleStyle={commonStyle.cardHeaderText}
        left={props => (
          <IconButton
            {...props}
            style={{
              marginTop: normalized(60),
              paddingRight: normalized(16),
            }}
            icon="access-point"
          />
        )}
        right={props =>
          validateRole ? (
            <View style={styles.cardActions}>
              {/* <Switch
                    value={sensor.enabled}
                    onValueChange={() => sensorSwitch(sensor)}
                  /> */}
              <IconButton
                {...props}
                style={{
                  opacity: sensor.status === 1 && !sensor.enabled ? 8 : 8,
                }}
                icon="pencil"
                onPress={() => {
                  openSensorDetails(sensor);
                  startEditingStatus();
                }}
              />
              {/* <IconButton
                {...props}
                icon="delete"
                onPress={() => openDeleteDialog(sensor)}
              /> */}
            </View>
          ) : null
        }
      />
      <Card.Content style={styles.cardContent}>
        <View style={commonStyle.modalRow}>
          <FwTextPrimary style={commonStyle.boldText}>
            {LanguageString('Location') + ' : '}
          </FwTextPrimary>
          <FwTextPrimary style={commonStyle.normalText}>
            {LanguageString(sensor.locationName)}
          </FwTextPrimary>
        </View>
        <View style={commonStyle.modalRow}>
          <FwTextPrimary style={commonStyle.boldText}>
            {LanguageString('Status') + ' : '}
          </FwTextPrimary>
          <FwTextPrimary style={commonStyle.normalText}>
            {LanguageString(
              sensor.status == 0
                ? 'Active'
                : sensor.status == 1
                ? 'Inactive'
                : sensor.status == 2
                ? 'Maintenance'
                : 'Status Not found',
            )}
          </FwTextPrimary>
        </View>
      </Card.Content>
    </Card>
  );
};

export default SensorCardComponent;
