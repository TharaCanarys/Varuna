import React from 'react';
import {View, StyleSheet} from 'react-native';
import {IconButton} from 'react-native-paper';
import {COLORS} from '../../constants/colors';
import {FwButtonPrimary, FwTextPrimary, FwTextSecondary} from '../../elements';
import {LanguageString} from '../../constants/data';
import {commonStyle} from '../../constants/theme';
import FWDropdown from '../../elements/FwDropdown';
import {normalized} from '../../constants/platform';
import FwModal from '../../elements/FwModal';

interface AlertDetailsModalProps {
  selectedAlert: any;
  closeAlertDetails: any;
  startEditingStatus: any;
  editingStatus: boolean;
  saveStatus: any;
  newStatus: any;
  validateRole: boolean;
  statusAOptions: any;
  onSelectStatus: any;
}

const AlertDetailsModal = ({
  selectedAlert,
  closeAlertDetails,
  startEditingStatus,
  editingStatus,
  saveStatus,
  newStatus,
  validateRole,
  statusAOptions,
  onSelectStatus,
}: AlertDetailsModalProps) => {
  return (
    <FwModal
      visible={selectedAlert !== null}
      onDismiss={closeAlertDetails}
      contentContainerStyle={styles.modalContainer}>
      {selectedAlert && (
        <>
          <View style={commonStyle.modalHeader}>
            <FwTextPrimary style={commonStyle.modalTitle}>
              {LanguageString('Alert Details')}
            </FwTextPrimary>
            {validateRole ? (
              <IconButton
                icon="pencil"
                size={24}
                onPress={startEditingStatus}
                disabled={selectedAlert.status === 'Resolved'}
              />
            ) : null}
          </View>
          <View style={commonStyle.modalRow}>
            <FwTextPrimary style={commonStyle.boldText}>
              {LanguageString('Alert Name')}:
            </FwTextPrimary>
            <FwTextPrimary style={commonStyle.normalText}>
              {' '}
              {LanguageString('Alerts') + ' ' + selectedAlert.id}
            </FwTextPrimary>
          </View>
          <View style={commonStyle.modalRow}>
            <FwTextPrimary style={commonStyle.boldText}>
              {LanguageString('Sensor') + ' ' + LanguageString('Name')}:
            </FwTextPrimary>
            <FwTextPrimary style={commonStyle.normalText}>
              {' '}
              {LanguageString(selectedAlert.sensor) + ' ' + selectedAlert.id}
            </FwTextPrimary>
          </View>
          <View style={commonStyle.modalRow}>
            <FwTextPrimary style={commonStyle.boldText}>
              {LanguageString('Alert') + ' ' + LanguageString('Type')}:
            </FwTextPrimary>
            <FwTextPrimary style={commonStyle.normalText}>
              {' '}
              {LanguageString(selectedAlert.alertType)}
            </FwTextPrimary>
          </View>
          <View style={commonStyle.modalRow}>
            <FwTextPrimary style={commonStyle.boldText}>
              {LanguageString('Severity')}:
            </FwTextPrimary>
            <FwTextPrimary style={commonStyle.normalText}>
              {' '}
              {LanguageString(selectedAlert.severity)}
            </FwTextPrimary>
          </View>
          <View style={commonStyle.modalRow}>
            <FwTextPrimary style={commonStyle.boldText}>
              {LanguageString('Created Date')}:
            </FwTextPrimary>
            <FwTextPrimary style={commonStyle.normalText}>
              {' '}
              {selectedAlert.createdDate}
            </FwTextPrimary>
          </View>
          <View style={commonStyle.modalRow}>
            <FwTextPrimary style={commonStyle.boldText}>
              {LanguageString('Status')}:
            </FwTextPrimary>
            <FwTextPrimary style={commonStyle.normalText}>
              {' '}
              {!editingStatus && LanguageString(selectedAlert.status)}
            </FwTextPrimary>
          </View>
          {editingStatus && (
            <FWDropdown
              multiple={false}
              label={LanguageString('Select Status')}
              options={statusAOptions}
              value={newStatus}
              onSelect={onSelectStatus}
            />
          )}
          {editingStatus && (
            <FwButtonPrimary onPress={saveStatus} style={styles.saveButton}>
              <FwTextSecondary>{LanguageString('Save')}</FwTextSecondary>
            </FwButtonPrimary>
          )}
          <FwButtonPrimary
            onPress={closeAlertDetails}
            style={styles.closeButton}>
            <FwTextSecondary>{LanguageString('Cancel')}</FwTextSecondary>
          </FwButtonPrimary>
        </>
      )}
    </FwModal>
  );
};
export default AlertDetailsModal;

const styles = StyleSheet.create({
  modalContainer: {
    backgroundColor: COLORS.BG_WHITE,
    padding: normalized(24),
    margin: normalized(24),
    borderRadius: 8,
    elevation: 4,
  },
  closeButton: {
    marginTop: normalized(24),
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: normalized(24),
  },
  modalTitle: {
    fontSize: normalized(21),
    fontWeight: 'bold',
    letterSpacing: 1,
    marginBottom: normalized(10),
    marginLeft: normalized(5),
    color: COLORS.BLACK,
  },
  dropdownContainer: {
    marginTop: normalized(16),
    marginLeft: normalized(20),
  },
  saveButton: {
    marginTop: normalized(16),
  },
});
