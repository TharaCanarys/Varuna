import React from 'react';
import {Appbar} from 'react-native-paper';
import {COLORS} from '../constants/colors';
import {normalized} from '../constants/platform';
import {PAGES} from './pages';
import {useSelector} from 'react-redux';
import {RootState} from '../store/store';
import DateComponent from './DateComponent';
import {showDialog, updateNotificationCount} from '../store/appSlice';
import FwLanguagePicker from '../elements/FwLanguagePicker';
import {useCallback, useState, useEffect, useRef} from 'react';
import {LanguageString} from '../constants/data';
import {View, Text, Animated} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

export const AppbarTop = ({navigation, dispatch, route, toggleMenu}: any) => {
  const shakeAnimation = useRef(new Animated.Value(0)).current;
  const NotificationCount = useSelector(
    (state: RootState) => state.app.notificationCount,
  );
  const [notifications, setNotifications] = useState(NotificationCount);

  const startShake = () => {
    Animated.sequence([
      Animated.timing(shakeAnimation, {
        toValue: -5,
        duration: 50,
        useNativeDriver: true,
      }),
      Animated.timing(shakeAnimation, {
        toValue: 5,
        duration: 50,
        useNativeDriver: true,
      }),
      Animated.timing(shakeAnimation, {
        toValue: -5,
        duration: 50,
        useNativeDriver: true,
      }),
      Animated.timing(shakeAnimation, {
        toValue: 5,
        duration: 50,
        useNativeDriver: true,
      }),
      Animated.timing(shakeAnimation, {
        toValue: -5,
        duration: 50,
        useNativeDriver: true,
      }),
      Animated.timing(shakeAnimation, {
        toValue: 0,
        duration: 50,
        useNativeDriver: true,
      }),
    ]).start();
  };

  useEffect(() => {
    const interval = setInterval(() => {
      if (notifications > 0) {
        startShake();
      }
    }, 5000);

    return () => clearInterval(interval);
  }, [notifications]);

  const ChangeLanguage = () => {
    dispatch(showDialog());
  };
  const language = useSelector(
    (state: RootState) => state.app.selectedLanguage,
  );

  useEffect(() => {
    const fetchNotifications = async () => {
      const savedViewedNotifications = await AsyncStorage.getItem(
        'viewedNotifications',
      );
      const savedCount = savedViewedNotifications
        ? JSON.parse(savedViewedNotifications).length
        : 0;
      setNotifications(
        savedCount === NotificationCount ? 0 : NotificationCount,
      );
    };

    fetchNotifications();
  }, [NotificationCount]);
  const HandleNotificationsView = () => {
    navigation.navigate(PAGES.NOTIFICATIONS as never);
  };

  const handleOpenDrawer = useCallback(() => {
    navigation.openDrawer();
  }, [navigation, language]);

  const getAppbarContent = useCallback(() => {
    return {
      color: COLORS.BG_WHITE,
      // title: LanguageString(route.name),
      titleStyle: {
        fontSize: normalized(18),
        fontWeight: '700' as const,
        color: COLORS.BG_WHITE,
      },
    };
  }, [route.name, language]);

  return (
    <>
      <DateComponent />
      <Appbar.Header
        mode="center-aligned"
        style={{
          elevation: 8,
          zIndex: 1000,
          backgroundColor: COLORS.PRIMARY,
          height: 40,
        }}>
        <Appbar.Action
          icon="menu"
          color={COLORS.BG_WHITE}
          onPress={() => handleOpenDrawer()}
          size={30}
          animated={true}
        />
        <Appbar.Content {...getAppbarContent()} />
        <Appbar.Action
          icon={() => <FwLanguagePicker />}
          color={COLORS.BG_WHITE}
          onPress={() => ChangeLanguage()}
        />
        <View>
          <Animated.View
            style={{
              transform: [
                {
                  rotate: shakeAnimation.interpolate({
                    inputRange: [-5, 5],
                    outputRange: ['-15deg', '15deg'],
                  }),
                },
              ],
            }}>
            <Appbar.Action
              icon="bell"
              color={COLORS.BG_WHITE}
              onPress={() => HandleNotificationsView()}
              size={24}
            />
          </Animated.View>
          {notifications > 0 && (
            <View
              style={{
                position: 'absolute',
                right: 8,
                top: 8,
                backgroundColor: 'red',
                borderRadius: 10,
                minWidth: 20,
                height: 20,
                justifyContent: 'center',
                alignItems: 'center',
              }}>
              <Text style={{color: COLORS.BG_WHITE, fontSize: 12}}>
                {notifications > 99 ? '99+' : notifications}
              </Text>
            </View>
          )}
        </View>
        <Appbar.Action
          icon="dots-vertical"
          color={COLORS.BG_WHITE}
          onPress={toggleMenu}
          size={24}
        />
      </Appbar.Header>
    </>
  );
};
