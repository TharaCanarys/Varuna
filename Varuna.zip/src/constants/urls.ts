import {BASE_URL_DSS_OPS} from './data';

export const ALL_URLS = {
  GET_USERS: BASE_URL_DSS_OPS + 'UserManagement/GetUsers',
  GET_TASKS: BASE_URL_DSS_OPS + 'tasks',
  CREATE_TASK: BASE_URL_DSS_OPS + 'tasks/create',
  UPDATE_TASK: BASE_URL_DSS_OPS + 'tasks/update',
  DELETE_TASK: BASE_URL_DSS_OPS + 'tasks/delete'
} as const;
