import React, {useState, useCallback} from 'react';
import FwModal from '../../elements/FwModal';
import {
  View,
  Image,
  ScrollView,
  Dimensions,
  TouchableOpacity,
} from 'react-native';
import {commonStyle} from '../../constants/theme';
import {FwButtonPrimary, FwTextPrimary, FwTextSecondary} from '../../elements';
import {LanguageString} from '../../constants/data';
import {IconButton} from 'react-native-paper';
import FWDropdown from '../../elements/FwDropdown';
import ImageZoom from 'react-native-image-pan-zoom';

const {width} = Dimensions.get('window');

const IncidentDetailsComponent = ({
  styles,
  selectedIncident,
  closeIncidentDetails,
  validateRole,
  startEditingStatus,
  editingStatus,
  statusOptions,
  newStatus,
  setNewStatus,
  validateStatus,
  saveStatus,
}: any) => {
  const [selectedImage, setSelectedImage] = useState<string | null>(null);

  const openImageDetail = (imageUri: string) => {
    setSelectedImage(imageUri);
  };

  const getCategoryName = useCallback((category: number) => {
    switch (category) {
      case 0:
        return LanguageString('DrainBlockage');
      case 1:
        return LanguageString('WaterLogging');
      case 2:
        return LanguageString('DrainageDamage');
      case 3:
        return LanguageString('Overflow');
      default:
        return LanguageString('Unknown');
    }
  }, []);

  const getStatusName = useCallback((status: number) => {
    switch (status) {
      case 0:
        return LanguageString('Open');
      case 1:
        return LanguageString('In Progress');
      case 2:
        return LanguageString('Resolved');
      case 3:
        return LanguageString('Rejected');
      default:
        return LanguageString('Unknown');
    }
  }, []);

  console.log("selectedIncident",selectedIncident)

  return (
    <FwModal
      visible={selectedIncident !== null}
      onDismiss={closeIncidentDetails}
      contentContainerStyle={styles.modalContainer}>
      {selectedIncident && (
        <>
          <View style={commonStyle.modalHeader}>
            <FwTextPrimary style={commonStyle.modalTitle}>
              {LanguageString('Incident Id')}: {selectedIncident?.incidentID}
            </FwTextPrimary>
            {validateRole ? (
              <IconButton
                icon="pencil"
                size={24}
                onPress={startEditingStatus}
                disabled={selectedIncident?.status === 'Resolved'}
              />
            ) : null}
          </View>

          {selectedIncident?.reportedByUserName && (
            <View style={commonStyle.modalRow}>
              <FwTextPrimary style={commonStyle.boldText}>
                {LanguageString('Reported By')}:
              </FwTextPrimary>
              <FwTextPrimary style={commonStyle.normalText}>
                {' '}
                {selectedIncident?.status !== undefined ? 
                getStatusName(selectedIncident.status) : 
                LanguageString('Unknown')}
              </FwTextPrimary>
            </View>
          )}
          {selectedIncident?.category && (
            <View style={commonStyle.modalRow}>
              <FwTextPrimary style={commonStyle.boldText}>
                {LanguageString('Category')}:
              </FwTextPrimary>
              <FwTextPrimary style={commonStyle.normalText}>
                {' '}
                {selectedIncident?.category !== undefined ? 
                  getCategoryName(selectedIncident.category) : 
                  LanguageString('Unknown')}
              </FwTextPrimary>
            </View>
          )}
          
          {selectedIncident?.description && (
            <View style={commonStyle.modalRow}>
              <FwTextPrimary style={commonStyle.boldText}>
                {LanguageString('Description')}:
              </FwTextPrimary>
              <FwTextPrimary style={commonStyle.normalText}>
                {' '}
                {selectedIncident?.description}
              </FwTextPrimary>
            </View>
          )}
           {selectedIncident?.address && (
            <View style={commonStyle.modalRow}>
              <FwTextPrimary style={commonStyle.boldText}>
                {LanguageString('Address')}:
              </FwTextPrimary>
              <FwTextPrimary style={commonStyle.normalText}>
                {' '}
                {selectedIncident?.description}
              </FwTextPrimary>
            </View>
          )}
          <View style={commonStyle.modalRow}>
            <FwTextPrimary style={commonStyle.boldText}>
              {LanguageString('Reported Time')}:
            </FwTextPrimary>
            <FwTextPrimary style={commonStyle.normalText}>
              {' '}
              {selectedIncident?.reportTime
                ? new Date(selectedIncident.reportTime).toLocaleTimeString(
                    'en-US',
                    {hour: 'numeric', minute: 'numeric', hour12: true},
                  )
                : ''}
            </FwTextPrimary>
          </View>
          {selectedIncident?.comments && (
            <View style={commonStyle.modalRow}>
              <FwTextPrimary style={commonStyle.boldText}>
                {LanguageString('Comment')}:
              </FwTextPrimary>
              <FwTextPrimary style={commonStyle.normalText}>
                {' '}
                {selectedIncident?.comments}
              </FwTextPrimary>
            </View>
          )}
          
          <View style={commonStyle.modalRow}>
            <FwTextPrimary style={commonStyle.boldText}>
              {LanguageString('Location')}:
            </FwTextPrimary>
            <FwTextPrimary style={commonStyle.normalText}>
              {selectedIncident?.latitude && selectedIncident?.longitude ? 
                `${selectedIncident.latitude.toFixed(2)}, ${selectedIncident.longitude.toFixed(2)}` 
                : 'Location not available'}
            </FwTextPrimary>
          </View>
          {selectedIncident?.resulationTime ? (
            <View style={commonStyle.modalRow}>
              <FwTextPrimary style={commonStyle.boldText}>
                {LanguageString('Resolution Time')}:
              </FwTextPrimary>

              <FwTextPrimary style={commonStyle.normalText}>
                {new Date(selectedIncident.resulationTime).toLocaleTimeString(
                  'en-US',
                  {hour: 'numeric', minute: 'numeric', hour12: true},
                )}
              </FwTextPrimary>
            </View>
          ) : null}
          <View style={commonStyle.modalRow}>
            <FwTextPrimary style={commonStyle.boldText}>
              {LanguageString('Status')}:
            </FwTextPrimary>
            <FwTextPrimary style={commonStyle.normalText}>
              {' '}
              {!editingStatus && LanguageString(getStatusName(selectedIncident?.status))}
            </FwTextPrimary>
          </View>
          <ScrollView
            horizontal
            pagingEnabled
            showsHorizontalScrollIndicator={true}
            style={styles.imageContainer}>
            {selectedIncident?.pictureData && (
              <TouchableOpacity
                onPress={() =>
                  openImageDetail(
                    `data:image/jpeg;base64,${selectedIncident.pictureData}`,
                  )
                }>
                <Image
                  source={{
                    uri: `data:image/jpeg;base64,${selectedIncident.pictureData}`,
                  }}
                  style={[styles.image, {width: width - 40, height: 200}]}
                  resizeMode="cover"
                />
              </TouchableOpacity>
            )}
            {selectedIncident?.pictureData1 && (
              <TouchableOpacity
                onPress={() =>
                  openImageDetail(
                    `data:image/jpeg;base64,${selectedIncident.pictureData1}`,
                  )
                }>
                <Image
                  source={{
                    uri: `data:image/jpeg;base64,${selectedIncident.pictureData1}`,
                  }}
                  style={[styles.image, {width: width - 40, height: 200}]}
                  resizeMode="cover"
                />
              </TouchableOpacity>
            )}
            {selectedIncident?.pictureData2 && (
              <TouchableOpacity
                onPress={() =>
                  openImageDetail(
                    `data:image/jpeg;base64,${selectedIncident.pictureData2}`,
                  )
                }>
                <Image
                  source={{
                    uri: `data:image/jpeg;base64,${selectedIncident.pictureData2}`,
                  }}
                  style={[styles.image, {width: width - 40, height: 200}]}
                  resizeMode="cover"
                />
              </TouchableOpacity>
            )}
          </ScrollView>
          {selectedImage && (
            <FwModal
              visible={!!selectedImage}
              onDismiss={() => setSelectedImage(null)}
              contentContainerStyle={{
                ...styles.imageModalContainer,
                backgroundColor: 'rgba(0, 0, 0, 0.67)',
              }}>
              <ImageZoom
                cropWidth={width - 20}
                cropHeight={width - 20}
                imageWidth={width - 20}
                imageHeight={width - 20}>
                <Image
                  source={{uri: selectedImage}}
                  style={{width: width - 20, height: width - 20}}
                  resizeMode="contain"
                />
              </ImageZoom>
              <FwButtonPrimary
                onPress={() => setSelectedImage(null)}
                style={commonStyle.closeButton}>
                <FwTextSecondary>{LanguageString('Close')}</FwTextSecondary>
              </FwButtonPrimary>
            </FwModal>
          )}
          {editingStatus && selectedIncident?.status !== 'Resolved' && (
            <FWDropdown
              multiple={false}
              label={LanguageString('Select Status')}
              options={statusOptions}
              value={newStatus}
              onSelect={(value: string | undefined) => {
                if (value !== undefined) {
                  setNewStatus(value);
                  validateStatus(value);
                }
              }}
            />
          )}
          {editingStatus && selectedIncident?.status !== 'Resolved' && (
            <FwButtonPrimary
              onPress={saveStatus}
              style={commonStyle.saveButton}>
              <FwTextSecondary>{LanguageString('Save')}</FwTextSecondary>
            </FwButtonPrimary>
          )}
          <FwButtonPrimary
            onPress={closeIncidentDetails}
            style={commonStyle.closeButton}>
            <FwTextSecondary>{LanguageString('Cancel')}</FwTextSecondary>
          </FwButtonPrimary>
        </>
      )}
    </FwModal>
  );
};
export default IncidentDetailsComponent;