import React from 'react';

import {TextStyle} from 'react-native';
import {Text} from 'react-native-paper';
import {COLORS} from '../constants/colors';
import {normalized} from '../constants/platform';

interface FwTextProps {
  type?: keyof typeof styles; // Use keyof typeof for better type safety
  style?: TextStyle;
  children?: React.ReactNode;
  theme?: any; // Consider defining a more specific type for theme
}

const styles = {
  heading_1: {fontSize: normalized(32), fontWeight: 'bold' as const},
  heading_2: {fontSize: normalized(28), fontWeight: 'bold' as const},
  heading_3: {fontSize: normalized(24), fontWeight: 'bold' as const},
  heading_4: {fontSize: normalized(22), fontWeight: 'bold' as const},
  heading_5: {fontSize: normalized(20), fontWeight: 'bold' as const},
  heading_6: {fontSize: normalized(18), fontWeight: 'bold' as const},
  heading_7: {fontSize: normalized(16), fontWeight: 'bold' as const},
  heading_8: {fontSize: normalized(14), fontWeight: 'bold' as const},
  title_1: {fontSize: normalized(26), fontWeight: '500' as const},
  title_2: {fontSize: normalized(24), fontWeight: '500' as const},
  title_3: {fontSize: normalized(22), fontWeight: '500' as const},
  title_4: {fontSize: normalized(20), fontWeight: '500' as const},
  title_5: {fontSize: normalized(18), fontWeight: '500' as const},
  title_6: {fontSize: normalized(16), fontWeight: '500' as const},
  title_7: {fontSize: normalized(14), fontWeight: '500' as const},
  subtitle_1: {fontSize: normalized(16), fontWeight: '400' as const},
  subtitle_2: {fontSize: normalized(14), fontWeight: '400' as const},
  body: {fontSize: normalized(14), fontWeight: 'normal' as const},
  bottomDrawerText: {fontSize: normalized(12), fontWeight: '300' as const},
  buttonText: {fontSize: normalized(16), fontWeight: 'bold' as const},
  caption: {fontSize: normalized(12), fontWeight: '300' as const},
  description: {fontSize: normalized(14), fontWeight: 'normal' as const},
  filter: {fontSize: normalized(12), fontWeight: '400' as const},
  mainTitle: {fontSize: normalized(28), fontWeight: '600' as const},
  navText: {fontSize: normalized(14), fontWeight: '500' as const},
  overline: {fontSize: normalized(10), fontWeight: '400' as const},
  placeholderText: {
    fontSize: normalized(14),
    fontWeight: 'normal' as const,
    color: '#999',
  },
  popupText: {fontSize: normalized(14), fontWeight: 'normal' as const},
  secondaryButtonText: {fontSize: normalized(14), fontWeight: 'bold' as const},
  smallText: {fontSize: normalized(12), fontWeight: 'normal' as const},
  tagsText: {fontSize: normalized(12), fontWeight: 'normal' as const},
};

// Main component function
const FwTextPrimary: React.FC<FwTextProps> = ({
  type = 'body',
  style,
  children,
  theme,
}) => {
  const textStyle = styles[type];

  return (
    <Text
      accessible={true}
      style={[{color: COLORS.PRIMARY}, textStyle, style]}
      theme={{colors: {primary: 'green'}}}>
      {children}
    </Text>
  );
};

export default FwTextPrimary;
