import React from 'react';
import {View, StyleSheet} from 'react-native';
import {ScrollView} from 'react-native';
import {
  FwButtonPrimary,
  FwTextInputPrimary,
  FwTextPrimary,
  FwTextSecondary,
} from '../../elements';
import {LanguageString} from '../../constants/data';
import FWDropdown from '../../elements/FwDropdown';
import {commonStyle} from '../../constants/theme';
import {HelperText} from 'react-native-paper';
import {normalized} from '../../constants/platform';

const AddPoiComponent = ({
  locationOptions,
  newPOI,
  setNewPOI,
  errors,
  elevationOptions,
  networkOptions,
  statusOptions,
  floodRiskLevelOptions,
  handleAddNewPOI,
  closeAddNewPOI,
}: any) => {
  return (
    <ScrollView>
      <View style={commonStyle.modalHeader}>
        <FwTextPrimary style={commonStyle.modalTitle}>
          {LanguageString('Add New')} {LanguageString('POI')}
        </FwTextPrimary>
      </View>
      <FWDropdown
        multiple={false}
        label={LanguageString('Select Location')}
        options={locationOptions}
        value={newPOI?.location}
        onSelect={(value: string | undefined) => {
          if (value !== undefined) {
            setNewPOI({...newPOI, location: value});
          }
        }}
      />
      <HelperText type="error" visible={!!errors.location}>
        {errors.location}
      </HelperText>
      <FwTextInputPrimary
        label={LanguageString('POI') + ' ' + LanguageString('Name')}
        value={newPOI?.poiName}
        onChangeText={text => {
          setNewPOI({...newPOI, poiName: text});
        }}
        style={styles.input}
      />
      <HelperText type="error" visible={!!errors.poiName}>
        {errors.poiName}
      </HelperText>
      {/* <FwTextInputPrimary
      label={LanguageString('POI') + ' ' + LanguageString('Type')}
      value={newPOI?.poiType}
      onChangeText={text => setNewPOI({...newPOI, poiType: text})}
      style={styles.input}
      error={!!errors.poiType}
    />
    <HelperText type="error" visible={!!errors.poiType}>
      {errors.poiType}
    </HelperText> */}
      <FWDropdown
        multiple={false}
        label={LanguageString('Select Elevation')}
        options={elevationOptions}
        value={newPOI?.elevation}
        onSelect={(value: string | undefined) => {
          if (value !== undefined) {
            setNewPOI({...newPOI, elevation: value});
          }
        }}
      />
      <HelperText type="error" visible={!!errors.elevation}>
        {errors.elevation}
      </HelperText>
      <FWDropdown
        multiple={false}
        label={LanguageString('Network')}
        options={networkOptions}
        value={newPOI?.network}
        onSelect={(value: string | undefined) => {
          if (value !== undefined) {
            setNewPOI({...newPOI, network: value});
          }
        }}
      />
      <HelperText type="error" visible={!!errors.network}>
        {errors.network}
      </HelperText>
      <FWDropdown
        multiple={false}
        label={LanguageString('POI') + ' ' + LanguageString('Status')}
        options={statusOptions}
        value={newPOI?.poiStatus}
        onSelect={(value: string | undefined) => {
          if (value !== undefined) {
            setNewPOI({...newPOI, poiStatus: value});
          }
        }}
      />
      <HelperText type="error" visible={!!errors.poiStatus}>
        {errors.poiStatus}
      </HelperText>
      <FWDropdown
        multiple={false}
        label={LanguageString('Flood Risk Level')}
        options={floodRiskLevelOptions}
        value={newPOI?.floodRiskLevel}
        onSelect={(value: string | undefined) => {
          if (value !== undefined) {
            setNewPOI({...newPOI, floodRiskLevel: value});
          }
        }}
      />
      <HelperText type="error" visible={!!errors.floodRiskLevel}>
        {errors.floodRiskLevel}
      </HelperText>
      <FwTextInputPrimary
        label={LanguageString('Adjescent POIs')}
        value={LanguageString(newPOI?.adjescentPois)}
        onChangeText={text => {
          setNewPOI({...newPOI, adjescentPois: text});
        }}
        style={styles.input}
      />
      <HelperText type="error" visible={!!errors.adjescentPois}>
        {errors.adjescentPois}
      </HelperText>
      <FwButtonPrimary onPress={handleAddNewPOI} style={commonStyle.saveButton}>
        <FwTextSecondary>{LanguageString('Save')}</FwTextSecondary>
      </FwButtonPrimary>
      <FwButtonPrimary onPress={closeAddNewPOI} style={commonStyle.closeButton}>
        <FwTextSecondary>{LanguageString('Cancel')}</FwTextSecondary>
      </FwButtonPrimary>
    </ScrollView>
  );
};

export default AddPoiComponent;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: normalized(16),
  },
  input: {
    marginBottom: normalized(8),
  },
});
