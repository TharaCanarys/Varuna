import React, {useCallback, useState, useMemo, useEffect} from 'react';
import {PumpStationPropTypes} from '../../types/commonTypes';
import {LanguageString} from '../../constants/data';
import PumpOperationScreenView from './PumpOperationScreenView';
import { getPumpOperationsData } from '../../services/apiServices';

const PumpOperationScreen: React.FC = () => {
  const [selectedPumpStation, setSelectedPumpStation] =
    useState<PumpStationPropTypes | null>(null);
  const [pumpStations, setPumpStations] = useState<PumpStationPropTypes[]>([]);
  const [refreshing, setRefreshing] = useState(false);


  const onGetSuccess = (data: any[]) => {
      setPumpStations(data);
    };

     const onGetFailed = useCallback((error: any) => {
    console.log("Failed to get Pump Stations", error);
      }, []);

  useEffect(() => {
      getPumpStationOperations();
    }, []);
  
    const getPumpStationOperations = async () => {
      let payload = [0];
      getPumpOperationsData(payload, onGetSuccess, onGetFailed);
    };
  
  // Simulate data refresh
  const onRefresh = useCallback(() => {
    setRefreshing(true);
    setTimeout(() => {
      getPumpStationOperations();
      setRefreshing(false);
    }, 1000);
  }, []);

  // Open pumpStation details modal
  const openPumpStationDetails = useCallback(
    (pumpStation: PumpStationPropTypes) => {
      setSelectedPumpStation(pumpStation);
    },
    [],
  );

  // Close pumpStation details modal
  const closePumpStationDetails = useCallback(() => {
    setSelectedPumpStation(null);
  }, []);

  // Memoize the props for PumpStationScreenView to prevent unnecessary re-renders
  const pumpStationScreenViewProps = useMemo(
    () => ({
      selectedPumpStation,
      pumpStations: pumpStations || [],
      refreshing,
      onRefresh,
      openPumpStationDetails,
      closePumpStationDetails,
    }),
    [
      selectedPumpStation,
      pumpStations,
      refreshing,
      onRefresh,
      openPumpStationDetails,
      closePumpStationDetails,
    ],
  );

  return <PumpOperationScreenView {...pumpStationScreenViewProps} />;
};

export default PumpOperationScreen;
