import React from 'react';
import LogsScreenView from './LogsScreenView';

const LogsScreen: React.FC = () => {
  return <LogsScreenView />;
};

export default LogsScreen;
