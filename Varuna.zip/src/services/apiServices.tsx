import axios from 'axios';
import {ALL_URLS, BASE_URL_DSS_OPS, BASE_URL_HARDWARE} from '../constants/data';
import {getToken, storeId, storeToken} from './authService';
import {setToken, setUserDetails} from '../store/authSlice';
import {PAGES} from '../components/pages';
import {DecodeJWT} from '../components/DecodeJWT';
import {CommonActions} from '@react-navigation/native';
import { Platform } from 'react-native';
import { TaskTypes } from '../types/commonTypes';

export const handleLogin = async (
  email: string,
  password: string,
  onOTPVerifySuccess:(data: any) => void,
  onOTPVerifyFailed: (data: any) => void,
  setIsLoading: (visible: boolean) => void,
) => {
  try {
    setIsLoading(true);
    
    const response = await axios.post(
      BASE_URL_DSS_OPS + ALL_URLS.SIGN_IN,
      {
        email: email,
        password:password
      },
      {
        headers: {
          'Content-Type': 'application/json',
        },
      },
    );
    const data = response.data;
    console.log("Login Password Api Called",data.success)
    if (data.success === true) {
        onOTPVerifySuccess(data)
        setIsLoading(false);       
    } 
    // else {
    //   onOTPVerifyFailed('Something went wrong, Please try again.');
    //   setIsLoading(false);
    // }
  } catch (error) {
    if (axios.isAxiosError(error) && error.response) {
      onOTPVerifyFailed(
        error.response.data.details === undefined
          ? 'Something went wrong, Please try again.'
          : error.response.data.details,
      );
    }
  } finally {
    setIsLoading(false);
  }
};


// export const handleVerifyPhone = async (
//   phone: string,
//   setIsLoading: (visible: boolean) => void,
//   onPhoneVerifySuccess: (data: any) => void,
//   onPhoneVerifyFailed: (data: any) => void,
// ) => {
//   console.log('Verify Reset Password Called:', phone);
//   setIsLoading(true);
//   try {
//     const response = await axios.post(
//       BASE_URL_DSS_OPS + ALL_URLS.VERIFY_EMAIL,
//       {mobileNumber: phone},
//       {
//         headers: {
//           'Content-Type': 'application/json',
//         },
//       },
//     );
//     if (response.status === 200) {
//       onPhoneVerifySuccess(response.data);
//     } else {
//       onPhoneVerifyFailed(response.data);
//     }
//   } catch (error) {
//     if (axios.isAxiosError(error) && error.response) {
//       // console.error('Error during OTP request Here:', error);
//       onPhoneVerifyFailed(
//         error.response.data === undefined
//           ? 'Something went wrong, Please try again.'
//           : error.response.data,
//       );
//     }
//   } finally {
//     setIsLoading(false);
//   }
// };

export const handleVerifyOTP = async (
  phone: string,
  otp: number,
  setIsLoading: (visible: boolean) => void,
  onOTPVerifySuccess: (data: any) => void,
  onOTPVerifyFailed: (data: any) => void,
) => {
  setIsLoading(true);
  try {
    const response = await axios.post(
      BASE_URL_DSS_OPS + ALL_URLS.VERIFY_OTP,
      {
        otp: otp,
        mobileNumber: phone,
      },
      {
        headers: {
          'Content-Type': 'application/json',
        },
      },
    );
    console.log('Verify OTP response:', response.data);
    onOTPVerifySuccess(response.data);
    if (response.data.statuscode === 200) {
    }
    // else {
    //     onOTPVerifyFailed(response.data);
    // }
  } catch (error) {
    setIsLoading(false);
    if (axios.isAxiosError(error) && error.response) {
      console.log('OTP Verify Failed:', error.response.data.details);
      onOTPVerifyFailed(
        error.response.data.details === undefined
          ? 'Something went wrong, While OTP Verification.'
          : error.response.data.details,
      );
    }
  } finally {
    setIsLoading(false);
  }
};
export const handleSetNewPassword = async (
  email: string,
  newPassword: string,
  setIsLoading: (visible: boolean) => void,
  onSetNewPasswordSuccess: (data: any) => void,
  onSetNewPasswordFailed: (data: any) => void,
) => {
  console.log('Set new password payload:', {
    email: email,
    newPWD: newPassword,
  });
  setIsLoading(true);

  try {
    const response = await axios.post(
      BASE_URL_DSS_OPS + ALL_URLS.RESET_PASSWORD,
      {
        email: email,
        newPWD: newPassword,
      },
      {
        headers: {
          'Content-Type': 'application/json',
        },
      },
    );
    console.log('Set new password response:', response.data);
    if (response.status === 200) {
      onSetNewPasswordSuccess(response.data);
    } else {
      onSetNewPasswordFailed(response.data);
    }
  } catch (error) {
    if (axios.isAxiosError(error) && error.response) {
      console.log('Error during password reset:', error.response.data.details);
      onSetNewPasswordFailed(
        error.response.data.title != undefined
          ? error.response.data.title
          : error.response.data.details != undefined
          ? error.response.data.details
          : 'Something went wrong, Please try again.',
      );
    }
  } finally {
    setIsLoading(false);
  }
};

// Handle signup
export const handleSignup = async (
  payload: any,
  setLoading: (visible: boolean) => void,
  onSignupSuccess: (data: any) => void,
  onSignupFailed: (data: any) => void,
) => {
  // console.log('Signup payload:', payload);
  setLoading(true);
  try {
    const response = await axios.post(
      BASE_URL_DSS_OPS + ALL_URLS.CREATE_USER,
      payload,
      {
        headers: {
          'Content-Type': 'application/json',
        },
      },
    );
    console.log('Create Account Response:', response);
    if (response.status === 200) {
      onSignupSuccess(response.data);
    } else {
      onSignupFailed(response.data);
    }
  } catch (error) {
    if (axios.isAxiosError(error) && error.response) {
      if (error.response.status === 400) {
        // console.log('Error during Creating Account:', error.response.data);
        onSignupFailed(
          error.response.data === undefined
            ? 'Something went wrong, Please try again.'
            : error.response.data,
        );
      } else {
        console.error('Error during Creating Account:', error);
        onSignupFailed('Something went wrong, Please try again.');
      }
    }
  } finally {
    setLoading(false);
  }
};

export const handleCreateAccount = async (
  payload: any,
  setLoading: (visible: boolean) => void,
  onCreateSuccess: (data: any) => void,
  onCreateFailed: (data: any) => void,
) => {
  // console.log('Signup payload:', payload);
  setLoading(true);
  try {
    const response = await axios.post(
      BASE_URL_DSS_OPS + ALL_URLS.CREATE_USER,
      payload,
      {
        headers: {
          'Content-Type': 'application/json',
        },
      },
    );
    console.log('Create Account Response:', response);
    if (response.status === 200) {
      onCreateSuccess(response.data);
    } else {
      onCreateFailed(response.data);
    }
  } catch (error) {
    if (axios.isAxiosError(error) && error.response) {
      if (error.response.status === 400) {
        // console.log('Error during Creating Account:', error.response.data);
        onCreateFailed(
          error.response.data === undefined
            ? 'Something went wrong, Please try again.'
            : error.response.data,
        );
      } else {
        console.error('Error during Creating Account:', error);
        onCreateFailed('Something went wrong, Please try again.');
      }
    }
  } finally {
    setLoading(false);
  }
};

// Get Sensors Data
export const getSensorsData = async (
  payload: any,
  setLoading: (visible: boolean) => void,
  onSuccess: (data: any) => void,
  onFailed: (data: any) => void,
) => {
  // console.log('Signup payload:', payload);
  setLoading(true);
  try {
    const response = await axios.post(
      BASE_URL_HARDWARE + ALL_URLS.GET_SENSOR,
      payload,
      {
        headers: {
          'Content-Type': 'application/json',
        },
      },
    );

    if (response.status === 200) {
      onSuccess(response.data);
    } else {
      onFailed(response.data);
    }
  } catch (error) {
    if (axios.isAxiosError(error) && error.response) {
      if (error.response.status === 400) {
        // console.log('Error during Creating Account:', error.response.data);
        onFailed(
          error.response.data === undefined
            ? 'Something went wrong, Please try again.'
            : error.response.data,
        );
      } else {
        console.error('Error Getting Sensor Data:', error);
        onFailed('Something went wrong, Please try again.');
      }
    }
  } finally {
    setLoading(false);
  }
};

export const updateSensorsData = async (
  payload: any,
  onSuccess: (data: any) => void,
  onFailed: (data: any) => void,
) => {
  // console.log('Signup payload:', payload);

  try {
    const response = await axios.post(
      BASE_URL_HARDWARE + ALL_URLS.UPDATE_SENSOR,
      payload,
      {
        headers: {
          'Content-Type': 'application/json',
        },
      },
    );

    if (response.status === 200) {
      onSuccess(response.data);
    } else {
      onFailed(response.data);
    }
  } catch (error) {
    if (axios.isAxiosError(error) && error.response) {
      if (error.response.status === 400) {
        // console.log('Error during Creating Account:', error.response.data);
        onFailed(
          error.response.data === undefined
            ? 'Something went wrong, Please try again.'
            : error.response.data,
        );
      } else {
        console.error('Error Updating Sensor Data:', error);
        onFailed('Something went wrong, Please try again.');
      }
    }
  }
};

// Get Location Data
export const fetchLocations = async ({
  onFetchLocations,
  onLocationFailed,
}: {
  onFetchLocations: (data: any) => void;
  onLocationFailed: (data: any) => void;
}) => {
  try {
    const response = await axios.post(
      BASE_URL_HARDWARE + ALL_URLS.GET_LOCATION,
      [0],
      {
        headers: {
          'Content-Type': 'application/json',
        },
      },
    );
    const data = await response.data;
    onFetchLocations(data);
  } catch (error) {
    console.error('Error fetching locations:', error);
    onLocationFailed(error);
  }
};

// Get POI Data
// Get Sensors Data
export const getPoiData = async (
  payload: any,
  setLoading: (visible: boolean) => void,
  onSuccess: (data: any) => void,
  onFailed: (data: any) => void,
) => {
  // console.log('Signup payload:', payload);
  setLoading(true);
  try {
    const response = await axios.post(
      BASE_URL_DSS_OPS + ALL_URLS.GET_POI,
      payload,
      {
        headers: {
          'Content-Type': 'application/json',
        },
      },
    );

    if (response.status === 200) {
      onSuccess(response.data.data);
    } else {
      onFailed(response.data);
    }
  } catch (error) {
    if (axios.isAxiosError(error) && error.response) {
      if (error.response.status === 400) {
        // console.log('Error during Creating Account:', error.response.data);
        onFailed(
          error.response.data === undefined
            ? 'Something went wrong, Please try again.'
            : error.response.data,
        );
      } else {
        console.error('Error Getting POI Data:', error);
        onFailed('Something went wrong, Please try again.');
      }
    }
  } finally {
    setLoading(false);
  }
};

// Send or Resend Otp Api
export const HandleSendOtp = async (
  payload: any,
  // setLoading: (visible: boolean) => void,
  onSuccessSentOtp: (data: any) => void,
  onFailedSendOtp: (data: any) => void,
) => {
  try {
    const response = await axios.post(
      BASE_URL_DSS_OPS + ALL_URLS.VERIFY_MOBILE,
      payload,
      {
        headers: {
          'Content-Type': 'application/json',
        },
      },
    );

    if (response.status === 200) {
      onSuccessSentOtp(response.data.message);
    } else {
      onFailedSendOtp(response.data.message);
    }
  } catch (error) {
    if (axios.isAxiosError(error) && error.response) {
      if (error.response.status === 400) {
        // console.log('Error during Creating Account:', error.response.data);
        onFailedSendOtp(
          error.response.data === undefined
            ? 'Something went wrong, Please try again.'
            : error.response.data,
        );
      } else {
        console.error('Error Getting Login Data:', error);
        onFailedSendOtp('Something went wrong, Please try again.');
      }
    }
  } finally {
    // setLoading(false);
  }
};

// Get Maintenance Data
export const getMaintenanceData = async (
  payload: any,
  // setLoading: (visible: boolean) => void,
  onSuccess: (data: any) => void,
  onFailed: (data: any) => void,
) => {
  const token = await getToken();
  try {
    // setLoading(true);
    const response = await axios.get(
      `${BASE_URL_DSS_OPS}${ALL_URLS.GET_MAINTENANCE}`,
      // payload,
      {
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
      },
    );
    if (response.status === 200) {
      onSuccess(response.data);
    } else {
      onFailed(response.data);
    }
  } catch (error) {
    if (axios.isAxiosError(error)) {
      const errorMessage =
        error.response?.data || 'Something went wrong, Please try again.';
      onFailed(errorMessage);
      if (error.response?.status !== 400) {
        console.error('Error Getting Maintenance Data:', error);
      }
    }
  } finally {
    // setLoading(false);
  }
};

export const getEscalationData = async (
  payload: any,
  // setLoading: (visible: boolean) => void,
  onSuccess: (data: any) => void,
  onFailed: (data: any) => void,
) => {
  const token = await getToken();
  try {
    // setLoading(true);
    const response = await axios.get(
      `${BASE_URL_DSS_OPS}${ALL_URLS.GET_ESCALATION}`,
      // payload,
      {
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
      },
    );
    if (response.status === 200) {
      onSuccess(response.data);
    } else {
      onFailed(response.data);
    }
  } catch (error) {
    if (axios.isAxiosError(error)) {
      const errorMessage =
        error.response?.data || 'Something went wrong, Please try again.';
      onFailed(errorMessage);
      if (error.response?.status !== 400) {
        console.error('Error Getting Escalation Data:', error);
      }
    }
  } finally {
    // setLoading(false);
  }
};

// Get Incident Data
export const getIncidentData = async (
  payload: any,
  // setLoading: (visible: boolean) => void,
  onSuccess: (data: any) => void,
  onFailed: (data: any) => void,
) => {
  const token = await getToken();
  try {
    // setLoading(true);
    const response = await axios.get(
      `${BASE_URL_DSS_OPS}${ALL_URLS.GET_INCIDENTS}`,
      // payload,
      {
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
      },
    );
    if (response.status === 200) {
      onSuccess(response.data);
    } else {
      onFailed(response.data);
    }
  } catch (error) {
    if (axios.isAxiosError(error)) {
      const errorMessage =
        error.response?.data || 'Something went wrong, Please try again.';
      onFailed(errorMessage);
      if (error.response?.status !== 400) {
        console.error('Error Getting Incident Data:', error);
      }
    }
  } finally {
    // setLoading(false);
  }
};

// Upload Incident
export const uploadIncident = async (
  incidentDetails: any,
  setLoading: (loading: boolean) => void,
  onSuccess: (data: any) => void,
  onFailure: (error: string) => void,
) => {
  try {
    setLoading(true);
    const formData = new FormData();

    // Append image files
    const imageUris = incidentDetails.PictureFile.filter(Boolean);
    imageUris.forEach((imageUri: string, index: number) => {
      formData.append('PictureFile', {
        uri: Platform.OS === 'android' ? imageUri : imageUri.replace('file://', ''),
        type: 'image/png',
        name: `picture${index + 1}.png`,
      });
    });

    // Append other form data fields
    formData.append('ReportedByUserID', incidentDetails.ReportedByUserID.toString());
    formData.append('Description', incidentDetails.Description);
    formData.append('Comments', incidentDetails.Comments);
    formData.append('Latitude', incidentDetails.Latitude.toString());
    formData.append('Longitude', incidentDetails.Longitude.toString());
    formData.append('ReportTime', incidentDetails.ReportTime);
    formData.append('IncidentCategory', incidentDetails.IncidentCategory.toString());
    formData.append('isActive', incidentDetails.isActive.toString());
    formData.append('IncidentStatus', incidentDetails.IncidentStatus.toString());
    const token = await getToken(); // Optional if token is needed
    const response = await axios.post(
      `${BASE_URL_DSS_OPS}${ALL_URLS.UPLOAD_INCIDENT}`,
      formData,
      {
        headers: {
          'Content-Type': 'multipart/form-data',
          // 'Authorization': `Bearer ${token}`  // Uncomment if needed
        },
      }
    );
    console.log('Upload Response', response.data);
    onSuccess(response.data);
  } catch (error: any) {
    console.error('Upload Error:', error.message || error);
    onFailure(error.message || 'Failed to upload incident');
  } finally {
    setLoading(false);
  }
};


// Get Dashboard Data
export const getDashboardData = (
  payload: any,
  setLoading: (visible: boolean) => void,
  onSuccess: (data: any) => void,
  onFailed: (data: any) => void,
) => {
  setLoading(true);
  const token = getToken();
  axios
    .get(BASE_URL_DSS_OPS + ALL_URLS.GET_DASHBOARD_DATA, {
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`,
      },
    })
    .then((response) => {
      onSuccess(response.data);
    })
    .catch((error) => {
      onFailed(error.response?.data || 'Failed to fetch dashboard data');
    })
    .finally(() => {
      setLoading(false);
    });
};

interface ApiResponse<T> {
  data: T;
  status: number;
  statusText: string;
}

interface User {
  id: number;
  name: string;
}


export const getAllUsers = async (): Promise<ApiResponse<User[]>> => {
  try {
    const response = await axios.get(`${BASE_URL_DSS_OPS}${ALL_URLS.GET_USERS}`);
    return {
      data: response.data,
      status: response.status,
      statusText: response.statusText
    };
  } catch (error) {
    console.error('Error fetching users:', error);
    throw error;
  }
};


// Get Flood Data
export const getFloodData = async (
  payload: any,
  setLoading: (visible: boolean) => void,
  onSuccess: (data: any) => void,
  onFailed: (data: any) => void,
) => {
  setLoading(true);
  try {
    const token = await getToken();
    const response = await axios.get(
      `${BASE_URL_DSS_OPS}${ALL_URLS.GET_FLOOD_INFORMATION}`,
      {
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
      },
    );
    if (response.status === 200) {
      onSuccess(response.data.data);
    } else {
      onFailed(response.data);
    }
  } catch (error) {
    if (axios.isAxiosError(error)) {
      const errorMessage =
      error.response?.data || 'Something went wrong, Please try again.';
      onFailed(errorMessage);
      if (error.response?.status !== 400) {
        setLoading(false);
        console.error('Error Getting Flood Data:', error);
      }
    }
  } finally {
    setLoading(false);
  }
};

export const getAddressFromCoordinates = async (latitude: any, longitude: any) => {
  try {
    const response = await fetch(
      `https://nominatim.openstreetmap.org/reverse?format=json&lat=${latitude}&lon=${longitude}&addressdetails=1`,
    );
    const data = await response.json();
    const address = data.address;
    const city = address.city || address.town || address.village || '';
    const state = address.state || '';
    const area = address.suburb || address.neighbourhood || '';
    return {city, state, area};
  } catch (error) {
    console.error('Error fetching location:', error);
    return {};
  }
};


export const getTasks = async (
  payload: any,
  setLoading: (visible: boolean) => void,
  onSuccess: (data: any) => void,
  onFailed: (data: any) => void,
) => {
  setLoading(true);
  try {
    const url = `${BASE_URL_DSS_OPS}${ALL_URLS.GET_TASKS}?status=${2}`;
    console.log('url passing', url);
    const token = await getToken();
    const response = await axios.get(
      url,
      {
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
      },
    );
    if (response.status === 200) {
      onSuccess(response.data.data);
    } else {
      onFailed(response.data);
    }
  } catch (error) {
    if (axios.isAxiosError(error)) {
      const errorMessage =
      error.response?.data || 'Something went wrong, Please try again.';
      onFailed(errorMessage);
      if (error.response?.status !== 400) {
        setLoading(false);
        console.error('Error Getting Tasks Data:', error);
      }
    }
  } finally {
    setLoading(false);
  }
};


export const getPumpOperationsData = async (
  payload: any,
  // setLoading: (visible: boolean) => void,
  onSuccess: (data: any) => void,
  onFailed: (data: any) => void,
) => {
  const token = await getToken();
  try {
    // setLoading(true);
    const response = await axios.get(
      `${BASE_URL_DSS_OPS}${ALL_URLS.GET_PUMP_OPERATIONS}`,
      // payload,
      {
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
      },
    );
    if (response.status === 200) {
      onSuccess(response.data.data);
    } else {
      onFailed(response.data);
    }
  } catch (error) {
    if (axios.isAxiosError(error)) {
      const errorMessage =
        error.response?.data || 'Something went wrong, Please try again.';
      onFailed(errorMessage);
      if (error.response?.status !== 400) {
        console.error('Error Getting Maintenance Data:', error);
      }
    }
  } finally {
    // setLoading(false);
  }
};