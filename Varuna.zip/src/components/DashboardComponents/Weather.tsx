import React, {useState, useEffect} from 'react';
import {Dimensions, StyleSheet, View, ScrollView} from 'react-native';
import MapView from 'react-native-maps';
import {Card, DataTable, List, Avatar} from 'react-native-paper';
import {
  ALL_URLS,
  BASE_URL,
  BASE_URL_WEATHER,
  LanguageString,
  width,
} from '../../constants/data';
import axios from 'axios';
import {COLORS} from '../../constants/colors';
import {FwTextPrimary} from '../../elements';
import {normalized} from '../../constants/platform';

const NowcastSection = () => {
  const [nowcastData, setNowcastData] = useState({
    forecast: 'No Warning',
    timeOfIssue: '16:00',
    validUpto: '19.00',
  });

  // useEffect(() => {
  //   const fetchNowcastData = async () => {
  //     try {
  //       const response = await axios.get(
  //         BASE_URL_WEATHER + ALL_URLS.GET_NOWCAST,
  //         {
  //           headers: {
  //             'Content-Type': 'application/json',
  //           },
  //         },
  //       );
  //       setNowcastData(response.data);
  //     } catch (error) {
  //       console.error('Error fetching nowcast data:', error);
  //     }
  //   };
  //   fetchNowcastData();
  // }, []);

  return (
    <Card style={styles.card}>
      <Card.Title
        title={LanguageString('Nowcast')}
        titleStyle={[styles.nowcastTitle, styles.cardTitle]}
        style={styles.cardTitleContainer}
      />
      <Card.Content style={styles.nowcastContent}>
        <View style={styles.nowcastRow}>
          <FwTextPrimary style={styles.nowcastWarning}>
            {LanguageString(nowcastData.forecast)}
          </FwTextPrimary>
        </View>
      </Card.Content>
      <View style={styles.footer}>
        <FwTextPrimary style={styles.footerText}>
          {LanguageString('Time of Issue')}: {nowcastData.timeOfIssue}
        </FwTextPrimary>
        <FwTextPrimary style={styles.footerText}>
          {LanguageString('Valid Upto')}: {nowcastData.validUpto}
        </FwTextPrimary>
      </View>
    </Card>
  );
};
const WeatherMap = () => {
  const [rainfallData, setRainfallData] = useState(null);

  // useEffect(() => {
  //   const fetchRainfallData = async () => {
  //     try {
  //       const response = await axios.post(
  //         BASE_URL + ALL_URLS.GET_LOCATION,
  //         [0],
  //         {
  //           headers: {
  //             'Content-Type': 'application/json',
  //           },
  //         },
  //       );
  //       const data = await response.data;
  //       setRainfallData(data);
  //     } catch (error) {
  //       console.error('Error fetching rainfall data:', error);
  //     }
  //   };
  //   fetchRainfallData();
  // }, []);

  return (
    <Card style={styles.card}>
      <Card.Content>
        <MapView
          style={styles.map}
          initialRegion={{
            latitude: 26.7605,
            longitude: 83.3731,
            latitudeDelta: 0.0922,
            longitudeDelta: 0.0421,
          }}>
          {/* {rainfallData &&
            rainfallData.markers?.map((marker, index) => (
              <Marker
                key={index}
                coordinate={{
                  latitude: marker.latitude,
                  longitude: marker.longitude,
                }}
                title={marker.title}
                description={marker.description}
              />
            ))} */}
        </MapView>
      </Card.Content>
    </Card>
  );
};
const OneDayData = () => {
  const [weatherData, setWeatherData] = useState({
    maxTemp: '30.2',
    todayMinTemp: '18.3',
    todayMinDepartureFromNormal: '3.2',
    maxDepartureFromNormal: '3.2',
    past24HrsRainfall: '413 mm',
    relativeHumidityAt0830: '95',
    relativeHumidityAt1730: '81',
    previousDayRelativeHumidityAt1730: '74',
  });

  // useEffect(() => {
  //   const fetchWeatherData = async () => {
  //     try {
  //       const response = await axios.get(
  //         BASE_URL_WEATHER + ALL_URLS.GET_FORCAST,
  //         {
  //           headers: {
  //             'Content-Type': 'application/json',
  //           },
  //         },
  //       );
  //       setWeatherData(response.data);
  //     } catch (error) {
  //       console.error('Error fetching weather data:', error);
  //     }
  //   };
  //   fetchWeatherData();
  // }, []);

  return (
    <Card style={styles.card}>
      <Card.Title
        title={LanguageString('Past 24 Hours Weather Data')}
        titleStyle={[styles.sectionTitle, styles.cardTitle]}
        style={styles.cardTitleContainer}
      />
      <Card.Content style={styles.nowcastContent}>
        <List.Item
          title={LanguageString('Max Temperature')}
          description={`${weatherData.maxTemp} °C`}
          titleStyle={styles.nowcastText}
          descriptionStyle={styles.nowcastText}
          left={() => <Avatar.Icon size={30} icon="thermometer" />}
        />
        <List.Item
          title={LanguageString('Min Temperature')}
          description={`${weatherData.todayMinTemp} °C`}
          titleStyle={styles.nowcastText}
          descriptionStyle={styles.nowcastText}
          left={() => <Avatar.Icon size={30} icon="thermometer-minus" />}
        />
        <List.Item
          title={LanguageString('Min Departure from Normal')}
          description={`${weatherData.todayMinDepartureFromNormal} °C`}
          titleStyle={styles.nowcastText}
          descriptionStyle={styles.nowcastText}
          left={() => <Avatar.Icon size={30} icon="arrow-up" />}
        />
        <List.Item
          title={LanguageString('Rainfall')}
          description={weatherData.past24HrsRainfall}
          titleStyle={styles.nowcastText}
          descriptionStyle={styles.nowcastText}
          left={() => <Avatar.Icon size={30} icon="weather-rainy" />}
        />
        <List.Item
          title={LanguageString('Relative Humidity at 08:30')}
          description={`${weatherData.relativeHumidityAt0830} %`}
          titleStyle={styles.nowcastText}
          descriptionStyle={styles.nowcastText}
          left={() => <Avatar.Icon size={30} icon="water" />}
        />
        <List.Item
          title={LanguageString('Relative Humidity at 17:30')}
          description={
            weatherData.relativeHumidityAt1730
              ? `${weatherData.relativeHumidityAt1730} %`
              : 'N/A'
          }
          titleStyle={styles.nowcastText}
          descriptionStyle={styles.nowcastText}
          left={() => <Avatar.Icon size={30} icon="water-outline" />}
        />
        <List.Item
          title={LanguageString('Previous Day Relative Humidity at 17:30')}
          description={`${weatherData.previousDayRelativeHumidityAt1730} %`}
          titleStyle={styles.nowcastText}
          descriptionStyle={styles.nowcastText}
          left={() => <Avatar.Icon size={30} icon="water-off" />}
        />
      </Card.Content>
    </Card>
  );
};
const ForecastSection = () => {
  const [forecastData, setForecastData] = useState([
    {
      date: '2024-11-13',
      forecast: 'Dense Fog',
      warning: 'Fog',
      color: COLORS.DARKYELLOW,
    },
    {
      date: '2024-11-14',
      forecast: 'Dense Fog',
      warning: 'Fog',
      color: COLORS.DARKYELLOW,
    },
    {
      date: '2024-11-15',
      forecast: 'Mist',
      warning: 'No Warning',
      color: COLORS.LIGHTGREEN,
    },
    {
      date: '2024-11-16',
      forecast: 'Mist',
      warning: 'No Warning',
      color: COLORS.LIGHTGREEN,
    },
    {
      date: '2024-11-17',
      forecast: 'Mist',
      warning: 'No Warning',
      color: COLORS.LIGHTGREEN,
    },
  ]);

  // useEffect(() => {
  //   const fetchForecastData = async () => {
  //     try {
  //       const response = await axios.get(
  //         BASE_URL_WEATHER + ALL_URLS.GET_FORCAST,
  //         {
  //           headers: {
  //             'Content-Type': 'application/json',
  //           },
  //         },
  //       );

  //       setForecastData(response.data.forecasts);
  //     } catch (error) {
  //       console.error('Error fetching forecast data:', error);
  //     }
  //   };
  //   fetchForecastData();
  // }, []);

  return (
    <Card style={styles.card}>
      <Card.Title
        title={LanguageString('5 Days Forecast Warning')}
        titleStyle={styles.cardTitle}
        style={styles.cardTitleContainer}
      />
      <Card.Content>
        <DataTable style={styles.dataTable}>
          <DataTable.Header>
            <DataTable.Title>{LanguageString('Date')}</DataTable.Title>
            <DataTable.Title>{LanguageString('Forecast')}</DataTable.Title>
            <DataTable.Title>{LanguageString('Warning')}</DataTable.Title>
          </DataTable.Header>
          {forecastData.map(
            (
              item: {
                date: string;
                forecast: string;
                color: string;
                warning: string;
              },
              index: number,
            ) => (
              <DataTable.Row key={index} style={styles.dataTableRow}>
                <DataTable.Cell>{item.date}</DataTable.Cell>
                <DataTable.Cell>{LanguageString(item.forecast)}</DataTable.Cell>
                <DataTable.Cell
                  style={[
                    styles.colorIndicatorWrapper,
                    {backgroundColor: item.color},
                  ]}>
                  <FwTextPrimary>{LanguageString(item.warning)}</FwTextPrimary>
                  <View />
                </DataTable.Cell>
              </DataTable.Row>
            ),
          )}
        </DataTable>
      </Card.Content>
    </Card>
  );
};
const WeatherScreen = () => (
  <View style={styles.container}>
    <ScrollView contentContainerStyle={styles.scrollContent}>
      <NowcastSection />
      <WeatherMap />
      <OneDayData />
      <ForecastSection />
    </ScrollView>
  </View>
);

export default WeatherScreen;

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  scrollContent: {
    padding: normalized(10),
    flexGrow: 1,
  },
  card: {
    marginVertical: normalized(10),
  },
  nowcastTitle: {
    fontSize: normalized(20),
    textAlign: 'center',
  },
  nowcastContent: {
    alignItems: 'center',
    marginTop: normalized(10),
  },
  nowcastRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: normalized(10),
  },
  nowcastWarning: {
    backgroundColor: COLORS.LIGHTGREEN,
    paddingHorizontal: normalized(10),
    borderRadius: normalized(10),
  },
  sectionTitle: {
    fontSize: normalized(18),
  },
  map: {
    width: normalized(width - 100),
    height: normalized(200),
  },
  colorIndicatorWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    textAlign: 'center',
    margin: normalized(10),
    paddingLeft: normalized(5),
    paddingRight: normalized(5),
    borderRadius: normalized(30),
  },
  dataTableRow: {marginHorizontal: 0, paddingHorizontal: 0},
  dataTable: {borderRadius: 4, overflow: 'scroll'},

  nowcastText: {
    display: 'flex',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    fontSize: normalized(15),
  },
  cardTitle: {
    color: COLORS.SECONDARY,
    textAlign: 'center',
    fontSize: normalized(18),
  },
  cardTitleContainer: {
    backgroundColor: COLORS.PRIMARY,
  },
  footer: {
    display: 'flex',
    flexDirection: 'row',
    backgroundColor: COLORS.LIGHTGRAY,
    width: '100%',
    padding: normalized(10),
    borderBottomLeftRadius: 8,
    borderBottomRightRadius: 8,
    justifyContent: 'space-between',
  },
  footerText: {
    textAlign: 'center',
    fontSize: normalized(16),
  },
});
