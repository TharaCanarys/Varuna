import {DefaultTheme} from 'react-native-paper';
import {COLORS} from './colors';
import {StyleSheet} from 'react-native';
import {normalized} from './platform';

export const theme = {
  ...DefaultTheme,
  colors: {
    ...DefaultTheme.colors,
    primary: COLORS.PRIMARY,
    accent: COLORS.SECONDARY,
    // Handling Custom Overlay transparency
    backdrop: COLORS.LOW_TRANSPARENT,
  },
};

export const commonStyle = StyleSheet.create({
  modalRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: normalized(8),
  },
  boldText: {
    fontWeight: 'bold',
    flex: normalized(1),
    letterSpacing: normalized(1.2),
    fontSize: normalized(16),
  },
  normalText: {
    color: COLORS.BLACK,
    flex: normalized(1.2),
    letterSpacing: normalized(1.2),
    lineHeight: normalized(25),
    fontSize: normalized(15),
    marginLeft: normalized(-5),
  },
  cardHeaderText: {
    fontWeight: 'semibold',
    letterSpacing: 1,
    lineHeight: normalized(30),
    fontSize: normalized(20),
  },
  cardContent: {
    marginLeft: normalized(58),
    marginTop: normalized(-16),
  },
  cardText: {
    color: COLORS.BLACK,
  },
  // Dashboard Styling
  metricTitle: {
    fontSize: normalized(18),
    fontWeight: 'bold',
    marginTop: normalized(8),
    textAlign: 'center',
  },
  metricValue: {
    fontSize: normalized(12),
    lineHeight: normalized(24),
    textAlign: 'center',
  },
  metric: {
    justifyContent: 'center',
    alignItems: 'center',
    flex: 1,
  },
  card: {
    marginBottom: normalized(16),
  },
  cardContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: normalized(16),
  },
  addButtonContainer: {
    marginRight: normalized(16),
    alignItems: 'flex-end',
  },
  closeButton: {
    marginTop: normalized(24),
  },
  saveButton: {
    marginTop: normalized(16),
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: normalized(24),
  },
  modalTitle: {
    fontSize: normalized(20),
    padding: normalized(16),
    fontWeight: 'bold',
    color: COLORS.BLACK,
  },
});
