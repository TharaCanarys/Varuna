import React, {useCallback, useState, useMemo, useEffect} from 'react';
import SensorScreenView from './SensorScreenView';
import {SensorPropTypes} from '../../types/commonTypes';
import {LanguageString} from '../../constants/data';
import {getSensorsData, updateSensorsData} from '../../services/apiServices';
import {RootState} from '../../store/store';
import {useSelector} from 'react-redux';

const SensorScreen: React.FC = () => {
  const locations = useSelector((state: RootState) => state.app.locations);
  const [allLocations, setAllLocations] = useState<any>();
  const [selectedSensor, setSelectedSensor] = useState<SensorPropTypes | null>(
    null,
  );
  const [editingStatus, setEditingStatus] = useState(false);
  const [newStatus, setNewStatus] = useState('');
  const [statusError, setStatusError] = useState('');
  const [sensors, setSensors] = useState<SensorPropTypes[]>([]);
  const [isAddingNewSensor, setIsAddingNewSensor] = useState(false);
  const [isSwitchOn, setIsSwitchOn] = React.useState(false);
  const [isLoading, setLoading] = useState(false);
  const [sensorNameOptions, setSensorOptions] = useState([]);
  const [locationOptions, setLocationOptions] = useState([]);
  const [newSensor, setNewSensor] = useState<SensorPropTypes>({
    sensorId: 0,
    sensorName: '',
    type: 0,
    status: '',
    locationName: '',
    sensorType: 0,
    locationId: 0,
    installedDate: '',
  });
  const [showDatePicker, setShowDatePicker] = useState(false);
  const [errors, setErrors] = useState({
    sensorName: '',
    type: 0,
    locationName: '',
    installedDate: '',
    status: '',
  });
  const [refreshing, setRefreshing] = useState(false);

  const initialNewSensorState = useMemo(
    () => ({
      sensorId: 0,
      sensorName: '',
      type: 0,
      status: '',
      locationName: '',
      installedDate: '',
      locationId: 0,
      sensorType: 0,
    }),
    [],
  );

  const onGetFailed = useCallback((error: any) => {
    console.log('Failed to get data', error);
  }, []);

  const onGetSuccess = useCallback(
    (data: any) => {
      const updatedData = data.map((sensor: any) => {
        const location = locations?.find(
          (loc: any) => loc.id === sensor.locationId,
        );
        return {
          ...sensor,
          locationName: location?.locationName || '',
        };
      });
      setSensors(updatedData);
      setSensorOptions(
        updatedData.map((sensor: {sensorName: any}) => ({
          label: sensor.sensorName,
          value: sensor.sensorName,
        })),
      );
      setLocationOptions(
        allLocations?.map((location: any) => ({
          label: location.locationName,
          value: location.id,
        })) || [],
      );
    },
    [allLocations],
  );

  const language = useSelector(
    (state: RootState) => state.app.selectedLanguage,
  );

  useEffect(() => {
    getSensors();
    if (locations) {
      setAllLocations(locations);
    }
  }, [onGetSuccess, onGetFailed, language, locations]);

  const getSensors = () => {
    let payload = [0];
    getSensorsData(payload, setLoading, onGetSuccess, onGetFailed);
  };

  const onRefresh = useCallback(() => {
    setRefreshing(true);
    getSensors();
    setTimeout(() => {
      setRefreshing(false);
    }, 1000);
  }, [language]);

  const openSensorDetails = useCallback(
    (sensor: SensorPropTypes) => {
      setSelectedSensor(sensor);
      setNewStatus(sensor.status.toString());
    },
    [locations],
  );

  const closeSensorDetails = useCallback(() => {
    setSelectedSensor(null);
    setEditingStatus(false);
  }, []);

  const startEditingStatus = useCallback(() => {
    setEditingStatus(prev => !prev);
  }, []);

  const saveStatus = useCallback(() => {
    if (selectedSensor) {
      const updatedSensor = {...selectedSensor, status: newStatus};
      setSensors(prevSensors =>
        prevSensors.map(sensor =>
          sensor.sensorId === selectedSensor.sensorId ? updatedSensor : sensor,
        ),
      );
      setSelectedSensor(updatedSensor);
      setEditingStatus(false);
      handleUpdateSensor(updatedSensor);
    }
  }, [selectedSensor, newStatus]);

  const onUpdateSuccess = useCallback((data: any) => {
    console.log('Successfully updated sensor', data);
  }, []);

  const onUpdateFailed = useCallback((error: any) => {
    console.log('Failed to update sensor', error);
  }, []);

  const handleUpdateSensor = useCallback((sensor: SensorPropTypes) => {
    let payload = {
      sensorId: sensor.sensorId,
      sensorName: sensor.sensorName,
      sensorType: sensor.sensorType,
      installedDate: sensor.installedDate,
      status: Number(sensor.status),
      locationId: sensor.locationId,
      locationName: sensor.locationName,
    };
    updateSensorsData(payload, onUpdateSuccess, onUpdateFailed);
  }, []);
  const validateStatus = useCallback((status: string) => {
    if (!status) {
      setStatusError('Status is required');
    } else {
      setStatusError('');
    }
  }, []);

  const openAddNewSensor = useCallback(() => {
    setIsAddingNewSensor(true);
  }, []);

  const closeAddNewSensor = useCallback(() => {
    setIsAddingNewSensor(false);
    setNewSensor(initialNewSensorState);
    setErrors({
      sensorName: '',
      type: 0,
      locationName: '',
      installedDate: '',
      status: '',
    });
  }, [initialNewSensorState]);

  const validateNewSensor = useCallback(() => {
    let hasError = false;
    const newErrors = {
      sensorName: '',
      type: 0,
      locationName: '',
      installedDate: '',
      status: '',
    };

    if (!newSensor.sensorName.trim()) {
      newErrors.sensorName = `${LanguageString('Sensor Name')} ${LanguageString(
        'is required',
      )}`;
      hasError = true;
    }

    // if (!newSensor.type) {
    //   newErrors.type = 0;
    //   hasError = true;
    // }

    if (!newSensor.locationName) {
      newErrors.locationName = `${LanguageString('Location')} ${LanguageString(
        'is required',
      )}`;
      hasError = true;
    }

    if (!newSensor.installedDate) {
      newErrors.installedDate = `${LanguageString(
        'Installation Date',
      )} ${LanguageString('is required')}`;
      hasError = true;
    }

    if (newSensor.status === '') {
      newErrors.status = `${LanguageString('Status')} ${LanguageString(
        'is required',
      )}`;
      hasError = true;
    }

    setErrors(newErrors);
    return !hasError;
  }, [newSensor, LanguageString]);

  const handleAddNewSensor = useCallback(() => {
    if (!validateNewSensor()) {
      return;
    }

    setSensors(prevSensors => {
      const existingIds = new Set(prevSensors.map(s => s.sensorId));
      let newId = 1;
      while (existingIds.has(newId)) {
        newId++;
      }
      const sensorToAdd = {...newSensor, sensorId: newId};
      return [...prevSensors, sensorToAdd];
    });
    let payload = {
      sensorName: newSensor.sensorName,
      sensorType: newSensor.type,
      installedDate: newSensor.installedDate,
      status: Number(newSensor.status),
      locationId: newSensor.locationName,
    };
    console.log('NEWWWW SENSOR', payload);
    // setNewSensor(initialNewSensorState);
    // setErrors({
    //   sensorName: '',
    //   type: '',
    //   locationName: '',
    //   installedDate: '',
    //   status: '',
    // });
    // setIsAddingNewSensor(false);
  }, [newSensor, validateNewSensor, initialNewSensorState]);

  const handleDeleteSensor = useCallback((sensor: SensorPropTypes) => {
    setSensors(prevSensors =>
      prevSensors.filter(s => s.sensorId !== sensor.sensorId),
    );
  }, []);

  const onDateChange = useCallback((selectedDate: Date) => {
    setShowDatePicker(false);
    setNewSensor(prev => ({
      ...prev,
      installedDate: selectedDate.toISOString(),
    }));
  }, []);

  const sensorScreenViewProps = useMemo(
    () => ({
      selectedSensor,
      setShowDatePicker,
      editingStatus,
      newStatus,
      sensors,
      isAddingNewSensor,
      newSensor,
      setNewSensor,
      setNewStatus,
      showDatePicker,
      errors,
      refreshing,
      onRefresh,
      openSensorDetails,
      closeSensorDetails,
      startEditingStatus,
      saveStatus,
      validateStatus,
      openAddNewSensor,
      closeAddNewSensor,
      handleAddNewSensor,
      handleDeleteSensor,
      isSwitchOn,
      setIsSwitchOn,
      onDateChange,
      handleUpdateSensor,
      isLoading,
      sensorNameOptions,
      locationOptions,
    }),
    [
      selectedSensor,
      editingStatus,
      newStatus,
      sensors,
      isAddingNewSensor,
      newSensor,
      showDatePicker,
      errors,
      refreshing,
      onRefresh,
      openSensorDetails,
      closeSensorDetails,
      startEditingStatus,
      saveStatus,
      validateStatus,
      openAddNewSensor,
      closeAddNewSensor,
      handleAddNewSensor,
      handleDeleteSensor,
      isSwitchOn,
      setIsSwitchOn,
      onDateChange,
      handleUpdateSensor,
      isLoading,
      sensorNameOptions,
      locationOptions,
    ],
  );

  return <SensorScreenView {...sensorScreenViewProps} />;
};

export default SensorScreen;
