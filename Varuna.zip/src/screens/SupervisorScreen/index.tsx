import React from 'react';
import SupervisorScreenView from './SupervisorScreenView';

const SupervisorScreen: React.FC = () => {
  return <SupervisorScreenView />;
};
export default SupervisorScreen;
