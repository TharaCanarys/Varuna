import React, {useCallback, useState, useMemo} from 'react';
import {PumpStationPropTypes} from '../../types/commonTypes';
import {LanguageString, pumpStationData} from '../../constants/data';
import PumpStationScreenView from './PumpStationScreenView';

const PumpStationScreen: React.FC = () => {
  const [selectedPumpStation, setSelectedPumpStation] =
    useState<PumpStationPropTypes | null>(null);
  const [pumpStations, setPumpStations] =
    useState<PumpStationPropTypes[]>(pumpStationData);
  const [isAddingNewPumpStation, setIsAddingNewPumpStation] = useState(false);
  const [newPumpStation, setNewPumpStation] = useState<PumpStationPropTypes>({
    id: 0,
    PumpStationid: 0,
    PumpHouseName: '',
    inspectionDate: '',
    Locationid: 0,
    Elevation: 0,
    PumpType: '',
    PumpNumber: 0,
    RatedPower: 0,
    Location: '',
    PipeDetails: '',
    PumpOperationRawData: '',
  });
  const [showDatePicker, setShowDatePicker] = useState(false);

  const [errors, setErrors] = useState({
    PumpStationid: 0,
    PumpHouseName: '',
    inspectionDate: '',
    Locationid: 0,
    Elevation: 0,
    PumpType: '',
    PumpNumber: 0,
    RatedPower: 0,
    Location: '',
    PipeDetails: '',
    PumpOperationRawData: '',
  });
  const [refreshing, setRefreshing] = useState(false);

  // Memoize the initial state of newPumpStation to avoid unnecessary re-renders
  const initialNewPumpStationState = useMemo(
    () => ({
      id: 0,
      PumpStationid: 0,
      PumpHouseName: '',
      inspectionDate: '',
      Locationid: 0,
      Elevation: 0,
      PumpType: '',
      PumpNumber: 0,
      RatedPower: 0,
      Location: '',
      PipeDetails: '',
      PumpOperationRawData: '',
    }),
    [],
  );

  // Simulate data refresh
  const onRefresh = useCallback(() => {
    setRefreshing(true);
    setTimeout(() => {
      setPumpStations([...pumpStationData]);
      setRefreshing(false);
    }, 1000);
  }, []);

  // Open pumpStation details modal
  const openPumpStationDetails = useCallback(
    (pumpStation: PumpStationPropTypes) => {
      setSelectedPumpStation(pumpStation);
    },
    [],
  );

  // Close pumpStation details modal
  const closePumpStationDetails = useCallback(() => {
    setSelectedPumpStation(null);
  }, []);

  // Open add new pumpStation modal
  const openAddNewPumpStation = useCallback(() => {
    setIsAddingNewPumpStation(true);
  }, []);

  // Close add new pumpStation modal
  const closeAddNewPumpStation = useCallback(() => {
    setIsAddingNewPumpStation(false);
    setNewPumpStation(initialNewPumpStationState);
    setErrors({
      PumpStationid: 0,
      PumpHouseName: '',
      inspectionDate: '',
      Locationid: 0,
      Elevation: 0,
      PumpType: '',
      PumpNumber: 0,
      RatedPower: 0,
      Location: '',
      PipeDetails: '',
      PumpOperationRawData: '',
    });
  }, [initialNewPumpStationState]);

  // Validate new pumpStation input
  const validateNewPumpStation = useCallback(() => {
    let isValid = true;
    const newErrors = {
      PumpStationid: 0,
      PumpHouseName: '',
      inspectionDate: '',
      Locationid: 0,
      Elevation: 0,
      PumpType: '',
      PumpNumber: 0,
      RatedPower: 0,
      Location: '',
      PipeDetails: '',
      PumpOperationRawData: '',
    };

    if (!newPumpStation.PumpType) {
      newErrors.PumpType =
        LanguageString('Type') + ' ' + LanguageString('is required');
      isValid = false;
    }

    setErrors(newErrors);
    return isValid;
  }, [newPumpStation]);

  // Add new pumpStation
  const handleAddNewPumpStation = useCallback(() => {
    if (validateNewPumpStation()) {
      setPumpStations(prevPumpStations => {
        const newId = Math.max(...prevPumpStations.map(s => s.id)) + 1;
        const pumpStationToAdd = {...newPumpStation, id: newId};
        return [...prevPumpStations, pumpStationToAdd];
      });
      closeAddNewPumpStation();
    }
  }, [newPumpStation, validateNewPumpStation, closeAddNewPumpStation]);

  // Delete pumpStation
  const handleDeletePumpStation = useCallback(
    (pumpStation: PumpStationPropTypes) => {
      setPumpStations(prevPumpStations =>
        prevPumpStations.filter(s => s.id !== pumpStation.id),
      );
    },
    [],
  );
  // Handle date change
  const onDateChange = useCallback((selectedDate: Date) => {
    console.log('Selected date:', selectedDate);
    setShowDatePicker(false);
    const indianTime = new Date(selectedDate.getTime() + 5.5 * 60 * 60 * 1000);
    setSelectedPumpStation(prevStation => ({
      ...prevStation!,
      inspectionDate: indianTime.toISOString().slice(0, 19).replace('T', ' '),
    }));
  }, []);

  // Memoize the props for PumpStationScreenView to prevent unnecessary re-renders
  const pumpStationScreenViewProps = useMemo(
    () => ({
      selectedPumpStation,
      setSelectedPumpStation,
      setShowDatePicker,
      pumpStations,
      isAddingNewPumpStation,
      newPumpStation,
      setNewPumpStation,
      showDatePicker,
      errors,
      refreshing,
      onRefresh,
      openPumpStationDetails,
      closePumpStationDetails,
      openAddNewPumpStation,
      closeAddNewPumpStation,
      handleAddNewPumpStation,
      handleDeletePumpStation,
      onDateChange,
    }),
    [
      selectedPumpStation,
      setSelectedPumpStation,
      pumpStations,
      isAddingNewPumpStation,
      newPumpStation,
      showDatePicker,
      errors,
      refreshing,
      onRefresh,
      openPumpStationDetails,
      closePumpStationDetails,
      openAddNewPumpStation,
      closeAddNewPumpStation,
      handleAddNewPumpStation,
      handleDeletePumpStation,
      onDateChange,
    ],
  );

  return <PumpStationScreenView {...pumpStationScreenViewProps} />;
};

export default PumpStationScreen;
