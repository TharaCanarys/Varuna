import React, {useCallback, useMemo} from 'react';
import {View, StyleSheet, RefreshControl, FlatList, ScrollView, ViewStyle, TextStyle} from 'react-native';
import {Card, IconButton} from 'react-native-paper';

import FwButtonPrimary from '../../elements/FwButtonPrimary';
import FwTextPrimary from '../../elements/FwTextPrimary';
import FwTextSecondary from '../../elements/FwTextSecondary';
import {PumpOperationScreenProps} from '../../types/commonTypes';
import {LanguageString, width} from '../../constants/data';
import {COLORS} from '../../constants/colors';
import PageHeader from '../../components/PageHeader';
import {PAGES} from '../../components/pages';
import {commonStyle} from '../../constants/theme';
import {normalized} from '../../constants/platform';
import FwModal from '../../elements/FwModal';

const PumpOperationScreenView = ({
  refreshing,
  pumpStations,
  onRefresh,
  openPumpStationDetails,
  selectedPumpStation,
  closePumpStationDetails,
}: PumpOperationScreenProps) => {
  const [isEditing] = React.useState(false);
  const renderPumpStationCard = useCallback(
    ({item: pumpStation, index}: {item: any; index: number}) => (
      <Card
        key={index}
        style={styles.pumpStationCard}
        onPress={() => openPumpStationDetails(pumpStation)}>
        <Card.Title
          title={LanguageString(pumpStation?.PumpHouseName)}
          titleStyle={commonStyle.cardHeaderText}
          left={props => (
            <IconButton
              {...props}
              style={{
                marginTop: normalized(60),
                paddingRight: normalized(20),
              }}
              icon="access-point"
            />
          )}
        />
        <Card.Content style={styles.cardContent}>
          <View style={commonStyle.modalRow}>
            <FwTextPrimary style={commonStyle.boldText}>
              {LanguageString('Location') + ' : '}
            </FwTextPrimary>
            <FwTextPrimary style={commonStyle.normalText}>
              {LanguageString(pumpStation?.locationName)}
            </FwTextPrimary>
          </View>
          <View style={commonStyle.modalRow}>
            <FwTextPrimary style={commonStyle.boldText}>
              {LanguageString('Station Id') + ' : '}
            </FwTextPrimary>
            <FwTextPrimary style={commonStyle.normalText}>
              {LanguageString(pumpStation?.stationId)}
            </FwTextPrimary>
          </View>
        </Card.Content>
      </Card>
    ),
    [openPumpStationDetails],
  );

  const ListEmptyComponent = useCallback(
    () => (
      <FwTextPrimary style={styles.noPumpStationsText}>
        {LanguageString('No pumpStations found')}
      </FwTextPrimary>
    ),
    [],
  );

  const renderPumpStationDetails = useCallback(
    () => (
      <>
        <View style={commonStyle.modalHeader}>
          <FwTextSecondary style={commonStyle.modalTitle}>
            {LanguageString('Pump Station Details')}
          </FwTextSecondary>
        </View>
        <ScrollView>
          {selectedPumpStation && (
            <>
              <View style={styles.detailRow}>
                <FwTextPrimary style={styles.detailLabel}>
                  {LanguageString('Pump ID')}:
                </FwTextPrimary>
                <FwTextPrimary style={styles.detailValue}>
                  {selectedPumpStation?.pumpId || 'N/A'}
                </FwTextPrimary>
              </View>

              <View style={styles.detailRow}>
                <FwTextPrimary style={styles.detailLabel}>
                  {LanguageString('Location')}:
                </FwTextPrimary>
                <FwTextPrimary style={styles.detailValue}>
                  {selectedPumpStation?.locationName || 'N/A'}
                </FwTextPrimary>
              </View>

              <View style={styles.detailRow}>
                <FwTextPrimary style={styles.detailLabel}>
                  {LanguageString('Station ID')}:
                </FwTextPrimary>
                <FwTextPrimary style={styles.detailValue}>
                  {selectedPumpStation?.stationId || 'N/A'}
                </FwTextPrimary>
              </View>

              <View style={styles.detailRow}>
                <FwTextPrimary style={styles.detailLabel}>
                  {LanguageString('Pump Type')}:
                </FwTextPrimary>
                <FwTextPrimary style={styles.detailValue}>
                  {selectedPumpStation?.pumpTypeName || 'N/A'}
                </FwTextPrimary>
              </View>

              <View style={styles.detailRow}>
                <FwTextPrimary style={styles.detailLabel}>
                  {LanguageString('Fuel Type')}:
                </FwTextPrimary>
                <FwTextPrimary style={styles.detailValue}>
                  {selectedPumpStation?.fuelTypeName || 'N/A'}
                </FwTextPrimary>
              </View>

              <View style={styles.detailRow}>
                <FwTextPrimary style={styles.detailLabel}>
                  {LanguageString('Rated Power')}:
                </FwTextPrimary>
                <FwTextPrimary style={styles.detailValue}>
                  {selectedPumpStation?.ratedPower ? `${selectedPumpStation.ratedPower} kW` : 'N/A'}
                </FwTextPrimary>
              </View>

              <View style={styles.detailRow}>
                <FwTextPrimary style={styles.detailLabel}>
                  {LanguageString('Energy Consumed')}:
                </FwTextPrimary>
                <FwTextPrimary style={styles.detailValue}>
                  {selectedPumpStation?.energyUnitsConsumed ? `${selectedPumpStation.energyUnitsConsumed} units` : 'N/A'}
                </FwTextPrimary>
              </View>

              <View style={styles.detailRow}>
                <FwTextPrimary style={styles.detailLabel}>
                  {LanguageString('Pump On Time')}:
                </FwTextPrimary>
                <FwTextPrimary style={styles.detailValue}>
                  {selectedPumpStation?.pumpOnTimeHours || selectedPumpStation?.pumpOnTimeMinutes 
                    ? `${selectedPumpStation.pumpOnTimeHours || 0}h ${selectedPumpStation.pumpOnTimeMinutes || 0}m` 
                    : 'N/A'}
                </FwTextPrimary>
              </View>

              <View style={styles.detailRow}>
                <FwTextPrimary style={styles.detailLabel}>
                  {LanguageString('Total Pump On Time')}:
                </FwTextPrimary>
                <FwTextPrimary style={styles.detailValue}>
                  {selectedPumpStation?.pumpOnTimeTotalHours || selectedPumpStation?.pumpOnTimeTotalMinutes 
                    ? `${selectedPumpStation.pumpOnTimeTotalHours || 0}h ${selectedPumpStation.pumpOnTimeTotalMinutes || 0}m` 
                    : 'N/A'}
                </FwTextPrimary>
              </View>
            </>
          )}
          <FwButtonPrimary
            onPress={closePumpStationDetails}
            style={styles.closeButton}>
            <FwTextSecondary>{LanguageString('Cancel')}</FwTextSecondary>
          </FwButtonPrimary>
        </ScrollView>
      </>
    ),
    [selectedPumpStation, closePumpStationDetails],
  );

  const styles = useMemo(
    () =>
      StyleSheet.create({
        container: {
          flex: 1,
          padding: normalized(16),
          backgroundColor: COLORS.OFF_WHITE,
        },
        pumpStationCard: {
          marginBottom: normalized(16),
          elevation: 2,
          backgroundColor: COLORS.BG_WHITE,
        },
        addButtonContainer: {
          marginVertical: normalized(24),
          alignItems: 'center',
        },
        addButton: {
          width: '100%',
          maxWidth: 200,
        },
        listContent: {
          paddingBottom: normalized(16),
        },
        noPumpStationsContainer: {
          flex: 1,
          justifyContent: 'center',
          alignItems: 'center',
          padding: normalized(20),
        },
        noPumpStationsText: {
          textAlign: 'center',
          color: COLORS.DARKGRAY,
          fontSize: normalized(16),
          marginTop: normalized(10),
        },
        cardContent: {
          padding: normalized(8),
        },
        detailRow: {
          flexDirection: 'row',
          justifyContent: 'space-between',
          paddingVertical: normalized(12),
          paddingHorizontal: normalized(16),
          borderBottomWidth: 1,
          borderBottomColor: COLORS.LIGHTGRAY,
        },
        detailLabel: {
          flex: 1,
          fontFamily: '600',
          color: COLORS.DARKGRAY,
          fontSize: normalized(15),
        },
        detailValue: {
          flex: 1.5,
          textAlign: 'right',
          color: COLORS.BLACK,
          fontSize: normalized(15),
          fontWeight: '500',
        },
        modalContainer: {
          backgroundColor: COLORS.BG_WHITE,
          margin: normalized(16),
          borderRadius: 12,
          maxHeight: '85%',
          padding: 0,
          overflow: 'hidden',
          elevation: 4,
        },
        modalHeader: {
          padding: normalized(16),
          borderBottomWidth: 1,
          borderBottomColor: COLORS.LIGHTGRAY,
          backgroundColor: COLORS.PRIMARY,
        },
        modalTitle: {
          fontSize: normalized(18),
          fontWeight: '600',
          color: COLORS.BG_WHITE,
          textAlign: 'center',
        },
        closeButton: {
          margin: normalized(16),
          backgroundColor: COLORS.PRIMARY,
          borderRadius: 8,
        },
        cardActions: {
          flexDirection: 'row',
          justifyContent: 'flex-end',
          padding: normalized(8),
        },
        appBar: {
          backgroundColor: COLORS.PRIMARY,
        },
      }),
    [],
  );

  return (
    <>
      <PageHeader title={PAGES.PUMPSTATION} />
      <FlatList
        style={styles.container}
        data={pumpStations}
        renderItem={renderPumpStationCard}
        keyExtractor={(item, index) => index.toString()}
        ListEmptyComponent={ListEmptyComponent}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
        }
      />

      <FwModal
        visible={selectedPumpStation !== null}
        onDismiss={closePumpStationDetails}
        contentContainerStyle={styles.modalContainer}>
        {selectedPumpStation && renderPumpStationDetails()}
      </FwModal>
    </>
  );
};

interface Styles {
  container: ViewStyle;
  pumpStationCard: ViewStyle;
  addButtonContainer: ViewStyle;
  addButton: ViewStyle;
  listContent: ViewStyle;
  noPumpStationsContainer: ViewStyle;
  noPumpStationsText: TextStyle;
  detailRow: ViewStyle;
  detailLabel: TextStyle;
  detailValue: TextStyle;
  modalHeader: ViewStyle;
  modalTitle: TextStyle;
  closeButton: ViewStyle;
  modalContainer: ViewStyle;
  appBar: ViewStyle;
  cardActions: ViewStyle;
}



export default PumpOperationScreenView;
