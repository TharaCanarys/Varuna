import React, { useRef } from 'react';
import { View, StyleSheet, Dimensions, BackHandler } from 'react-native';
import { WebView } from 'react-native-webview';

const EquipmentsScreen: React.FC = () => {
  const webViewRef = useRef<WebView>(null);
  const hideNavbarScript = `
    document.querySelector('nav')?.remove();
    document.querySelector('.navbar')?.remove();
    document.querySelector('header')?.remove();
    document.querySelector('.logos-container').style.display = 'none';
    true;
  `;

  React.useEffect(() => {
    const backAction = () => {
      if (webViewRef.current) {
        webViewRef.current.goBack();
        return true;
      }
      return false;
    };

    const backHandler = BackHandler.addEventListener('hardwareBackPress', backAction);
    return () => backHandler.remove();
  }, []);

  return (
    <View style={styles.container}>
      <WebView
        ref={webViewRef}
        source={{ uri: 'https://ufews.com/Equipment' }}
        style={styles.webview}
        javaScriptEnabled
        domStorageEnabled
        startInLoadingState
        injectedJavaScript={hideNavbarScript}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  webview: {
    width: Dimensions.get('window').width,
    height: Dimensions.get('window').height,
  },
});

export default EquipmentsScreen;