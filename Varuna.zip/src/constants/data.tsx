// import translate from 'google-translate-api-x';
import translate from 'google-translate-api-x';
import i18n from '../language/i18n';
import {
  MaintenancePropTypes,
  SensorPropTypes,
  CityAdminPropTypes,
  CityCatchmentPropTypes,
  POIPropTypes,
  NotificationPropTypes,
  TaskTypes,
  Log,
  PumpStationPropTypes,
  TaskStatus,
} from '../types/commonTypes';
import {Dimensions} from 'react-native';
import {TranslatingData} from '../services/authService';

// export const BASE_URL_DSS_OPS = 'http://10.0.1.58:8080/api/';
export const BASE_URL_DSS_OPS = 'https://ufews.com:8080/api/';
// export const BASE_URL_HARDWARE = 'http://10.0.1.58:8082/api/';
export const BASE_URL_HARDWARE = 'https://ufews.com:8082/api/';
export const BASE_URL_VISUALISATIONS = 'https://ufews.com:8084/api/';
export const ALL_URLS = {
  VERIFY_EMAIL: 'Authmanagement/VerifyEmail',
  SIGN_IN: 'Authmanagement/Sign-In',
  CREATE_USER: 'UserManagement/Register',
  VERIFY_MOBILE:'Authmanagement/VerifyMobileNumber',
  VERIFY_OTP: 'UserManagement/VerifyMobileOTP',
  RESET_PASSWORD: 'Authmanagement/ResetPassword',
  GET_LOCATION: 'Location/GetLocations',
  GET_FORCAST: 'IMD/forecast',
  GET_NOWCAST: 'IMD/nowcast',
  UPLOAD_INCIDENT: 'IncidentService/AddIncident',
  GET_INCIDENTS: 'IncidentService/GetAllIncidents',
  // Dashboard Screen Urls
  GET_DASHBOARD_DATA: 'Dashboard/GetDashboardData',
  GET_FLOOD_INFORMATION: 'Dashboard/GetFloodInformation',
  
  // Sensor Screen Urls
  ADD_SENSOR: 'SensorCustomApi/AddSensors',
  GET_SENSOR: 'SensorCustomApi/GetSensors',
  UPDATE_SENSOR: 'SensorCustomApi/UpdateSensors',

  // Maintenance Screen Urls
  // ADD_MAINTENANCE: 'MaintenanceCustomApi/AddMaintenances',
  GET_MAINTENANCE: 'maintenance',
  GET_PUMP_OPERATIONS: 'PumpingStationApiClient/GetTodayLatestPumpedOutWaterByPump',
  // UPDATE_MAINTENANCE: 'MaintenanceCustomApi/UpdateMaintenances',

  // POI Screen Urls
  GET_POI: 'POI/GetPoi',
  GET_TASKS: 'tasks',
  GET_USERS: 'Authmanagement/GetAllUsersAsync',
  GET_ESCALATION: 'EscalationApi',
};

export const LanguageString = (value: string) => {
  return i18n.t(value);
};
export const {width} = Dimensions.get('window');
export const {height} = Dimensions.get('window');
export const TranslateString = async (value: string) => {
  if (value !== null) {
    try {
      const res = await translate(value, {
        from: 'en',
        to: 'hi',
        autoCorrect: true,
      });
      return res.text;
    } catch (error) {
      console.log(error);
      return value;
    }
  }
  return value;
}; // Dropdown options

export const PumpStationidOptions = [
  {label: '0', value: '0'},
  {label: '1', value: '1'},
  {label: '2', value: '2'},
];
export const maintenanceTypeOptions = [
  {label: LanguageString('Preventive'), value: 'Preventive'},
  {label: LanguageString('Corrective'), value: 'Corrective'},
  {label: LanguageString('Predictive'), value: 'Predictive'},
];

export const cityAdminTypeOptions = [
  {label: LanguageString('Preventive'), value: 'Preventive'},
  {label: LanguageString('Corrective'), value: 'Corrective'},
  {label: LanguageString('Predictive'), value: 'Predictive'},
];

export const cityAdminNameOptions = [
  {label: LanguageString('Downtown'), value: 'Downtown'},
  {label: LanguageString('Suburb'), value: 'Suburb'},
  {label: LanguageString('Rural'), value: 'Rural'},
  {label: LanguageString('Urban'), value: 'Urban'},
];

export const keyFacilityOptions = [
  {label: LanguageString('Hospital'), value: 'Hospital'},
  {label: LanguageString('School'), value: 'School'},
  {label: LanguageString('Police Station'), value: 'Police Station'},
  {label: LanguageString('Government Office'), value: 'Government Office'},
];

export const emergencyServiceOptions = [
  {label: LanguageString('Ambulance'), value: 'Ambulance'},
  {label: LanguageString('Fire Brigade'), value: 'Fire Brigade'},
  {label: LanguageString('Police Station'), value: 'Police Station'},
];
export const adminAreaTypeOptions = [
  {label: LanguageString('Preventive'), value: 'Preventive'},
  {label: LanguageString('Corrective'), value: 'Corrective'},
  {label: LanguageString('Predictive'), value: 'Predictive'},
];

export const floodRiskLevelOptions = [
  {label: LanguageString('Low'), value: 'Low'},
  {label: LanguageString('Medium'), value: 'Medium'},
  {label: LanguageString('High'), value: 'High'},
  {label: LanguageString('Critical'), value: 'Critical'},
];

export const runOfCoeffecientOptions = [
  {label: '0', value: '0'},
  {label: '1', value: '1'},
  {label: '2', value: '2'},
];

export const waterBodiesOptions = [
  {label: 'River', value: 'River'},
  {label: 'Lake', value: 'Lake'},
  {label: 'Pond', value: 'Pond'},
  {label: 'Canal', value: 'Canal'},
];

export const assetsTypeOptions = [
  {label: LanguageString('Pumping Station'), value: 'Pumping Station'},
  {label: LanguageString('Drainage'), value: 'Drainage'},
  {label: LanguageString('Water level sensor'), value: 'Water level sensor'},
];

export const severityOptions = [
  {label: 'High', value: 'High'},
  {label: 'Medium', value: 'Medium'},
  {label: 'Low', value: 'Low'},
];


export const pumpStationData: PumpStationPropTypes[] = [
  {
    id: 1,
    PumpStationid: 1,
    PumpHouseName: 'Lalbagh Pump House',
    Locationid: 20,
    inspectionDate: '2024-10-15',
    Elevation: 79.0486,
    PumpType: 'Centrifugal',
    PumpNumber: 3,
    RatedPower: 75,
    Location: 'Lalbagh',
    PipeDetails: 'Diameter: 600mm, Material: Steel, Length: 250 meters',
    PumpOperationRawData:
      'Operational from 10:00 AM to 4:00 PM, Flow rate: 3000 LPM, Pressure: 5.5 bar',
  },
  {
    id: 2,
    PumpStationid: 2,
    PumpHouseName: 'Kushmuli Pump House',
    Locationid: 22,
    inspectionDate: '2024-09-20',
    Elevation: 85.2003,
    PumpType: 'Submersible',
    PumpNumber: 5,
    RatedPower: 50,
    Location: 'Kushmuli',
    PipeDetails: 'Diameter: 450mm, Material: PVC, Length: 350 meters',
    PumpOperationRawData:
      'Operational from 8:00 AM to 6:00 PM, Flow rate: 2000 LPM, Pressure: 4.2 bar',
  },
  {
    id: 3,
    PumpStationid: 3,
    PumpHouseName: 'Maharajganj Pump House',
    Locationid: 25,
    inspectionDate: '2024-08-10',
    Elevation: 78.9351,
    PumpType: 'Centrifugal',
    PumpNumber: 4,
    RatedPower: 100,
    Location: 'Maharajganj',
    PipeDetails: 'Diameter: 700mm, Material: Cast Iron, Length: 500 meters',
    PumpOperationRawData:
      'Operational from 6:00 AM to 8:00 PM, Flow rate: 5000 LPM, Pressure: 6.0 bar',
  },
];
export const maintenanceData: MaintenancePropTypes[] = [
  {
    id: 1,
    status: 1,
    location: 'Rapti Nagar',
    locationID: 20,
    maintenanceType: 'Preventive',
    description: 'Test',
    scheduledDate: '2025-01-27T09:23:07.0259584',
    dueDate: '2025-01-28T00:00:00',
    completedDate: 'null',
    Technician: 'John Doe',
    Remarks: 'All systems are functioning normally',
    assetsType: 'Water level sensor',
    facilityType: 0,
    isActive: false,
    maintenanceID: 0,
    raisedByUserID: 0,
    remarks: null,
    technicianID: 0,
    type: 0
  },
  {
    id: 2,
    status: 'Maintenance',
    location: 'Om Nagar',
    maintenanceType: 'Corrective',
    description: 'Repairing water level sensor',
    scheduledDate: '2023-05-17 10:00',
    dueDate: '2023-05-17 12:00',
    completedDate: '',
    Technician: 'Jane Smith',
    Remarks: 'Water level sensor repaired successfully',
    assetsType: 'Water level sensor',
    facilityType: 0,
    isActive: false,
    locationID: 0,
    maintenanceID: 0,
    raisedByUserID: 0,
    remarks: null,
    technicianID: 0,
    type: 0
  },
  {
    id: 3,
    status: 'Inactive',
    location: 'Rasoolpur',
    maintenanceType: 'Predictive',
    description: 'Scheduled maintenance for rainfall sensor',
    scheduledDate: '2023-05-18 16:30',
    dueDate: '2023-05-18 18:30',
    completedDate: '',
    Technician: 'Mike Johnson',
    Remarks: 'All systems are functioning normally',
    assetsType: 'Rainfall sensor',
    facilityType: 0,
    isActive: false,
    locationID: 0,
    maintenanceID: 0,
    raisedByUserID: 0,
    remarks: null,
    technicianID: 0,
    type: 0
  },
];
export const cityAdminData: CityAdminPropTypes[] = [
  {
    id: 1,
    cityAdminAreaName: 'Downtown',
    cityAdminAreaType: 'Religious',
    location: 'Rapti Nagar',
    population: 10000,
    keyFacility: 'Hospital',
    floodRiskLevel: 'Moderate',
    contactPerson: 'Sachin',
    emergencyService: 'Ambulance',
    evolutionPlan:
      'Our Coordinators will check the site and try to resolve the issues faced by the people',
  },
  {
    id: 2,
    cityAdminAreaName: 'Suburb',
    cityAdminAreaType: 'Religious',
    location: 'Rapti Nagar',
    population: 10000,
    keyFacility: 'School',
    floodRiskLevel: 'Moderate',
    contactPerson: 'Sachin',
    emergencyService: 'Fire Brigade',
    evolutionPlan:
      'Our Coordinators will check the site and try to resolve the issues faced by the people',
  },
  {
    id: 3,
    cityAdminAreaName: 'Rural',
    cityAdminAreaType: 'Religious',
    location: 'Rapti Nagar',
    population: 10000,
    keyFacility: 'Hospital',
    floodRiskLevel: 'Moderate',
    contactPerson: 'Sachin',
    emergencyService: 'Ambulance',
    evolutionPlan:
      'Our Coordinators will check the site and try to resolve the issues faced by the people',
  },
];

export const cityCatchmentData: CityCatchmentPropTypes[] = [
  {
    id: 0,
    cityCatchmentAreaName: 'Gorakhpur Temple',
    location: 'Rapti Nagar',
    areaSize: '1500 sqft',
    waterBodies: 'River',
    runOfCoeffecient: '2',
    avgRainfall: '1200 mm',
    drainageCapacity: 'Rainfall Intensity',
    floodRiskLevel: 'High',
  },
  {
    id: 1,
    cityCatchmentAreaName: 'Gorakhpur Temple',
    location: 'Rapti Nagar',
    areaSize: '1500 sqft',
    waterBodies: 'River',
    runOfCoeffecient: '2',
    avgRainfall: '1200 mm',
    drainageCapacity: 'Rainfall Intensity',
    floodRiskLevel: 'High',
  },
  {
    id: 2,
    cityCatchmentAreaName: 'Gorakhpur Temple',
    location: 'Rapti Nagar',
    areaSize: '1500 sqft',
    waterBodies: 'River',
    runOfCoeffecient: '2',
    avgRainfall: '1200 mm',
    drainageCapacity: 'Rainfall Intensity',
    floodRiskLevel: 'High',
  },
];

export const poiData: POIPropTypes[] = [
  {
    id: 1,
    location: 'Rasoolpur',
    poiName: 'Buddha Park',
    //poiType: 'Preventive',
    elevation: 'Low',
    network: 'Religious',
    poiStatus: 'Resolved',
    floodRiskLevel: 'Medium',
    adjescentPois: 'Shopping Areas',
  },
  {
    id: 2,
    location: 'Lalbagh',
    poiName: 'Buddha Park',
    //poiType: 'Preventive',
    elevation: 'Low',
    network: 'Religious',
    poiStatus: 'Active',
    floodRiskLevel: 'Medium',
    adjescentPois: 'Shopping Areas',
  },
  {
    id: 3,
    location: 'Rapti Nagar',
    poiName: 'Buddha Park',
    //poiType: 'Preventive',
    elevation: 'Low',
    network: 'Religious',
    poiStatus: 'Active',
    floodRiskLevel: 'Medium',
    adjescentPois: 'Shopping Areas',
  },
];

export const notificationData: NotificationPropTypes[] = [
  {
    id: 1,
    name: 'Heavy Rainfall Alert',
    sentTime: '2023-05-14 15:45',
    channel: 'Email',
    deliveryStatus: 'Delivered',
    message:
      'Heavy rainfall expected in Gorakhpur from 12 PM to 6 PM today. Risk of waterlogging in low-lying areas. Stay safe and avoid unnecessary travel.',
  },
  {
    id: 2,
    name: 'Water Level Rising',
    sentTime: '2023-05-14 15:45',
    channel: 'SMS',
    deliveryStatus: 'Delivered',
    message:
      'Water level of Rapti River is rising steadily due to continuous rainfall. Residents near riverbanks should remain alert and be ready for possible evacuation.',
  },
];

export const USER_ROLES = {
  USER: 'User',
  CAL: 'CAL',
  ADMIN: 'Admin',
  MC: 'MC',
  AMC: 'AMC',
  GM: 'GM',
  AE: 'AE',
  CI: 'CI',
  ZO: 'ZO',
  CLSS: 'CLSS',
  CSFI: 'CSFI',
  JE: 'JE',
  JEC: 'JEC',
  SI: 'SI',
  SS: 'SS',
  ZSO: 'ZSO',
  AEC: 'AEC',
  CE: 'CE',
  ExEn: 'ExEn',
  NSA: 'NSA',
  COUNCILLOR: 'Councillor',
  TECHNICIAN: 'Technician'
};

export const taskData: TaskTypes[] = [
  {
    taskID: '21',
    description: 'Resolve: Drain Block near Dmart',
    assignedToUserID: '1',
    createdByUserID: '1',
    status: TaskStatus.ESCALATED,
    creationDate: '2025-05-14T11:02:00.728189',
    manualIncidentEntryId: '250',
    taskHistory: [
      {
        id: 1,
        changedDate: '2025-05-14T11:02:00.728189',
        changedBy: 'Admin',
        oldStatus: '',
        newStatus: 'Escalated',
        comments: 'Task created and escalated',
      },
    ],
  },
  {
    taskID: '3',
    description: 'Task 3 description',
    assignedToUserID: '1',
    createdByUserID: '1',
    status: TaskStatus.IN_PROGRESS,
    creationDate: '2024-11-13T11:30:00',
    manualIncidentEntryId: '3',
    taskHistory: [
      {
        id: 1,
        changedDate: '2023-05-12T14:30:00',
        changedBy: 'Admin',
        oldStatus: '',
        newStatus: 'Open',
        comments: 'Task created',
      },
      {
        id: 2,
        changedDate: '2023-05-13T09:15:00',
        changedBy: 'Amit Patel',
        oldStatus: 'Open',
        newStatus: 'In progress',
        comments: 'Started working on the task',
      },
    ],
  },
];

export const logsData: Log[] = [
  {
    logId: 'LOG001',
    loggedTime: '2023-07-20 10:30',
    severity: 'Low',
    category: 'Telemetry',
    initiator: 'System',
    status: 'Success',
    correlationId: '20249878',
    message: 'Data synchronization completed successfully',
    details:
      'Successfully synchronized data with remote server. Total records: 150',
  },
  {
    logId: 'LOG002',
    loggedTime: '2023-07-20 09:15',
    status: 'Failed',
    severity: 'High',
    category: 'Cloud Operations',
    initiator: 'User',
    correlationId: '20249879',
    message: 'Authentication failure',
    details: 'Authentication failed due to invallogId credentials',
  },
  {
    logId: 'LOG003',
    loggedTime: '2023-07-20 11:45',
    severity: 'Medium',
    category: 'Security',
    initiator: 'System',
    status: 'Success',
    correlationId: '20249880',
    message: 'Firewall rules updated',
    details: 'Security policies successfully updated across all endpoints',
  },
  {
    logId: 'LOG004',
    loggedTime: '2023-07-20 12:20',
    severity: 'Critical',
    category: 'Database',
    initiator: 'System',
    status: 'Failed',
    correlationId: '20249881',
    message: 'Database backup failed',
    details: 'Critical error during scheduled database backup process',
  },
  {
    logId: 'LOG005',
    loggedTime: '2023-07-20 13:10',
    severity: 'Info',
    category: 'Maintenance',
    initiator: 'Admin',
    status: 'Success',
    correlationId: '20249882',
    message: 'System maintenance completed',
    details: 'Routine system maintenance tasks executed successfully',
  },
  {
    logId: 'LOG006',
    loggedTime: '2023-07-20 14:25',
    severity: 'High',
    category: 'Network',
    initiator: 'System',
    status: 'Failed',
    correlationId: '20249883',
    message: 'Network connectivity issue',
    details: 'Lost connection to primary network switch in Data Center A',
  },
  {
    logId: 'LOG007',
    loggedTime: '2023-07-20 15:40',
    severity: 'Low',
    category: 'Application',
    initiator: 'User',
    status: 'Success',
    correlationId: '20249884',
    message: 'Configuration updated',
    details: 'User preferences successfully updated in application settings',
  },
  {
    logId: 'LOG008',
    loggedTime: '2023-07-20 16:55',
    severity: 'Medium',
    category: 'Storage',
    initiator: 'System',
    status: 'Success',
    correlationId: '20249885',
    message: 'Storage optimization complete',
    details: 'Successfully cleaned up 500GB of temporary files',
  },
  {
    logId: 'LOG009',
    loggedTime: '2023-07-20 17:30',
    severity: 'Critical',
    category: 'Security',
    initiator: 'System',
    status: 'Failed',
    correlationId: '20249886',
    message: 'Unauthorized access attempt',
    details: 'Multiple failed login attempts detected from suspicious IP',
  },
  {
    logId: 'LOG010',
    loggedTime: '2023-07-20 18:15',
    severity: 'Info',
    category: 'Performance',
    initiator: 'Admin',
    status: 'Success',
    correlationId: '20249887',
    message: 'Performance optimization',
    details: 'System performance optimization completed successfully',
  },
  {
    logId: 'LOG011',
    loggedTime: '2023-07-20 19:05',
    severity: 'High',
    category: 'API',
    initiator: 'System',
    status: 'Failed',
    correlationId: '20249888',
    message: 'API endpoint failure',
    details: 'External API integration failed due to timeout',
  },
  {
    logId: 'LOG012',
    loggedTime: '2023-07-20 20:20',
    severity: 'Medium',
    category: 'User Management',
    initiator: 'Admin',
    status: 'Success',
    correlationId: '20249889',
    message: 'User roles updated',
    details: 'Batch update of user permissions completed successfully',
  },
];

export const setIndianTime = (date: Date) => {
  return date.toLocaleString('en-US', {
    timeZone: 'Asia/Kolkata',
  });
};

export const HomedummyData = {
  rainfallData: {
    rainfall24h: '30 mm',
    poiAffected: '76',
    riskZones: '3',
  },
  zoneData: {
    total: '80',
    noRisk: '40',
    highRisk: '3',
    mediumRisk: '9',
    lowRisk: '28',
  },
  sensorData: {
    waterLevel: '5.4 m',
    radarDetection: 'Flood Wave',
    flowRate: '700 m³/s',
  },
  floodDetails: {
    areasAffected: 'Ward 8, Ward 72',
    livesImpacted: {
      humans: '100',
      animals: '300',
    },
    drainsAffected: '11',
    injured: '15',
    lifeCasualties: {
      humans: '0',
      animals: '5',
    },
    sumpWellsAffected: '4',
    revenueLoss: '₹12,00,000',
    reliefFunds: '₹20,00,000',
  },
};
