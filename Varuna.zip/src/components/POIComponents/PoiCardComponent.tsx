import React, {useCallback, useMemo} from 'react';
import {View} from 'react-native';
import {Card, IconButton} from 'react-native-paper';
import {LanguageString} from '../../constants/data';
import {commonStyle} from '../../constants/theme';
import {ICONS} from '../../assets';
import FwImage from '../../elements/FwImage';
import {FwTextPrimary} from '../../elements';

const PoiCardComponent = ({
  index,
  styles,
  openPOIDetails,
  poi,
  validateRole,
  startEditingStatus,
  openDeleteDialog,
}: any) => {
  return (
    <Card
      key={index}
      style={styles.poiCard}
      onPress={() => openPOIDetails(poi)}>
      <Card.Title
        title={LanguageString('POI') + ' ' + LanguageString(poi.id)}
        titleStyle={commonStyle.cardHeaderText}
        left={() => (
          <View style={styles.cardImage}>
            <FwImage source={ICONS.POINTER} style={styles.cardImageIcon} />
          </View>
        )}
        right={props =>
          validateRole ? (
            <View style={styles.cardActions}>
              <IconButton
                {...props}
                icon="pencil"
                onPress={() => {
                  openPOIDetails(poi);
                  startEditingStatus();
                }}
                disabled={poi.poiStatus === 'Resolved'}
              />
              <IconButton
                {...props}
                icon="delete"
                onPress={() => openDeleteDialog(poi)}
              />
            </View>
          ) : null
        }
      />
      <Card.Content style={styles.cardContent}>
        <View style={commonStyle.modalRow}>
          <FwTextPrimary style={commonStyle.boldText}>
            {LanguageString('Location') + ' : '}
          </FwTextPrimary>
          <FwTextPrimary style={commonStyle.normalText}>
            {LanguageString(poi.location)}
          </FwTextPrimary>
        </View>
        <View style={commonStyle.modalRow}>
          <FwTextPrimary style={commonStyle.boldText}>
            {LanguageString('Status') + ' : '}
          </FwTextPrimary>
          <FwTextPrimary style={commonStyle.normalText}>
            {/* {LanguageString(
              poi.status == 0
                ? 'Active'
                : poi.status == 1
                ? 'Inactive'
                : poi.status == 2
                ? 'Maintenance'
                : 'Status Not found',
            )} */}
            {LanguageString(poi.poiStatus)}
          </FwTextPrimary>
        </View>
        <View style={commonStyle.modalRow}>
          <FwTextPrimary style={commonStyle.boldText}>
            {LanguageString('Flood Risk Level') + ' : '}
          </FwTextPrimary>
          <FwTextPrimary style={commonStyle.normalText}>
            {LanguageString(poi.floodRiskLevel)}
            {/* {LanguageString(
              poi.riskLevel == 0
                ? 'Low'
                : poi.riskLevel == 1
                ? 'Medium'
                : poi.riskLevel == 2
                ? 'High'
                : poi.riskLevel == 3
                ? 'Critical'
                : 'Not found',
            )} */}
          </FwTextPrimary>
        </View>
      </Card.Content>
    </Card>
  );
};

export default PoiCardComponent;
