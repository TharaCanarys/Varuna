import {createSlice, PayloadAction} from '@reduxjs/toolkit';
import {USER_ROLES} from '../constants/data';

interface AuthState {
  token: string | null;
  userId: string | null;
  userRole: string | null;
  userName: string | null;
  validatedRole: boolean;
  task: any;
}

const initialState: AuthState = {
  token: null,
  userId: null,
  userRole: null,
  userName: null,
  validatedRole: false,
  task: null,
};

const authSlice = createSlice({
  name: 'auth',
  initialState,
  reducers: {
    setToken(state, action: PayloadAction<string | null>) {
      state.token = action.payload;
    },
    clearToken(state) {
      state.token = null;
    },
    setUserDetails(
      state,
      action: PayloadAction<{id: string; role: string; userName: string}>,
    ) {
      state.userId = action.payload.id;
      state.userRole = action.payload.role;
      state.userName = action.payload.userName;
    },
    checkRole(state, action: PayloadAction<boolean>) {
      const role = state.userRole;
      console.log('Current Role:', role);
      state.validatedRole =
        role == USER_ROLES.ADMIN ||
        role == USER_ROLES.SUPER_ADMIN ||
        role == USER_ROLES.IT_SUPPORT ||
        role == USER_ROLES.USER;
    },
    setTaskHistory(state, action: PayloadAction<{task: any}>) {
      state.task = action.payload;
    },
    clearUserDetails(state) {
      state.userId = null;
      state.userRole = null;
    },
  },
});

export const {
  setToken,
  clearToken,
  setUserDetails,
  clearUserDetails,
  setTaskHistory,
} = authSlice.actions;
export default authSlice.reducer;
