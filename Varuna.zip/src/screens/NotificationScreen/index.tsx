import React, {useCallback, useState, useMemo} from 'react';
import {NotificationPropTypes} from '../../types/commonTypes';
import {notificationData} from '../../constants/data';
import NotificationScreenView from './NotificationScreenView';

const NotificationScreen: React.FC = () => {
  const [currentNotification, setCurrentNotification] =
    useState<NotificationPropTypes | null>(null);
  const [editingStatus, setEditingStatus] = useState(false);
  const [newStatus, setNewStatus] = useState('');
  const [notifications, setNotifications] =
    useState<NotificationPropTypes[]>(notificationData);
  const [isAddingNewNotification, setIsAddingNewNotification] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  // Simulate data refresh
  const onRefresh = useCallback(() => {
    setRefreshing(true);
    setTimeout(() => {
      // setNotifications([...notificationData]);
      setRefreshing(false);
    }, 1000);
  }, []);

  // Open notification details modal
  const openNotificationDetails = useCallback(
    (notification: NotificationPropTypes) => {
      setCurrentNotification(notification);
    },
    [],
  );

  // Close notification details modal
  const closeNotificationDetails = useCallback(() => {
    setCurrentNotification(null);
    setEditingStatus(false);
  }, []);

  // Toggle status editing
  const startEditingStatus = useCallback(() => {
    setEditingStatus(prev => !prev);
  }, []);

  // Memoize the props for NotificationScreenView to prevent unnecessary re-renders
  const notificationScreenViewProps = useMemo(
    () => ({
      currentNotification,
      editingStatus,
      newStatus,
      notifications,
      isAddingNewNotification,
      setIsAddingNewNotification,
      setNewStatus,
      refreshing,
      onRefresh,
      openNotificationDetails,
      closeNotificationDetails,
      startEditingStatus,
    }),
    [
      currentNotification,
      editingStatus,
      newStatus,
      notifications,
      setIsAddingNewNotification,
      isAddingNewNotification,
      refreshing,
      onRefresh,
      openNotificationDetails,
      closeNotificationDetails,
      startEditingStatus,
    ],
  );

  return <NotificationScreenView {...notificationScreenViewProps} />;
};
export default NotificationScreen;
