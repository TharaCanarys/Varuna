import React, {useRef} from 'react';
import {View, StyleSheet, Dimensions} from 'react-native';
import {WebView} from 'react-native-webview';

const Charts: React.FC = () => {
  const webViewRef = useRef<WebView | null>(null); // Reference for WebView

  // Updated script to hide only navigation elements and not interfere with charts
  const hideNavbarScript = `
    document.querySelector('nav')?.remove();
    document.querySelector('.navbar')?.remove();
    document.querySelector('header')?.remove();
    document.querySelector('.logos-container').style.display = 'none';
    true;
  `;

  // Handle load completion to inject the script (if necessary)
  const onLoadEnd = () => {
    if (webViewRef.current) {
      webViewRef.current.injectJavaScript(hideNavbarScript); // Inject JS after the page loads
    }
  };

  return (
    <View style={styles.container}>
      <WebView
        ref={webViewRef} // Reference to the WebView
        source={{uri: 'https://ufews.com:8085/Home/Charts'}}
        style={styles.webview}
        javaScriptEnabled={true}
        domStorageEnabled={true}
        startInLoadingState={true}
        injectedJavaScript={hideNavbarScript} // Inject the JavaScript immediately
        onLoadEnd={onLoadEnd} // Optional if you want more control over when the JS is injected
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  webview: {
    width: Dimensions.get('window').width,
    height: Dimensions.get('window').height,
  },
});

export default Charts;
