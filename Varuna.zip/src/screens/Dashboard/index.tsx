import React, {useCallback, useEffect, useState} from 'react';
import DashboardView from './DashboardScreenView';
import notifee, {AuthorizationStatus} from '@notifee/react-native';
import {fetchLocations, getDashboardData} from '../../services/apiServices';
import {Location} from '../HomeScreen/GuestView';
import {useDispatch} from 'react-redux';
import {saveLocation, saveDashboardData} from '../../store/appSlice';

async function requestNotificationPermission() {
  try {
    const settings = await notifee.getNotificationSettings();

    if (settings.authorizationStatus === AuthorizationStatus.DENIED) {
      await notifee.requestPermission({
        alert: true,
        badge: true,
        sound: true,
        announcement: true,
      });

      const newSettings = await notifee.getNotificationSettings();

      if (newSettings.authorizationStatus === AuthorizationStatus.DENIED) {
        await notifee.openNotificationSettings();
        const finalSettings = await notifee.getNotificationSettings();
        if (
          finalSettings.authorizationStatus === AuthorizationStatus.AUTHORIZED
        ) {
        } else {
          console.log('Notification permissions still denied.');
        }
      }
    } else {
      await notifee.requestPermission({
        alert: true,
        badge: true,
        sound: true,
        announcement: true,
      });

      const newSettings = await notifee.getNotificationSettings();
      if (newSettings.authorizationStatus === AuthorizationStatus.AUTHORIZED) {
      } else if (
        newSettings.authorizationStatus === AuthorizationStatus.DENIED
      ) {
        await notifee.openNotificationSettings();
      } else if (
        newSettings.authorizationStatus === AuthorizationStatus.PROVISIONAL
      ) {
      }
    }
  } catch (error) {
    console.log('Error requesting notification permission:', error);
  }
}

const DashboardScreen: React.FC = () => {
  const dispatch = useDispatch();
  // const [data, setData] = useState<any>();
  const [isLoading, setLoading] = useState(false);

  const onFetchLocations = useCallback((data: Location[]) => {
    dispatch(saveLocation(data));
  }, [dispatch]);

  const onLocationFailed = useCallback((data: Location[]) => {
    console.log('Location data Fetching Failed', data);
  }, []);

  const onGetFailed = useCallback((error: any) => {
    setLoading(false);
    console.log('Failed to get data', error);
  }, []);

  const onGetSuccess = useCallback(
    (data: any) => {
      dispatch(saveDashboardData(data));
      // console.log('Dashboard data', data);
    },
    [dispatch],
  );

  useEffect(() => {
    requestNotificationPermission();
    // fetchLocations({onFetchLocations, onLocationFailed});
  }, [onFetchLocations, onLocationFailed]);

  useEffect(() => {
    const payload = [0];
    getDashboardData(payload, setLoading, onGetSuccess, onGetFailed);
  }, [onGetSuccess, onGetFailed]);

  return <DashboardView isLoading={isLoading} />;
};

export default DashboardScreen;
