import React from 'react';
import {ViewStyle, Animated} from 'react-native';

import {Modal, Portal} from 'react-native-paper';

interface FwModalProps {
  children: React.ReactNode;
  contentContainerStyle?: ViewStyle;
  onDismiss?: () => void;
  visible: boolean;
  [key: string]: any;
}

export default function FwModal({
  children,
  contentContainerStyle,
  onDismiss,
  visible,
  ...props
}: FwModalProps) {
  const translateY = React.useRef(new Animated.Value(0)).current;
  const opacity = React.useRef(new Animated.Value(0)).current;

  React.useEffect(() => {
    if (visible) {
      Animated.parallel([
        Animated.timing(translateY, {
          toValue: 0,
          duration: 300,
          useNativeDriver: true,
        }),
        Animated.timing(opacity, {
          toValue: 1,
          duration: 300,
          useNativeDriver: true,
        }),
      ]).start();
    } else {
      translateY.setValue(-50);
      opacity.setValue(0);
    }
  }, [visible]);

  const handleDismiss = () => {
    Animated.parallel([
      Animated.timing(translateY, {
        toValue: -50,
        duration: 300,
        useNativeDriver: true,
      }),
      Animated.timing(opacity, {
        toValue: 0,
        duration: 300,
        useNativeDriver: true,
      }),
    ]).start(() => {
      if (onDismiss) {
        onDismiss();
      }
    });
  };

  return (
    <Portal>
      <Modal
        visible={visible}
        onDismiss={handleDismiss}
        contentContainerStyle={[
          contentContainerStyle,
          {
            transform: [{translateY: translateY}],
            opacity: opacity,
          },
        ]}
        {...props}>
        {children}
      </Modal>
    </Portal>
  );
}
