import React from 'react';
import {Card, Paragraph} from 'react-native-paper';
import {View} from 'react-native';
import {ICONS} from '../../assets';
import {COLORS} from '../../constants/colors';
import {LanguageString} from '../../constants/data';
import {StyleSheet} from 'react-native';
import {commonStyle} from '../../constants/theme';
import {normalized} from '../../constants/platform';

const Drains = ({data, renderIcon}: {data: any; renderIcon: any}) => {
  const drainsData = [
    {
      value: 13,
      label: 'MajorDrains'
    },
    {
      value: 117,
      label: 'MediumDrains'
    },
    {
      value: 127,
      label: 'SmallerDrains'
    }
  ];

  return (
    <>
      <Card style={commonStyle.card}>
        <Card.Content>
          <View style={commonStyle.cardContainer}>
            {drainsData.map((drain, index) => (
              <View key={index} style={commonStyle.metric}>
                {renderIcon(ICONS.DRAIN, COLORS.PRIMARY)}
                <Paragraph style={commonStyle.metricTitle}>
                  {drain.value}
                </Paragraph>
                <Paragraph style={commonStyle.metricValue}>
                  {LanguageString(drain.label)}
                </Paragraph>
              </View>
            ))}
          </View>
        </Card.Content>
      </Card>
    </>
  );
};
export default Drains;
