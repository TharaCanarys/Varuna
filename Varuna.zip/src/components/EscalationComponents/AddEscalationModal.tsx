import React from 'react';
import {View, StyleSheet} from 'react-native';
import {HelperText} from 'react-native-paper';
import {FwButtonPrimary, FwTextPrimary, FwTextSecondary} from '../../elements';
import {LanguageString} from '../../constants/data';
import FWDropdown from '../../elements/FwDropdown';
import DateTimePickerModal from 'react-native-modal-datetime-picker';
import {normalized} from '../../constants/platform';
import {COLORS} from '../../constants/colors';
import {commonStyle} from '../../constants/theme';
import FwModal from '../../elements/FwModal';
const AddEscalationModal = ({
  isAddingNewEscalation,
  closeAddNewEscalation,
  newEscalation,
  setNewEscalation,
  errors,
  isDatePickerVisible,
  handleConfirm,
  hideDatePicker,
  handleAddNewEscalation,
}: any) => {
  const statusOptions = [
    {label: LanguageString('Pending'), value: 'Pending'},
    {label: LanguageString('In progress'), value: 'In progress'},
    {label: LanguageString('Closed'), value: 'Closed'},
  ];
  const escalationNameOptions = [
    {label: LanguageString('Task') + ' ' + 1, value: 'Task 1'},
    {label: LanguageString('Task') + ' ' + 2, value: 'Task 2'},
    {label: LanguageString('Task') + ' ' + 3, value: 'Task 3'},
    {label: LanguageString('Maintenance') + ' ' + 1, value: 'Maintenance 1'},
    {label: LanguageString('Maintenance') + ' ' + 2, value: 'Maintenance 2'},
    {label: LanguageString('Maintenance') + ' ' + 3, value: 'Maintenance 3'},
    {label: LanguageString('Support') + ' ' + 1, value: 'Support 1'},
    {label: LanguageString('Support') + ' ' + 2, value: 'Support 2'},
    {label: LanguageString('Support') + ' ' + 3, value: 'Support 3'},
  ];
  const escalationLevelOptions = [
    {label: LanguageString('Level') + ' ' + 1, value: 'Level 1'},
    {label: LanguageString('Level') + ' ' + 2, value: 'Level 2'},
    {label: LanguageString('Level') + ' ' + 3, value: 'Level 3'},
    {label: LanguageString('Level') + ' ' + 4, value: 'Level 4'},
  ];
  const escalationTypeOptions = [
    {label: LanguageString('Support'), value: 'Support'},
    {label: LanguageString('Maintenance'), value: 'Maintenance'},
    {label: LanguageString('Task'), value: 'Task'},
  ];
  return (
    <FwModal
      visible={isAddingNewEscalation}
      onDismiss={closeAddNewEscalation}
      contentContainerStyle={styles.modalContainer}>
      <View style={commonStyle.modalHeader}>
        <FwTextPrimary style={commonStyle.modalTitle}>
          {LanguageString('Add New Escalation')}
        </FwTextPrimary>
      </View>
      <FWDropdown
        multiple={false}
        label={LanguageString('Select Escalation Name')}
        options={escalationNameOptions}
        value={newEscalation.escalationName}
        onSelect={(value: string | undefined) => {
          if (value !== undefined) {
            setNewEscalation({...newEscalation, escalationName: value});
          }
        }}
      />

      <HelperText type="error" visible={!!errors.escalationName}>
        {errors.escalationName}
      </HelperText>
      <FWDropdown
        multiple={false}
        label={LanguageString('Select Escalation level')}
        options={escalationLevelOptions}
        value={newEscalation.escalationLevel}
        onSelect={(value: string | undefined) => {
          if (value !== undefined) {
            setNewEscalation({...newEscalation, escalationLevel: value});
          }
        }}
      />
      <HelperText type="error" visible={!!errors.escalationLevel}>
        {errors.escalationLevel}
      </HelperText>
      <FWDropdown
        multiple={false}
        label={LanguageString('Select Escalation type')}
        options={escalationTypeOptions}
        value={newEscalation.escalationType}
        onSelect={(value: string | undefined) => {
          if (value !== undefined) {
            setNewEscalation({...newEscalation, escalationType: value});
          }
        }}
      />
      <HelperText type="error" visible={!!errors.escalationType}>
        {errors.escalationType}
      </HelperText>
      <DateTimePickerModal
        isVisible={isDatePickerVisible}
        mode="datetime"
        onConfirm={handleConfirm}
        onCancel={hideDatePicker}
      />
      <FWDropdown
        multiple={false}
        label={LanguageString('Select Status')}
        options={statusOptions}
        value={newEscalation.status}
        onSelect={(value: string | undefined) => {
          if (value !== undefined) {
            setNewEscalation({...newEscalation, status: value});
          }
        }}
      />
      <HelperText type="error" visible={!!errors.status}>
        {errors.status}
      </HelperText>
      <FwButtonPrimary
        onPress={handleAddNewEscalation}
        style={commonStyle.saveButton}>
        <FwTextSecondary>{LanguageString('Save')}</FwTextSecondary>
      </FwButtonPrimary>
      <FwButtonPrimary
        onPress={closeAddNewEscalation}
        style={commonStyle.closeButton}>
        <FwTextSecondary>{LanguageString('Cancel')}</FwTextSecondary>
      </FwButtonPrimary>
    </FwModal>
  );
};

export default AddEscalationModal;

const styles = StyleSheet.create({
  modalContainer: {
    backgroundColor: COLORS.BG_WHITE,
    padding: normalized(24),
    margin: normalized(24),
    borderRadius: normalized(8),
    elevation: normalized(4),
  },
  dropdownContainer: {
    marginTop: normalized(16),
    marginLeft: normalized(20),
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: normalized(24),
  },
  modalTitle: {
    fontSize: normalized(20),
    fontWeight: 'bold',
    color: COLORS.BLACK,
  },
});
