import React from 'react';
import {View, StyleSheet} from 'react-native';
import {Modal, HelperText} from 'react-native-paper';
import {COLORS} from '../../constants/colors';
import {FwButtonPrimary, FwTextPrimary, FwTextSecondary} from '../../elements';
import {LanguageString} from '../../constants/data';
import FWDropdown from '../../elements/FwDropdown';
import {AlertTypes} from '../../types/alertTypes';
import {PAGES} from '../pages';
import {normalized} from '../../constants/platform';
import {commonStyle} from '../../constants/theme';
import FwModal from '../../elements/FwModal';

interface AddAlertModalProps {
  isAddingNewAlert: boolean;
  closeAddNewAlert: any;
  newAlert: AlertTypes;
  sensorAOptions: any;
  severityAOptions: any;
  alertTypeOptions: any;
  onSelectSensor: any;
  onSelectSeverity: any;
  onSelectAlertType: any;
  errors: any;
  handleAddNewAlert: any;
  statusAOptions: any;
  onSelectNewAlertStatus: any;
}
const AddAlertModal = ({
  isAddingNewAlert,
  closeAddNewAlert,
  newAlert,
  sensorAOptions,
  severityAOptions,
  alertTypeOptions,
  onSelectSensor,
  onSelectSeverity,
  onSelectAlertType,
  errors,
  handleAddNewAlert,
  statusAOptions,
  onSelectNewAlertStatus,
}: AddAlertModalProps) => {
  return (
    <FwModal
      visible={isAddingNewAlert}
      onDismiss={closeAddNewAlert}
      contentContainerStyle={styles.modalContainer}>
      <View style={commonStyle.modalHeader}>
        <FwTextPrimary style={commonStyle.modalTitle}>
          {LanguageString('Add New Alert')}
        </FwTextPrimary>
      </View>
      <FWDropdown
        multiple={false}
        label={LanguageString('Select Sensor')}
        options={sensorAOptions}
        value={LanguageString(newAlert.sensor)}
        onSelect={onSelectSensor}
      />

      <HelperText type="error" visible={!!errors.sensor}>
        {errors.sensor}
      </HelperText>
      <FWDropdown
        multiple={false}
        label={LanguageString('Select Severity')}
        options={severityAOptions}
        value={newAlert.severity}
        onSelect={onSelectSeverity}
      />
      <HelperText type="error" visible={!!errors.severity}>
        {errors.severity}
      </HelperText>

      <FWDropdown
        multiple={false}
        label={LanguageString('Select Alert Type')}
        options={alertTypeOptions}
        value={newAlert.alertType}
        onSelect={onSelectAlertType}
      />

      <HelperText type="error" visible={!!errors.alertType}>
        {errors.alertType}
      </HelperText>
      <FWDropdown
        multiple={false}
        label={LanguageString('Select Status')}
        options={statusAOptions}
        value={newAlert.status}
        onSelect={onSelectNewAlertStatus}
      />
      <HelperText type="error" visible={!!errors.status}>
        {errors.status}
      </HelperText>
      <FwButtonPrimary onPress={handleAddNewAlert} style={styles.saveButton}>
        <FwTextSecondary type="buttonText">
          {LanguageString('Save')}
        </FwTextSecondary>
      </FwButtonPrimary>
      <FwButtonPrimary onPress={closeAddNewAlert} style={styles.closeButton}>
        <FwTextSecondary type="buttonText">
          {LanguageString('Cancel')}
        </FwTextSecondary>
      </FwButtonPrimary>
    </FwModal>
  );
};
export default AddAlertModal;

const styles = StyleSheet.create({
  modalContainer: {
    backgroundColor: COLORS.BG_WHITE,
    padding: normalized(24),
    margin: normalized(24),
    borderRadius: 8,
    elevation: 4,
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: normalized(24),
  },
  modalTitle: {
    fontSize: normalized(21),
    fontWeight: 'bold',
    letterSpacing: 1,
    marginBottom: normalized(10),
    marginLeft: normalized(5),
    color: COLORS.BLACK,
  },
  dropdownContainer: {
    marginTop: normalized(16),
    marginLeft: normalized(20),
  },
  saveButton: {
    marginTop: normalized(16),
  },
  input: {
    marginBottom: normalized(8),
  },
  closeButton: {
    marginTop: normalized(24),
  },
});
