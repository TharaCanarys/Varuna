import React from 'react';
import {View, RefreshControl, StyleSheet} from 'react-native';
import {TaskHistoryTypes} from '../../types/commonTypes';
import {useDispatch, useSelector} from 'react-redux';
import {FlatList} from 'react-native-gesture-handler';
import {Card} from 'react-native-paper';
import {COLORS} from '../../constants/colors';
import {LanguageString} from '../../constants/data';
import {commonStyle} from '../../constants/theme';
import {FwTextPrimary} from '../../elements';
import {normalized} from '../../constants/platform';
import TopBar from '../../navigation/TopBar';
import {useNavigation} from '@react-navigation/native';
import {PAGES} from '../../components/pages';
import FwLanguagePicker from '../../elements/FwLanguagePicker';
import {showDialog} from '../../store/appSlice';
import {RootState} from '../../store/store';
const TaskHistory: React.FC<TaskHistoryTypes> = (task: TaskHistoryTypes) => {
  const taskData = useSelector((state: any) => state.auth.task.task);
  const [refreshing, setRefreshing] = React.useState(false);
  const language = useSelector(
    (state: RootState) => state.app.selectedLanguage,
  );
  const onRefresh = React.useCallback(() => {
    setRefreshing(true);
    setTimeout(() => {
      setRefreshing(false);
    }, 2000);
  }, []);

  const cardContentItems = [
    {label: 'Updated By', value: 'changedBy'},
    {label: 'Updated Date', value: 'changedDate'},
    {label: 'Old Status', value: 'oldStatus'},
    {label: 'New Status', value: 'newStatus'},
    {label: 'Comments', value: 'comments'},
  ];

  const renderItem = ({item}: any) => (
    <>
      <Card style={styles.taskCard}>
        <Card.Title title={''} titleStyle={commonStyle.cardHeaderText} />
        <Card.Content style={styles.cardContent}>
          {cardContentItems.map((contentItem, index) => (
            <View key={index} style={commonStyle.modalRow}>
              <FwTextPrimary style={commonStyle.boldText}>
                {LanguageString(contentItem.label) + ' : '}
              </FwTextPrimary>
              <FwTextPrimary style={commonStyle.normalText}>
                {LanguageString(item[contentItem.value])}
              </FwTextPrimary>
            </View>
          ))}
        </Card.Content>
      </Card>
    </>
  );

  const handleLoadMore = () => {
    // Implement your pagination logic here
    // For example, fetch more data and append to taskData.taskHistory
  };
  const navigation = useNavigation();
  const dispatch = useDispatch();
  const handleLanguageChange = () => {
    dispatch(showDialog());
  };
  return (
    <>
      <TopBar navigation={navigation} routeName={PAGES.TASKS_HISTORY} />
      <View style={[commonStyle.modalRow, {...styles.titleContainer}]}>
        <FwTextPrimary style={commonStyle.boldText}>
          {LanguageString('Assigned To') + ' : '}
        </FwTextPrimary>
        <FwTextPrimary style={commonStyle.normalText}>
          {LanguageString(taskData.assignedTo)}
        </FwTextPrimary>
      </View>
      <FlatList
        data={taskData.taskHistory}
        renderItem={renderItem}
        keyExtractor={item => item.id}
        contentContainerStyle={styles.container}
        showsVerticalScrollIndicator={false}
        initialNumToRender={10}
        maxToRenderPerBatch={10}
        windowSize={5}
        removeClippedSubviews={true}
        onEndReached={handleLoadMore}
        onEndReachedThreshold={0.5}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
        }
      />
    </>
  );
};

const styles = StyleSheet.create({
  titleContainer: {marginHorizontal: normalized(20), marginTop: normalized(16)},
  container: {
    padding: normalized(16),
    flexGrow: 1,
  },
  taskCard: {
    marginBottom: normalized(16),
    elevation: 2,
    backgroundColor: COLORS.BG_WHITE,
    borderRadius: normalized(8),
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
  },
  cardContent: {
    marginTop: normalized(-16),
    paddingHorizontal: normalized(8),
  },
});
export default TaskHistory;
