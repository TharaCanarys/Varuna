import React, {useCallback, useMemo} from 'react';
import {View, StyleSheet, FlatList, RefreshControl} from 'react-native';
import {Avatar, IconButton, Card} from 'react-native-paper';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import {
  FwButtonPrimary,
  FwButtonSecondary,
  FwTextInputPrimary,
  FwTextPrimary,
  FwTextSecondary,
} from '../../elements';
import {COLORS} from '../../constants/colors';
import {Profile} from '../../types/profileTypes';
import {useDispatch} from 'react-redux';
import {LanguageString} from '../../constants/data';
import {normalized} from '../../constants/platform';
import TopBar from '../../navigation/TopBar';
import {PAGES} from '../../components/pages';
import {useNavigation} from '@react-navigation/native';
import {
  changeIncidentHeader,
  changeIncidentModal,
  
} from '../../store/appSlice';
import {HeaderBanner} from '../../components/HeaderBanner';

const ProfileScreenView: React.FC = ({
  editing,
  fields,
  refreshing,
  onRefresh,
  handleInputChange,
  profile,
  errors,
  toggleEditing,
  language,
  handleSubmit,
}: any) => {
  const dispatch = useDispatch();
  const navigation = useNavigation();

  const renderInputFields = useCallback(
    ({
      item: field,
      index,
    }: {
      item: {name: keyof Profile; label: string};
      index: number;
    }) => {
      if (!editing) return null;
      return (
        <View key={index}>
          <FwTextInputPrimary
            label={field.label}
            value={LanguageString(profile[field.name] || '')}
            onChangeText={(text: string) => handleInputChange(field.name, text)}
            style={styles.input}
            error={!!errors[field.name]}
            disabled={!editing}
          />
          {errors[field.name] && (
            <FwTextSecondary style={styles.error}>
              {errors[field.name]}
            </FwTextSecondary>
          )}
        </View>
      );
    },
    [editing, profile, errors, handleInputChange],
  );

  const renderProfileCard = useMemo(() => {
    if (editing) return null;
    return (
      <Card style={styles.card}>
        <Card.Content>
          {fields?.map((field: any, index: number) => (
            <View key={index} style={styles.fieldContainer}>
              <View style={styles.iconLabelContainer}>
                <Icon name={field.icon} size={30} style={styles.icon} />
                <View>
                  <FwTextSecondary style={styles.label}>
                    {field.label}
                  </FwTextSecondary>
                  <FwTextSecondary style={styles.value}>
                    {LanguageString(profile[field.name] || '')}
                  </FwTextSecondary>
                </View>
              </View>
              {errors[field.name] && (
                <FwTextSecondary style={styles.error}>
                  {errors[field.name]}
                </FwTextSecondary>
              )}
            </View>
          ))}
        </Card.Content>
      </Card>
    );
  }, [editing, fields, profile, errors, refreshing, language]);

  const isUpdateButtonDisabled = useMemo(() => {
    return (
      Object.values(errors).some(error => error !== '') ||
      Object.values(profile).some(
        value => typeof value === 'string' && !value.trim(),
      )
    );
  }, [errors, profile]);
  const ListHeaderComponent = useCallback(
    () => (
      <>
        <View style={styles.titleContainer}>
          <FwTextSecondary style={styles.title}>
            {editing
              ? LanguageString('Edit Profile')
              : LanguageString('View Profile')}
          </FwTextSecondary>
          <View style={{flexDirection: 'row'}}>
            <IconButton
              icon="pencil"
              size={24}
              onPress={toggleEditing}
              style={styles.editIcon}
            />
          </View>
        </View>
        <Avatar.Icon size={100} icon="account" style={styles.avatar} />
        {!editing && renderProfileCard}
      </>
    ),
    [editing, toggleEditing, renderProfileCard, language],
  );

  const ListFooterComponent = useCallback(
    () => (
      <>
        {editing && (
          <FwButtonPrimary
            mode="contained"
            onPress={handleSubmit}
            style={styles.button}
            disabled={isUpdateButtonDisabled}>
            <FwTextSecondary>{LanguageString('Update')}</FwTextSecondary>
          </FwButtonPrimary>
        )}
      </>
    ),
    [editing, handleSubmit, isUpdateButtonDisabled, language],
  );

  return (
    <>
      <HeaderBanner />
      <TopBar navigation={navigation} routeName={PAGES.PROFILE} />
      <FlatList
        style={styles.container}
        data={editing ? fields : []}
        renderItem={renderInputFields}
        keyExtractor={(item, index) => index.toString()}
        ListHeaderComponent={ListHeaderComponent}
        ListFooterComponent={ListFooterComponent}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
        }
      />
      <View style={styles.buttonContainer}>
        <FwButtonSecondary
          mode="outlined"
          icon="plus-circle"
          size={24}
          onPress={() => {
            navigation.navigate(PAGES.ADDINCIDENT as never);
            dispatch(changeIncidentModal(true));
            dispatch(changeIncidentHeader(true));
          }}
          style={styles.editIcon}>
          <FwTextPrimary type="buttonText">
            {LanguageString('Report Incident')}
          </FwTextPrimary>
        </FwButtonSecondary>
      </View>
    </>
  );
};
const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: normalized(16),
    backgroundColor: COLORS.BG_WHITE,
  },
  titleContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: normalized(20),
  },
  buttonContainer: {
    width: '50%',

    marginTop: normalized(20),
    alignSelf: 'center',
    bottom: normalized(10),
  },
  title: {
    fontSize: normalized(20),
    fontWeight: 'bold',
    color: COLORS.PRIMARY,
  },
  avatar: {
    alignSelf: 'center',
    marginBottom: normalized(20),
    backgroundColor: COLORS.BG_WHITE,
  },
  input: {
    marginBottom: normalized(10),
  },
  button: {
    marginTop: normalized(20),
  },
  editIcon: {
    marginLeft: normalized(10),
  },
  card: {
    marginBottom: normalized(20),
    elevation: normalized(4),
    borderRadius: normalized(8),
    backgroundColor: COLORS.BG_WHITE,
  },
  fieldContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: normalized(20),
    borderBottomWidth: 0.5,
    borderBottomColor: COLORS.DARKGRAY,
  },
  iconLabelContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  icon: {
    marginRight: normalized(10),
    color: COLORS.PRIMARY,
  },
  label: {
    fontSize: normalized(14),
    color: COLORS.DARKGRAY,
  },
  value: {
    color: COLORS.BLACK,
    fontSize: normalized(18),
  },
  error: {
    color: COLORS.CRITICAL,
    fontSize: normalized(14),
    marginBottom: normalized(8),
  },
});

export default ProfileScreenView;
