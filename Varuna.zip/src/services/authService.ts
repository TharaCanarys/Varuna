const STORAGE_KEY = 'authToken';
const STORAGE_ID = 'userId';
const LANGUAGE = 'English';
const NOTIFICATIONS = 'viewedNotifications';

import AsyncStorage from '@react-native-async-storage/async-storage';
import translate from 'google-translate-api-x';

export const storeToken = async (token: string) => {
  // console.log('Token: in Storage', token);
  // Store Token in Async Storage
  if (token) {
    await AsyncStorage.setItem(STORAGE_KEY, token);
  }

};
export const storeId = async (userId: string) => {
  // Store UserId in Async Storage
  if (userId) {
    await AsyncStorage.setItem(STORAGE_ID, userId);
  }

};

// Translate common Function
export const TranslatingData = async (text: string, fromLanguage: string) => {
  if (!text || text == null || text == undefined || text == '') {
    return;
  } else {

    try {
      if (fromLanguage === 'en') {
        const translated = await translate(text, {
          from: 'en',
          to: 'hi',
          autoCorrect: true,
        });
        return translated.text;
      } else {

        const translated = await translate(text, {
          from: 'hi',
          to: 'en',
          autoCorrect: true,
        });


        return translated.text;
      }
    } catch (error) {
      console.error('Translation error:', error);
      return text;
    }
  }
};
export const getToken = async () => {
  // Get Token from Async Storage
  return await AsyncStorage.getItem(STORAGE_KEY);
};
export const getId = async () => {
  // Get Token from Async Storage
  return await AsyncStorage.getItem(STORAGE_ID);
};

export const removeToken = async () => {
  // Remove Token from Async Storage
  await AsyncStorage.removeItem(STORAGE_KEY);
};

export const storeLanguage = async (language: string) => {
  // Store language in Async Storage
  if (language) {
    await AsyncStorage.setItem(LANGUAGE, language);
  }

};

export const getLanguage = async () => {
  // Get Language from Async Storage
  return await AsyncStorage.getItem(LANGUAGE);
};

export const changeLanguage = async () => {
  // Remove Token from Async Storage
  await AsyncStorage.removeItem(STORAGE_KEY);
};

export const getNotificationCount = async () => {
  // Get Token from Async Storage
  return await AsyncStorage.getItem(NOTIFICATIONS);
};

export const storeNotificationCount = async (count: string) => {
  if (count) {
    await AsyncStorage.setItem(NOTIFICATIONS, count);
  }

};