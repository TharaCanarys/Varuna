import React from 'react';
import {View, StyleSheet} from 'react-native';
import {useNavigation, CommonActions} from '@react-navigation/native';
import {PAGES} from '../../components/pages';
import {IMAGES} from '../../assets';
import {useDispatch} from 'react-redux';
import {COLORS} from '../../constants/colors';
import FwImage from '../../elements/FwImage';

const SplashScreenView: React.FC = () => {
  const navigation = useNavigation();

  setTimeout(() => {
    navigation.dispatch(
      CommonActions.reset({
        index: 0,
        routes: [{name: PAGES.LANGUAGE_SELECTION}],
      }),
    );
  }, 3000);

  return (
    <View style={styles.container}>
      <FwImage
        source={IMAGES.SPLASH_IMAGE}
        style={styles.logo}
        resizeMode="cover"
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: COLORS.BG_WHITE,
  },
  logo: {
    width: '80%',
    height: '80%',
  },
});
export default SplashScreenView;
