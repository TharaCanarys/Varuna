import React from 'react';
import {Snackbar} from 'react-native-paper';
import {COLORS} from '../constants/colors';

const FwNotifyMessage = ({
  children,
  visible,
  type,
  ...props
}: {
  children: React.ReactNode;
  visible: boolean;
  type: string;
}) => {
  return (
    <Snackbar
      visible={visible}
      duration={3000}
      style={{
        backgroundColor: type === 'error' ? COLORS.ERROR : COLORS.SUCCESS,
      }}
      {...props}>
      {children}
    </Snackbar>
  );
};
export default FwNotifyMessage;
