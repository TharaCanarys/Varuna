import React, {useCallback, useState} from 'react';
import {
  createDrawerNavigator,
  DrawerContent,
  DrawerContentComponentProps,
  DrawerItem,
} from '@react-navigation/drawer';
import {normalized} from '../constants/platform';
import {COLORS} from '../constants/colors';
import {StyleSheet, View, TouchableOpacity, ScrollView} from 'react-native';
import {HeaderBanner} from '../components/HeaderBanner';
import {AppbarTop} from '../components/AppBar';
import {Searchbar, Text} from 'react-native-paper';
import FwImage from '../elements/FwImage';
import {IMAGES} from '../assets';
import {LanguageString, USER_ROLES} from '../constants/data';
import {PAGES} from '../components/pages';
import {
  AlertScreen,
  Charts,
  CityAdminScreen,
  DashboardScreen,
  EscalationScreenView,
  IMDMapScreen,
  IncidentScreen,
  LogsScreen,
  MaintenanceScreen,
  MapScreen,
  POIScreen,
  SensorScreen,
  SupportTicketScreen,
  TaskScreen,
  WaterPercentage,
  WeatherForecast,
  PumpOperationScreen,
  ContactScreen,
  EquipmentsScreen
} from '../screens';

import Icon from 'react-native-vector-icons/MaterialIcons';

const AppDrawer = ({
  dispatch,
  toggleMenu,
  visibleSearch,
  searchQuery,
  setSearchQuery,
  role,
}: any) => {
  const DrawerNav = createDrawerNavigator();
  const [isVisualizationActive, setIsVisualizationActive] = useState(false);

  const MenuBanner = () => (
    <View style={styles.menuBanner}>
      <FwImage source={IMAGES.LOGO} style={styles.menuLogo} />
    </View>
  );

  const getDrawerScreens = useCallback(() => {
    const allScreens = [
      {name: PAGES.DASHBOARD, component: DashboardScreen},
      // {name: PAGES.SENSOR, component: SensorScreen},
      // {name: PAGES.ALERTS, component: AlertScreen},
      {name: PAGES.INCIDENT, component: IncidentScreen},
      {name: PAGES.TASKS, component: TaskScreen},
      {name: PAGES.MAINTENANCE, component: MaintenanceScreen},
      {name: PAGES.EQUIPMENTS, component: EquipmentsScreen},
      {name: PAGES.ESCALATIONS, component: EscalationScreenView},
      {name: PAGES.SUPPORTTICKET, component: SupportTicketScreen},
      // {name: PAGES.CITYADMIN, component: CityAdminScreen},
      {name: PAGES.POI, component: POIScreen},
      {name: PAGES.LOGS, component: LogsScreen},

      {
        name: PAGES.VISUALIZATION,
        component: LogsScreen,
        subScreens: [
          // {name: PAGES.NALAS, component: NalaScreen},
          {name: PAGES.MAP, component: MapScreen},
          {name: PAGES.CHARTS, component: Charts},
          {name: PAGES.WEATHER_FORECAST, component: WeatherForecast},
          {name: PAGES.WATER_PERCENTAGE, component: WaterPercentage},
          {name: PAGES.PUMP_OPERATIONS, component: PumpOperationScreen},
          {name: PAGES.IMD_MAP, component: IMDMapScreen},
        ],
      },
      {name: PAGES.CONTACT, component: ContactScreen},
    ];

    switch (role) {
      case USER_ROLES.USER:
        return allScreens.filter(screen =>
          [PAGES.DASHBOARD, PAGES.INCIDENT, PAGES.CONTACT].includes(
            screen.name,
          ),
        );
      case USER_ROLES.CAL:
        return allScreens;
      case USER_ROLES.ADMIN:
        return allScreens.filter(screen =>
          [
            PAGES.DASHBOARD,
            PAGES.VISUALIZATION,
            PAGES.TASKS,
            PAGES.MAINTENANCE,
            PAGES.ESCALATIONS,
            PAGES.EQUIPMENTS,
            PAGES.CONTACT,
          ].includes(screen.name),
        );
      case USER_ROLES.MC:
      case USER_ROLES.AMC:
      case USER_ROLES.GM:
        return allScreens.filter(screen =>
          [
            PAGES.DASHBOARD,
            PAGES.VISUALIZATION,
            PAGES.TASKS,
            PAGES.MAINTENANCE,
            PAGES.ESCALATIONS,
            PAGES.EQUIPMENTS,
            PAGES.CONTACT,
          ].includes(screen.name),
        );
      case USER_ROLES.AE:
      case USER_ROLES.AEC:
      case USER_ROLES.CI:
      case USER_ROLES.ZO:
      case USER_ROLES.ZSO:
      case USER_ROLES.CE:
      case USER_ROLES.ExEn:
      case USER_ROLES.NSA:
        return allScreens.filter(screen =>
          [
            PAGES.DASHBOARD,
            PAGES.VISUALIZATION,
            PAGES.INCIDENT,
            PAGES.TASKS,
            PAGES.MAINTENANCE,
            PAGES.ESCALATIONS,
            PAGES.CONTACT,
          ].includes(screen.name),
        );
      case USER_ROLES.JE:
      case USER_ROLES.JEC:
      case USER_ROLES.SI:
        return allScreens.filter(screen =>
          [
            PAGES.DASHBOARD,
            PAGES.VISUALIZATION,
            PAGES.INCIDENT,
            PAGES.TASKS,
            PAGES.MAINTENANCE,
            PAGES.ESCALATIONS,
          ].includes(screen.name),
        );
      case USER_ROLES.SS:
        return allScreens.filter(screen =>
          [PAGES.TASKS, PAGES.CONTACT].includes(screen.name),
        );
      case USER_ROLES.TECHNICIAN:
        return allScreens.filter(screen =>
          [PAGES.MAINTENANCE, PAGES.CONTACT].includes(screen.name),
        );
      default:
        return allScreens.filter(screen =>
          [PAGES.DASHBOARD,PAGES.INCIDENT, PAGES.CONTACT].includes(screen.name),
        );
    }
  }, [role]);

  const drawersScreens = getDrawerScreens();

  return (
    <DrawerNav.Navigator
      screenOptions={{
        headerShown: true,
        drawerLabelStyle: {fontSize: normalized(20)},
        headerStyle: {
          height: normalized(120),
          backgroundColor: COLORS.PRIMARY,
          elevation: normalized(8),
          shadowOpacity: normalized(0.5),
          shadowOffset: {width: 0, height: 4},
          shadowRadius: normalized(6),
          shadowColor: COLORS.BLACK,
          zIndex: normalized(1000),
        },
        header: ({navigation, route}) => (
          <View
            style={{
              backgroundColor: COLORS.PRIMARY,
              elevation: normalized(8),
              shadowOpacity: normalized(0.5),
              shadowOffset: {width: 0, height: 4},
              shadowRadius: normalized(6),
              shadowColor: COLORS.BLACK,
              zIndex: normalized(1000),
            }}>
            <HeaderBanner />
            <AppbarTop
              navigation={navigation}
              dispatch={dispatch}
              route={route}
              toggleMenu={toggleMenu}
            />
            {visibleSearch && (
              <View style={styles.search}>
                <Searchbar
                  placeholder="Search"
                  onChangeText={setSearchQuery}
                  value={searchQuery}
                  placeholderTextColor="#666666"
                  style={{backgroundColor: COLORS.PRIMARY}}
                  inputStyle={{color: '#000000'}}
                />
              </View>
            )}
          </View>
        ),
      }}
      drawerContent={(props: DrawerContentComponentProps) => (
        <View style={styles.drawerContent}>
          <MenuBanner />
          <ScrollView>
            {props.state.routes.map((route, index) => {
              const focused = index === props.state.index;
              const {options} = props.descriptors[route.key];
              const label = route.name;

              if (route.name === LanguageString(PAGES.VISUALIZATION)) {
                return (
                  <TouchableOpacity
                    key={route.key}
                    onPress={() =>
                      setIsVisualizationActive(!isVisualizationActive)
                    }
                    style={styles.visualizationItem}>
                    <View style={styles.visualizationHeader}>
                      <Text style={styles.visualizationText}>
                        {LanguageString(PAGES.VISUALIZATION)}
                      </Text>
                      <Icon
                        name={
                          isVisualizationActive
                            ? 'keyboard-arrow-up'
                            : 'keyboard-arrow-down'
                        }
                        size={24}
                        color={COLORS.PRIMARY}
                      />
                    </View>
                  </TouchableOpacity>
                );
              }
              return (
                <DrawerItem
                  key={route.key}
                  label={label}
                  focused={focused}
                  onPress={() => props.navigation.navigate(route.name)}
                  {...options}
                />
              );
            })}
          </ScrollView>
        </View>
      )}>
      {drawersScreens.map((screen, index) => {
        if (screen.name === PAGES.VISUALIZATION) {
          return (
            <React.Fragment key={index}>
              <DrawerNav.Screen
                name={LanguageString(screen.name)}
                component={screen.component}
                options={{drawerContentStyle: styles.drawerList}}
              />
              {isVisualizationActive &&
                screen.subScreens?.map((subScreen, subIndex) => (
                  <DrawerNav.Screen
                    key={`${index}-${subIndex}`}
                    name={LanguageString(subScreen.name)}
                    component={subScreen.component}
                    options={{
                      drawerContentStyle: styles.drawerList,
                    }}
                  />
                ))}
            </React.Fragment>
          );
        }
        return (
          <DrawerNav.Screen
            key={index}
            name={LanguageString(screen.name)}
            component={screen.component}
            options={{drawerContentStyle: styles.drawerList}}
          />
        );
      })}
    </DrawerNav.Navigator>
  );
};

export default AppDrawer;

const styles = StyleSheet.create({
  menuBanner: {
    alignItems: 'center',
    backgroundColor: COLORS.BG_WHITE,
  },
  menuLogo: {
    width: normalized(100),
    height: normalized(100),
    marginTop: normalized(10),
  },
  search: {
    marginBottom: normalized(20),
    position: 'absolute',
    top: normalized(150),
    left: 0,
    right: 0,
    zIndex: 1,
  },
  drawerList: {
    backgroundColor: COLORS.SECONDARY,
  },
  drawerContent: {
    flex: 1,
  },
  visualizationItem: {
    paddingHorizontal: normalized(8),
    paddingVertical: normalized(8),
  },
  visualizationHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  visualizationText: {
    fontSize: normalized(14),
    color: COLORS.DARKGRAY,
    textAlign: 'left',
    fontWeight: 'bold',
    paddingLeft: normalized(8),
  },
});
