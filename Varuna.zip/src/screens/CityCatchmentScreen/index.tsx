import React, {useCallback, useState, useMemo, useEffect} from 'react';
import {CityCatchmentPropTypes} from '../../types/commonTypes';
import {
  cityCatchmentData,
  LanguageString,
  maintenanceTypeOptions,
} from '../../constants/data';
import CityCatchmentScreenView from './CityCatchmentScreenView';
import {useSelector} from 'react-redux';
import {RootState} from '../../store/store';

const CityCatchmentScreen: React.FC = () => {
  const [selectedCityCatchment, setSelectedCityCatchment] =
    useState<CityCatchmentPropTypes | null>(null);
  const [editingStatus, setEditingStatus] = useState(false);
  const [newStatus, setNewStatus] = useState('');
  const [statusError, setStatusError] = useState('');
  const [cityCatchments, setCityCatchments] =
    useState<CityCatchmentPropTypes[]>(cityCatchmentData);
  const [isAddingNewCityCatchment, setIsAddingNewCityCatchment] =
    useState(false);
  const language = useSelector(
    (state: RootState) => state.app.selectedLanguage,
  );
  const [newCityCatchment, setNewCityCatchment] =
    useState<CityCatchmentPropTypes>({
      id: 0,
      cityCatchmentAreaName: '',
      location: '',
      areaSize: '',
      waterBodies: '',
      runOfCoeffecient: '',
      avgRainfall: '',
      drainageCapacity: '',
      floodRiskLevel: '',
    });
  const [errors, setErrors] = useState({
    cityCatchmentAreaName: '',
    location: '',
    areaSize: '',
    waterBodies: '',
    runOfCoeffecient: '',
    avgRainfall: '',
    drainageCapacity: '',
    floodRiskLevel: '',
  });
  const [refreshing, setRefreshing] = useState(false);

  // Memoize the initial state of newCityCatchment to avoid unnecessary re-renders
  const initialNewCityCatchmentState = useMemo(
    () => ({
      id: 0,
      cityCatchmentAreaName: '',
      location: '',
      areaSize: '',
      waterBodies: '',
      runOfCoeffecient: '',
      avgRainfall: '',
      drainageCapacity: '',
      floodRiskLevel: '',
    }),
    [],
  );

  // Simulate data refresh
  useEffect(() => {
    onRefresh();
  }, [language]);
  const onRefresh = useCallback(() => {
    setRefreshing(true);
    setTimeout(() => {
      setCityCatchments([...cityCatchmentData]);
      setRefreshing(false);
    }, 1000);
  }, []);

  // Open cityCatchment details modal
  const openCityCatchmentDetails = useCallback(
    (cityCatchment: CityCatchmentPropTypes) => {
      setSelectedCityCatchment(cityCatchment);
    },
    [],
  );

  // Close cityCatchment details modal
  const closeCityCatchmentDetails = useCallback(() => {
    setSelectedCityCatchment(null);
    setEditingStatus(false);
  }, []);

  // Toggle status editing
  const startEditingStatus = useCallback(() => {
    setEditingStatus(prev => !prev);
  }, []);

  // Save updated cityCatchment status
  const saveStatus = useCallback(() => {
    if (selectedCityCatchment) {
      setCityCatchments(prevCityCatchments =>
        prevCityCatchments.map(cityCatchment =>
          cityCatchment.id === selectedCityCatchment.id
            ? {...cityCatchment, status: newStatus}
            : cityCatchment,
        ),
      );
      setSelectedCityCatchment(prev => ({...prev!, status: newStatus}));
      setEditingStatus(false);
    }
  }, [selectedCityCatchment, newStatus]);

  // Validate status input
  const validateStatus = useCallback((status: string) => {
    if (!status) {
      setStatusError(LanguageString('Status is required'));
    } else {
      setStatusError('');
    }
  }, []);

  // Open add new cityCatchment modal
  const openAddNewCityCatchment = useCallback(() => {
    setIsAddingNewCityCatchment(true);
  }, []);

  // Close add new cityCatchment modal
  const closeAddNewCityCatchment = useCallback(() => {
    setIsAddingNewCityCatchment(false);
    setNewCityCatchment(initialNewCityCatchmentState);
    setErrors({
      cityCatchmentAreaName: '',
      location: '',
      areaSize: '',
      waterBodies: '',
      runOfCoeffecient: '',
      avgRainfall: '',
      drainageCapacity: '',
      floodRiskLevel: '',
    });
  }, [initialNewCityCatchmentState]);

  // Validate new cityCatchment input
  const validateNewCityCatchment = useCallback(() => {
    let isValid = true;
    const newErrors = {
      cityCatchmentAreaName: '',
      location: '',
      areaSize: '',
      waterBodies: '',
      runOfCoeffecient: '',
      avgRainfall: '',
      drainageCapacity: '',
      floodRiskLevel: '',
    };
    if (!newCityCatchment.location) {
      newErrors.location =
        LanguageString('Location') + ' ' + LanguageString('is required');
      isValid = false;
    }
    if (!newCityCatchment.cityCatchmentAreaName) {
      newErrors.cityCatchmentAreaName =
        LanguageString('Name') + ' ' + LanguageString('is required');
      isValid = false;
    }
    if (!newCityCatchment.areaSize) {
      newErrors.areaSize =
        LanguageString('Area Size') + ' ' + LanguageString('is required');
      isValid = false;
    }
    if (!newCityCatchment.waterBodies) {
      newErrors.waterBodies =
        LanguageString('Water Bodies') + ' ' + LanguageString('is required');
      isValid = false;
    }
    if (!newCityCatchment.runOfCoeffecient) {
      newErrors.runOfCoeffecient =
        LanguageString('Run of Coeffecient') +
        ' ' +
        LanguageString('is required');
      isValid = false;
    }
    if (!newCityCatchment.avgRainfall) {
      newErrors.avgRainfall =
        LanguageString('Average Rainfall') +
        ' ' +
        LanguageString('is required');
      isValid = false;
    }
    if (!newCityCatchment.drainageCapacity) {
      newErrors.drainageCapacity =
        LanguageString('Drainage Capacity') +
        ' ' +
        LanguageString('is required');
      isValid = false;
    }
    if (!newCityCatchment.floodRiskLevel) {
      newErrors.floodRiskLevel =
        LanguageString('Flood Risk Level') +
        ' ' +
        LanguageString('is required');
      isValid = false;
    }

    setErrors(newErrors);
    return isValid;
  }, [newCityCatchment]);

  // Add new cityCatchment
  const handleAddNewCityCatchment = useCallback(() => {
    if (validateNewCityCatchment()) {
      setCityCatchments(prevCityCatchments => {
        const newId = Math.max(...prevCityCatchments.map(s => s.id), 0) + 1;
        const cityCatchmentToAdd = {...newCityCatchment, id: newId};
        return [...prevCityCatchments, cityCatchmentToAdd];
      });
      closeAddNewCityCatchment();
    }
  }, [newCityCatchment, validateNewCityCatchment, closeAddNewCityCatchment]);

  // Delete cityCatchment
  const handleDeleteCityCatchment = useCallback(
    (cityCatchment: CityCatchmentPropTypes) => {
      setCityCatchments(prevCityCatchments =>
        prevCityCatchments.filter(s => s.id !== cityCatchment.id),
      );
    },
    [],
  );

  // Memoize the props for CityCatchmentScreenView to prevent unnecessary re-renders
  const cityCatchmentScreenViewProps = useMemo(
    () => ({
      selectedCityCatchment,
      editingStatus,
      newStatus,
      cityCatchments,
      isAddingNewCityCatchment,
      setIsAddingNewCityCatchment,
      newCityCatchment,
      setNewCityCatchment,
      setNewStatus,
      errors,
      refreshing,
      onRefresh,
      openCityCatchmentDetails,
      closeCityCatchmentDetails,
      startEditingStatus,
      saveStatus,
      validateStatus,
      openAddNewCityCatchment,
      closeAddNewCityCatchment,
      handleAddNewCityCatchment,
      handleDeleteCityCatchment,
    }),
    [
      selectedCityCatchment,
      editingStatus,
      newStatus,
      cityCatchments,
      setIsAddingNewCityCatchment,
      isAddingNewCityCatchment,
      newCityCatchment,
      errors,
      refreshing,
      onRefresh,
      openCityCatchmentDetails,
      closeCityCatchmentDetails,
      startEditingStatus,
      saveStatus,
      validateStatus,
      openAddNewCityCatchment,
      closeAddNewCityCatchment,
      handleAddNewCityCatchment,
      handleDeleteCityCatchment,
    ],
  );

  return <CityCatchmentScreenView {...cityCatchmentScreenViewProps} />;
};
export default CityCatchmentScreen;
