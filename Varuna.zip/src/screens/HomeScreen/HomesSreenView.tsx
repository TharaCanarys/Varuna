import React, {useCallback, useEffect, useState} from 'react';
import {
  View,
  StyleSheet,
  ScrollView,
  SafeAreaView,
  TouchableOpacity,
  RefreshControl,
  ViewStyle,
} from 'react-native';
import {Card} from 'react-native-paper';
import {HeaderBanner} from '../../components/HeaderBanner';
import {COLORS} from '../../constants/colors';
import {CommonActions, useNavigation} from '@react-navigation/native';
import {PAGES} from '../../components/pages';
import {getId, getToken} from '../../services/authService';
import {useDispatch, useSelector} from 'react-redux';
import {setToken, setUserDetails} from '../../store/authSlice';
import {LanguageString, width} from '../../constants/data';
import {FwButtonPrimary, FwTextPrimary} from '../../elements';
import {normalized} from '../../constants/platform';
import DateComponent from '../../components/DateComponent';
import FwLanguagePicker from '../../elements/FwLanguagePicker';
import {RootState} from '../../store/store';
import {changeLanguage} from 'i18next';
import FwModal from '../../elements/FwModal';
import {DecodeJWT} from '../../components/DecodeJWT';
import {Location} from './GuestView';
import {
  saveDashboardData,
  saveFloodData,
  saveLocation,
} from '../../store/appSlice';
import {fetchLocations, getFloodData} from '../../services/apiServices';
import {
  HomeFloodData,
  HomeRainfallData,
  HomeSensorData,
} from '../../components';

interface DecodedToken {
  id: string;
  role: string;
  [key: string]: any;
}

const HomeScreenView = () => {
  const navigation = useNavigation();
  const dispatch = useDispatch();
  const [refreshing, setRefreshing] = useState(false);
  const [isModalVisible, setModalVisible] = useState(false);
  const [isLoading, setLoading] = useState(false);
  const language = useSelector(
    (state: RootState) => state.app.selectedLanguage,
  );
  const floodData = useSelector((state: RootState) => state.app.floodData);
  const [currentLanguage, setCurrentLanguage] = useState(language);

  const onRefresh = React.useCallback(() => {
    setRefreshing(true);
    setTimeout(() => {
      setRefreshing(false);
    }, 2000);
  }, []);

  // Saving token in redux store while navigating to dashboard
  const handleNavigation = async () => {
    try {
      const token = await getToken();
      console.log('Token', token);
      if (!token) {
        navigation.dispatch(
          CommonActions.reset({
            index: 0,
            routes: [{name: PAGES.LOGIN}],
          }),
        );
        return;
      }

      const decodedToken = DecodeJWT({token}) as DecodedToken;
      if (!decodedToken) {
        navigation.dispatch(
          CommonActions.reset({
            index: 0,
            routes: [{name: PAGES.LOGIN}],
          }),
        );
        return;
      }

      const id = decodedToken.id;
      const role = decodedToken.role;
      const userName = decodedToken.userName;

      console.log('Token Decoded:', decodedToken);

      if (id) {
        dispatch(setToken(token));
        dispatch(setUserDetails({role, id, userName}));
        navigation.navigate(PAGES.DASHBOARD_NAV as never);
      }
    } catch (error) {
      navigation.dispatch(
        CommonActions.reset({
          index: 0,
          routes: [{name: PAGES.LOGIN}],
        }),
      );
    }
  };

  const handleChangeLanguage = () => {
    changeLanguage(currentLanguage === 'hi' ? 'en' : 'hi');
    setCurrentLanguage(currentLanguage === 'hi' ? 'en' : 'hi');
    setModalVisible(false);
    onRefresh();
  };

  const modalStyle: ViewStyle = {
    backgroundColor: 'white',
    padding: 30,
    margin: 20,
    borderRadius: 40,
    alignSelf: 'center',
  };

  // Fetching and setting the Locations in Redux
  const onFetchLocations = (data: Location[]) => {
    // console.log('Location data Fetched');
    dispatch(saveLocation(data));
  };

  const onLocationFailed = (data: Location[]) => {
    console.log('Location data Fetching Failed', data);
  };

  const onGetFailed = useCallback((error: any) => {
    setLoading(false);
    console.log('Failed to get data', error);
  }, []);

  const onGetSuccess = useCallback(
    (data: any) => {
      dispatch(saveFloodData(data));
    },
    [dispatch],
  );

  // useEffect(() => {
  //   fetchLocations({onFetchLocations, onLocationFailed});
  // }, []);

  useEffect(() => {
    const payload = {status:1};
    getFloodData(payload, setLoading, onGetSuccess, onGetFailed);
  }, [onGetSuccess, onGetFailed]);

  return (
    <SafeAreaView style={styles.safeArea}>
      <HeaderBanner />

      <View style={styles.header}>
        <View style={styles.headerTextContainer}>
          <FwTextPrimary style={styles.headerText}>
            {LanguageString('Flood Warning Dashboard')}
          </FwTextPrimary>
          <DateComponent />
        </View>
        <TouchableOpacity onPress={() => setModalVisible(true)}>
          <FwLanguagePicker />
        </TouchableOpacity>
      </View>
      <ScrollView
        style={styles.container}
        contentContainerStyle={{flexGrow: 1}}
        removeClippedSubviews={false}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
        }>
        <HomeRainfallData styles={styles} />
        {/* <HomeSensorData styles={styles} floodData={HomefloodData} /> */}
        <HomeFloodData styles={styles} floodData={floodData} />

        {/* Sign In Link */}
        <Card
          style={[styles.card, styles.signInCard]}
          onPress={() => handleNavigation()}>
          <Card.Content>
            <FwTextPrimary style={styles.signInText}>
              {LanguageString('Click here to sign in for more info')}.
            </FwTextPrimary>
          </Card.Content>
        </Card>

        <FwModal
          visible={isModalVisible}
          onDismiss={() => setModalVisible(false)}
          contentContainerStyle={modalStyle}>
          <View>
            <FwTextPrimary style={styles.modalTitle}>
              {LanguageString('Change Language')}
            </FwTextPrimary>
            <View style={styles.buttonContainer}>
              <FwButtonPrimary
                mode="outlined"
                onPress={() => setModalVisible(false)}
                style={styles.button}>
                <FwTextPrimary style={styles.buttonText}>
                  {LanguageString('LanguageCancel')}
                </FwTextPrimary>
              </FwButtonPrimary>
              <FwButtonPrimary
                mode="outlined"
                onPress={() => handleChangeLanguage()}
                style={styles.button}>
                <FwTextPrimary style={styles.buttonText}>
                  {LanguageString('LanguageConfirm')}
                </FwTextPrimary>
              </FwButtonPrimary>
            </View>
          </View>
        </FwModal>
      </ScrollView>
    </SafeAreaView>
  );
};
const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: '#FAFAFA',
  },
  container: {
    flex: 1,
    padding: normalized(15),
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    width: width,
    paddingVertical: normalized(5),
    // paddingHorizontal: normalized(15),
    backgroundColor: COLORS.PRIMARY,
    alignItems: 'center',
    marginBottom: normalized(10),
  },
  headerText: {
    textAlign: 'center',
    fontSize: normalized(16),
    color: COLORS.SECONDARY,
    fontWeight: 'bold',
    alignItems: 'flex-start',
  },

  topRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: normalized(12),
  },
  card: {
    marginBottom: normalized(12),
    elevation: 3,
  },
  halfCard: {
    flex: 0.48,
  },
  cardTitle: {
    fontSize: normalized(18),
    fontWeight: '600',
    color: COLORS.PRIMARY,
    marginBottom: normalized(10),
  },
  detailRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: normalized(8),
    justifyContent: 'space-between',
  },
  detailText: {
    fontSize: normalized(14),
    color: '#333333',
    marginLeft: normalized(8),
    flex: 1,
  },
  valueText: {
    fontSize: normalized(17),
    fontWeight: 'bold',
    marginLeft: normalized(8),
  },
  alertText: {
    fontSize: normalized(16),
    marginLeft: normalized(8),
  },
  mapPlaceholder: {
    width: '100%',
    height: normalized(180),
    backgroundColor: COLORS.BG_WHITE,
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: normalized(8),
    marginTop: normalized(15),
  },
  signInCard: {
    marginBottom: normalized(20),
  },
  signInText: {
    color: COLORS.PRIMARY,
    textAlign: 'center',
    textDecorationLine: 'underline',
  },
  headerTextContainer: {marginLeft: normalized(80)},
  modalTitle: {
    fontSize: normalized(18),
    marginBottom: normalized(20),
    textAlign: 'left',
    lineHeight: normalized(24),
    fontWeight: 'bold',
  },
  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    width: width - 90,
    marginTop: normalized(10),
    // backgroundColor: COLORS.DARKORANGE,
  },
  buttonText: {
    fontSize: normalized(12),
  },
  button: {
    marginLeft: normalized(5),
    // backgroundColor: COLORS.DARKORANGE,
    // width: normalized(width / 3),
  },
});
export default HomeScreenView;
