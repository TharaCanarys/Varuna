import React, {useState, useEffect} from 'react';
import {View, StyleSheet, Image, ScrollView, Dimensions} from 'react-native';
import {Card, IconButton} from 'react-native-paper';
import {LanguageString} from '../../constants/data';
import {commonStyle} from '../../constants/theme';
import {FwTextPrimary} from '../../elements';
import { getAddressFromCoordinates } from '../../services/apiServices';

const {width} = Dimensions.get('window');



const RenderIncidentItem = ({
  item,
  styles,
  validateRole,
  setEditingStatus,
  startEditingStatus,
  openIncidentDetails,
  showDeleteConfirmation,
}: any) => {
  const [locationDetails, setLocationDetails] = useState({
    city: '',
    state: '',
    area: '',
  });

  useEffect(() => {
    const fetchLocation = async () => {
      if (item?.latitude && item?.longitude) {
        const address = await getAddressFromCoordinates(
          item.latitude,
          item.longitude,
        );
        setLocationDetails({
          city: address.city || '',
          state: address.state || '',
          area: address.area || '',
        });
      }
    };    fetchLocation();
  }, [item?.latitude, item?.longitude]);

  return (
    <Card style={styles.incidentCard} onPress={() => openIncidentDetails(item)}>
      <Card.Title
        title={LanguageString('Incident') + ' ' + item?.incidentID}
        titleStyle={commonStyle.cardHeaderText}
        left={props => (
          <IconButton {...props} icon="alert-octagon" style={styles.cardIcon} />
        )}
        right={props =>
          validateRole ? (
            <View style={styles.cardActions}>
              {/* <IconButton
                {...props}
                icon="pencil"
                onPress={() => {
                  openIncidentDetails(item);
                  setEditingStatus(true);
                  startEditingStatus();
                }}
                disabled={item?.status === 'Resolved'}
              />
              <IconButton
                {...props}
                icon="delete"
                onPress={() => showDeleteConfirmation(item?.id)}
              /> */}
            </View>
          ) : null
        }
      />
      <Card.Content style={styles.cardContent}>
        <View style={styles.card}>
          <View style={styles.cardHeader}>
            <FwTextPrimary style={styles.status}>
              {LanguageString('Status')}: {LanguageString('Open')}
            </FwTextPrimary>
          </View>
          {item?.description ? (
            <FwTextPrimary style={styles.cardDescription}>
              {LanguageString('Description')}: {item?.description}
            </FwTextPrimary>
          ) : null}
          {item?.comments ? (
            <FwTextPrimary style={styles.cardDescription}>
              {LanguageString('Comment')}: {item?.comments}
            </FwTextPrimary>
          ) : null}
          <FwTextPrimary style={styles.timestamp}>
            {item?.timestamp}
          </FwTextPrimary>
          <ScrollView
            horizontal
            pagingEnabled
            showsHorizontalScrollIndicator={true}
            style={styles.imageContainer}>
            {item?.PictureData && (
              <Image
                source={{
                  uri: `data:image/jpeg;base64,${item.PictureData}`,
                }}
                style={[styles.image, {width: width - 40, height: 200}]}
                resizeMode="cover"
              />
            )}
          </ScrollView>
          <FwTextPrimary style={styles.titleText}>
            {LanguageString('Location')}:
            <FwTextPrimary style={styles.locationText}>
              {' '}
              {`${item?.latitude?.toFixed(2)}, ${item?.longitude?.toFixed(2)}`}
              {locationDetails.city &&
                ` - ${locationDetails.area}${
                  locationDetails.area ? ', ' : ''
                }${locationDetails.city}, ${locationDetails.state}`}
            </FwTextPrimary>
          </FwTextPrimary>
        </View>
      </Card.Content>
    </Card>
  );
};

export default RenderIncidentItem;