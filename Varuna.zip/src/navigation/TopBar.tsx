import React from 'react';
import {StyleSheet} from 'react-native';
import {Appbar} from 'react-native-paper';
import {COLORS} from '../constants/colors';
import {LanguageString} from '../constants/data';
import {useDispatch} from 'react-redux';
import {changeIncidentHeader, showDialog} from '../store/appSlice';
import {ICONS, IMAGES} from '../assets';
import FwLanguagePicker from '../elements/FwLanguagePicker';
interface TopBarProps {
  navigation: any;
  routeName: string;
}

const TopBar = ({navigation, routeName}: TopBarProps) => {
  const dispatch = useDispatch();
  const handleLanguageChange = () => {
    dispatch(showDialog());
  };
  const handleBack = () => {
    navigation.goBack();
    dispatch(changeIncidentHeader(false));
  };
  return (
    <>
      <Appbar.Header style={styles.appbar}>
        <Appbar.BackAction onPress={() => handleBack()} />
        <Appbar.Content title={LanguageString(routeName)} />
        <Appbar.Action
          icon={() => <FwLanguagePicker />}
          onPress={() => handleLanguageChange()}
        />
      </Appbar.Header>
    </>
  );
};
export default TopBar;
const styles = StyleSheet.create({
  appbar: {
    backgroundColor: COLORS.SECONDARY,
  },
});
