import React from 'react';
import {Card, Paragraph} from 'react-native-paper';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';

import {View} from 'react-native';
import {COLORS} from '../../constants/colors';
import {LanguageString} from '../../constants/data';
import {commonStyle} from '../../constants/theme';

const TicketsSummary = ({data}: {data: any}) => {
  return (
    <Card style={commonStyle.card}>
      <Card.Content>
        <View style={commonStyle.cardContainer}>
          <View style={{...commonStyle.metric, justifyContent: 'flex-start'}}>
            <Icon name="ticket-confirmation" size={36} color={COLORS.ERROR} />
            <Paragraph style={commonStyle.metricValue}>
              {data.ticketsSummary.critical}
            </Paragraph>
            <Paragraph>{LanguageString('Critical')}</Paragraph>
          </View>
          <View style={{...commonStyle.metric, justifyContent: 'flex-start'}}>
            <Icon
              name="ticket-confirmation"
              size={36}
              color={COLORS.DARKORANGE}
            />
            <Paragraph style={commonStyle.metricValue}>
              {data.ticketsSummary.highPriority}
            </Paragraph>
            <Paragraph>{LanguageString('HighPriority')}</Paragraph>
          </View>
          <View style={{...commonStyle.metric, justifyContent: 'flex-start'}}>
            <Icon name="ticket-confirmation" size={36} color={COLORS.WARNING} />
            <Paragraph style={commonStyle.metricValue}>
              {data.ticketsSummary.mediumPriority}
            </Paragraph>
            <Paragraph>{LanguageString('MediumPriority')}</Paragraph>
          </View>
          <View style={{...commonStyle.metric, justifyContent: 'flex-start'}}>
            <Icon
              name="ticket-confirmation"
              size={36}
              color={COLORS.DARKYELLOW}
            />
            <Paragraph style={commonStyle.metricValue}>
              {data.ticketsSummary.lowPriority}
            </Paragraph>
            <Paragraph>{LanguageString('LowPriority')}</Paragraph>
          </View>
        </View>
      </Card.Content>
    </Card>
  );
};
export default TicketsSummary;
