import React from 'react';
import {Card, Paragraph} from 'react-native-paper';
import {View} from 'react-native';
import {ICONS} from '../../assets';
import {COLORS} from '../../constants/colors';
import {LanguageString} from '../../constants/data';
import {commonStyle} from '../../constants/theme';
import { normalized } from '../../constants/platform';

const PumpingStation = ({data, renderIcon}: {data: any; renderIcon: any}) => {
  const pumpingStationData = [
    {
      value: data?.pumpingStationCount,
      label: 'Total Pumps'
    },
    {
      value: 124,
      label: 'MobilePumps'
    }
  ];

  return (
    <Card style={commonStyle.card}>
      <Card.Content>
        <View style={commonStyle.cardContainer}>
          {pumpingStationData.map((station, index) => (
            <View 
              key={index} 
              style={{...commonStyle.metric, justifyContent: 'flex-start'}}
            >
              {renderIcon(ICONS.PUMPINGSTATION, COLORS.PRIMARY)}
              <Paragraph style={commonStyle.metricTitle}>
                {station.value}
              </Paragraph>
              <Paragraph style={{...commonStyle.metricValue, fontSize: normalized(12)}}>
                {LanguageString(station.label)}
              </Paragraph>
            </View>
          ))}
        </View>
      </Card.Content>
    </Card>
  );
};
export default PumpingStation;
