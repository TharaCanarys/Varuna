import React from 'react';
import {
  FwButtonPrimary,
  FwTextInputPrimary,
  FwTextPrimary,
  FwTextSecondary,
} from '../../elements';
import {LanguageString} from '../../constants/data';
import {StyleSheet} from 'react-native';
import {normalized} from '../../constants/platform';
import {COLORS} from '../../constants/colors';
import {TextInput} from 'react-native-paper';
interface CreatePasswordModalProps {
  updateFormState: (field: string, value: string) => void;
  formState: {
    email: string;
    phone: number | string;
    password: string;
    confirmPassword: string;
  };
  // validateConfirmPassword: (password: string, confirmPassword: string) => void;
  updateUiState: (field: string, value: boolean) => void;
  uiState: {
    showPassword: boolean;
    showConfirmPassword: boolean;
    isFormValid: boolean;
    handleCreateAccount: () => void;
  };
  // validatePassword: (password: string) => void;
  errorState: any;
}
const CreatePasswordModal = ({
  formState,
  //   validatePassword,
  //   validateConfirmPassword,
  uiState,
  errorState,
  updateFormState,
  updateUiState,
}: CreatePasswordModalProps) => {
  const validatePassword = (password: string) => {
    if (!password) {
      errorState.passwordError =
        LanguageString('Password') + ' ' + LanguageString('is required');
    } else if (password.length < 6) {
      errorState.passwordError = LanguageString(
        'Password must be at least 6 characters long',
      );
    } else {
      errorState.passwordError = '';
    }
  };
  const validateConfirmPassword = (confirmPassword: string) => {
    if (!confirmPassword) {
      errorState.confirmPasswordError =
        LanguageString('Confirm Password') +
        ' ' +
        LanguageString('is required');
    } else if (confirmPassword !== formState.password) {
      errorState.confirmPasswordError = LanguageString(
        'Passwords do not match',
      );
    } else {
      errorState.confirmPasswordError = '';
    }
  };
  return (
    <>
      <FwTextInputPrimary
        label={LanguageString('Mobile Number')}
        value={formState.phone.toString()}
        mode="outlined"
        disabled={true}
        style={styles.inputField}
      />

      <FwTextInputPrimary
        label={LanguageString('Password')}
        value={formState.password}
        mode="outlined"
        onChangeText={(text: string) => {
          updateFormState('password', text);
          validatePassword(text);
        }}
        secureTextEntry={!uiState.showPassword}
        error={!!errorState.passwordError}
        right={
          <TextInput.Icon
            icon={uiState.showPassword ? 'eye' : 'eye-off'}
            onPress={() => updateUiState('showPassword', !uiState.showPassword)}
          />
        }
        style={styles.inputField}
      />
      {errorState.passwordError ? (
        <FwTextPrimary style={styles.errorText}>
          {errorState.passwordError}
        </FwTextPrimary>
      ) : null}

      <FwTextInputPrimary
        label={LanguageString('Confirm Password')}
        value={formState.confirmPassword}
        mode="outlined"
        onChangeText={(text: string) => {
          updateFormState('confirmPassword', text);
          validateConfirmPassword(text);
        }}
        secureTextEntry={!uiState.showConfirmPassword}
        error={!!errorState.confirmPasswordError}
        right={
          <TextInput.Icon
            icon={uiState.showConfirmPassword ? 'eye' : 'eye-off'}
            onPress={() =>
              updateUiState('showConfirmPassword', !uiState.showConfirmPassword)
            }
          />
        }
        style={styles.inputField}
      />
       <FwTextInputPrimary
        label={LanguageString('Email')}
        value={formState.email}
        mode="outlined"
        onChangeText={(text: string) => {
          updateFormState('email', text);
          // validateEmail(text);
        }}
        error={!!errorState.emailError}
        style={styles.inputField}
      />
      {errorState.emailError ? (
        <FwTextPrimary style={styles.errorText}>
          {errorState.emailError}
        </FwTextPrimary>
      ) : null}
      {errorState.confirmPasswordError ? (
        <FwTextPrimary style={styles.errorText}>
          {errorState.confirmPasswordError}
        </FwTextPrimary>
      ) : null}
      <FwButtonPrimary
        mode="contained"
        onPress={uiState.handleCreateAccount}
        style={styles.signupBtnStyle}>
        <FwTextSecondary type="buttonText">
          {LanguageString('Submit')}
        </FwTextSecondary>
      </FwButtonPrimary>
     
    </>
  );
};export default CreatePasswordModal;

const styles = StyleSheet.create({
  inputField: {
    marginBottom: normalized(20),
  },
  signupBtnStyle: {
    marginTop: normalized(20),
    minWidth: normalized(200),
    alignSelf: 'center',
  },
  errorText: {
    color: COLORS.ERROR,
    marginBottom: normalized(10),
  },
});
