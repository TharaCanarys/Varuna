import React from 'react';
import {Card} from 'react-native-paper';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import {FwTextPrimary} from '../../elements';
import {LanguageString} from '../../constants/data';
import {Platform, View, TextStyle, ViewStyle} from 'react-native';
import {normalized} from '../../constants/platform';
import {COLORS} from '../../constants/colors';
import {ICONS} from '../../assets';
import FwImage from '../../elements/FwImage';
import {useSelector} from 'react-redux';
import {RootState} from '../../store/store';

interface FloodDataComponentProps {
  styles: any;
}

const FloodDataComponent = ({styles}: FloodDataComponentProps) => {
  const floodData = useSelector((state: RootState) => state.app.floodData);

  const renderIcon = (icon: any, color: string) => (
    <FwImage
      source={icon}
      style={{
        width: 20,
        height: 20,
        tintColor: color,
        ...(Platform.OS === 'ios' ? {resizeMode: 'contain'} : {}),
      }}
    />
  );

  return (
    <Card style={styles.card}>
      <Card.Content>
        <FwTextPrimary style={styles.cardTitle}>
          {LanguageString('Flood Details')}
        </FwTextPrimary>

        <FwTextPrimary style={styles.cardTitle}>
          {LanguageString('Areas Flooded')}
        </FwTextPrimary>
        {floodData?.top3HotspotLocations?.map(
          (location: any, index: number) => (
            <View key={index} style={styles.detailRow}>
              <MaterialCommunityIcons
                name="map-marker-alert"
                size={normalized(20)}
                color={COLORS.PRIMARY}
              />
              <FwTextPrimary style={styles.detailText}>
                {location.locationName}:
              </FwTextPrimary>
              <FwTextPrimary style={styles.valueText}>
                {Number(location.latestReading).toFixed(2)}
              </FwTextPrimary>
            </View>
          ),
        )}

        <FwTextPrimary style={styles.cardTitle}>
          {LanguageString('Nalas Affected')}
        </FwTextPrimary>
        {floodData?.top3NalaLocations?.map((location: any, index: number) => (
          <View key={index} style={styles.detailRow}>
            <MaterialCommunityIcons
              name="pipe"
              size={normalized(20)}
              color={COLORS.PRIMARY}
            />
            <FwTextPrimary style={styles.detailText}>
              {location.locationName}:
            </FwTextPrimary>
            <FwTextPrimary style={styles.valueText}>
              {Number(location.latestReading).toFixed(2)}
            </FwTextPrimary>
          </View>
        ))}

        <FwTextPrimary style={styles.cardTitle}>
          {LanguageString('Impacted Sump Wells')}
        </FwTextPrimary>
        {floodData?.top3PumpingStations?.map((station: any, index: number) => (
          <View key={index} style={styles.detailRow}>
            {renderIcon(ICONS.TANK, COLORS.PRIMARY)}
            <FwTextPrimary style={styles.detailText}>
              {station.locationName}:
            </FwTextPrimary>
            <FwTextPrimary style={styles.valueText}>
              {Number(station.latestReading).toFixed(2)}
            </FwTextPrimary>
          </View>
        ))}
        
        <FwTextPrimary style={styles.cardTitle}>
          {LanguageString('Affected Locations')}
        </FwTextPrimary>
        {floodData?.affectedLocations?.map((location: any, index: number) => (
          <View key={index} style={styles.detailRow}>
            {renderIcon(ICONS.TANK, COLORS.PRIMARY)}
            <FwTextPrimary style={styles.detailText}>
              {location.locationName}:
            </FwTextPrimary>
            <FwTextPrimary style={styles.valueText}>
              {Number(location.percentageWater).toFixed(2)}%
            </FwTextPrimary>
          </View>
        ))}
      </Card.Content>
    </Card>
  );
};

export default FloodDataComponent;
