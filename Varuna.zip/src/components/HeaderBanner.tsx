import {IMAGES} from '../assets';
import {COLORS} from '../constants/colors';
import {StyleSheet, View} from 'react-native';
import {FwTextPrimary} from '../elements';
import {normalized} from '../constants/platform';
import DateComponent from './DateComponent';
import FwImage from '../elements/FwImage';

export const HeaderBanner = () => (
  <View style={styles.banner}>
    <FwImage source={IMAGES.UP_GOV_LOGO} style={styles.logo} />
    <View style={styles.bannerTextContainer}>
      <FwTextPrimary style={styles.bannerHindiText}>
        शहरी बाढ़ चेतावनी प्रणाली
      </FwTextPrimary>
      <FwTextPrimary style={styles.bannerText}>
        Urban Flood Early Warning System
      </FwTextPrimary>
    </View>
    <FwImage source={IMAGES.JALKAL_LOGO} style={styles.logo} />
  </View>
);

const styles = StyleSheet.create({
  banner: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: COLORS.PRIMARY,
    height: normalized(70),
  },
  logo: {
    width: normalized(50),
    height: normalized(50),
    marginHorizontal: normalized(10),
    borderRadius: normalized(50),
  },
  bannerTextContainer: {
    flex: 1,
    marginHorizontal: normalized(10),
  },
  bannerText: {
    color: COLORS.SECONDARY,
    fontSize: normalized(13.5),
    fontWeight: 'bold',
    textAlign: 'center',
  },
  bannerHindiText: {
    color: COLORS.SECONDARY,
    fontSize: normalized(20),
    fontWeight: 'bold',
    textAlign: 'center',
  },
});
