import React from 'react';
import {
  FwButtonPrimary,
  FwButtonSecondary,
  FwTextInputPrimary,
  FwTextPrimary,
  FwTextSecondary,
} from '../../elements';
import {TextInput} from 'react-native-paper';
import {LanguageString} from '../../constants/data';

const RenderNewPassword = ({
  formState,
  updateFormState,
  validateNewPassword,
  modalState,
  errorState,
  uiState,
  updateUiState,
  validateConfirmNewPassword,
  handleSetNewPassword,
  closeNewPasswordModal,
  styles,
}: any) => {
  return (
    <>
      <FwTextPrimary type="title_2" style={styles.modalTitle}>
        {LanguageString('Set New Password')}
      </FwTextPrimary>
      <FwTextInputPrimary
        label={LanguageString('New Password')}
        value={formState.newPassword}
        onChangeText={(text: string) => {
          updateFormState('newPassword', text);
          validateNewPassword(text);
        }}
        secureTextEntry={!modalState.showNewPassword}
        style={styles.input}
        error={!!errorState.newPasswordError}
        right={
          <TextInput.Icon
            icon={modalState.showNewPassword ? 'eye' : 'eye-off'}
            onPress={() => updateUiState('showNewPassword', true)}
          />
        }
      />
      {errorState.newPasswordError ? (
        <FwTextPrimary style={styles.errorText}>
          {errorState.newPasswordError}
        </FwTextPrimary>
      ) : null}
      <FwTextInputPrimary
        label={LanguageString('Confirm Password')}
        value={formState.confirmNewPassword}
        onChangeText={(text: string) => {
          updateFormState('confirmNewPassword', text);
          validateConfirmNewPassword(text);
        }}
        secureTextEntry={!uiState.showConfirmNewPassword}
        style={styles.input}
        error={!!errorState.confirmNewPasswordError}
        right={
          <TextInput.Icon
            icon={uiState.showConfirmNewPassword ? 'eye' : 'eye-off'}
            onPress={() =>
              updateUiState(
                'showConfirmNewPassword',
                !uiState.showConfirmNewPassword,
              )
            }
          />
        }
      />
      {errorState.confirmNewPasswordError ? (
        <FwTextPrimary style={styles.errorText}>
          {errorState.confirmNewPasswordError}
        </FwTextPrimary>
      ) : null}
      <FwButtonPrimary
        mode="contained"
        disabled={formState.newPassword == '' ? true : false}
        style={styles.modalButton}
        onPress={handleSetNewPassword}>
        <FwTextSecondary type="buttonText">
          {LanguageString('Save')}
        </FwTextSecondary>
      </FwButtonPrimary>
      <FwButtonSecondary
        mode="outlined"
        style={styles.modalButton}
        onPress={closeNewPasswordModal}>
        <FwTextPrimary type="buttonText">
          {LanguageString('Cancel')}
        </FwTextPrimary>
      </FwButtonSecondary>
    </>
  );
};

export default RenderNewPassword;
