import React, {useCallback, useMemo} from 'react';
import {View, StyleSheet, RefreshControl, FlatList} from 'react-native';
import {COLORS} from '../../constants/colors';
import {FwButtonPrimary, FwDialog, FwTextPrimary} from '../../elements';
import PageHeader from '../../components/PageHeader';
import {PAGES} from '../../components/pages';
import {AlertScreenViewProps, AlertTypes} from '../../types/alertTypes';
import {LanguageString, USER_ROLES} from '../../constants/data';
import {commonStyle} from '../../constants/theme';
import {useSelector} from 'react-redux';
import {RootState} from '../../store/store';
import {AlertItem, AlertDetailsModal, AddAlertModal} from '../../components';
import {normalized} from '../../constants/platform';

const AlertScreenView = ({
  newAlert,
  setNewAlert,
  alerts,
  selectedAlert,
  newStatus,
  setNewStatus,
  startEditingStatus,
  openAlertDetails,
  closeAlertDetails,
  editingStatus,
  saveStatus,
  openAddNewAlert,
  isAddingNewAlert,
  closeAddNewAlert,
  errors,
  refreshing,
  validateStatus,
  onRefresh,
  deleteConfirmationVisible,
  handleAddNewAlert,
  setDeleteConfirmationVisible,
  setAlertToDelete,
  alertToDelete,
  setAlerts,
}: AlertScreenViewProps) => {
  // Memoize options to prevent unnecessary re-renders
  const statusAOptions = [
    {label: LanguageString('Active'), value: 'Active'},
    {label: LanguageString('Resolved'), value: 'Resolved'},
  ];
  const role = useSelector((state: RootState) => state.auth.userRole);

  const validateRole =
    role == USER_ROLES.ADMIN ||
    role == USER_ROLES.SUPER_ADMIN ||
    role == USER_ROLES.IT_SUPPORT;
  const sensorAOptions = [
    {
      label: LanguageString('AWLR') + ' 1',
      value: LanguageString('AWLR') + ' 1',
    },
    {
      label: LanguageString('AWLR') + ' 2',
      value: LanguageString('AWLR') + ' 2',
    },
    {
      label: LanguageString('AWLR') + ' 3',
      value: LanguageString('AWLR') + ' 3',
    },
    {
      label: LanguageString('AWLR') + ' 4',
      value: LanguageString('AWLR') + ' 4',
    },
  ];

  const severityAOptions = [
    {label: LanguageString('High'), value: 'High'},
    {label: LanguageString('Medium'), value: 'Medium'},
    {label: LanguageString('Low'), value: 'Low'},
  ];

  const alertTypeOptions = [
    {label: LanguageString('Flood'), value: 'Flood'},
    {label: LanguageString('Nala Block'), value: 'Nala Block'},
  ];

  // Optimize renderItem with useCallback
  // Open delete confirmation dialog
  const openDeleteDialog = useCallback((delAlert: any) => {
    setAlertToDelete(delAlert);
    setDeleteConfirmationVisible(true);
  }, []);

  const renderItem = useCallback(
    ({item: alert}: {item: AlertTypes}) => (
      <AlertItem
        alert={alert}
        openAlertDetails={openAlertDetails}
        openDeleteDialog={openDeleteDialog}
        validateRole={validateRole}
        startEditingStatus={startEditingStatus}
      />
    ),
    [openAlertDetails, startEditingStatus],
  );

  // Optimize onSelect callbacks with useCallback
  const onSelectStatus = useCallback(
    (value: string | undefined) => {
      if (value !== undefined) {
        setNewStatus(value);
        validateStatus(value);
      }
    },
    [setNewStatus, validateStatus],
  );

  const onSelectSensor = useCallback(
    (value: string | undefined) => {
      if (value !== undefined) {
        setNewAlert(prevAlert => ({...prevAlert, sensor: value}));
      }
    },
    [setNewAlert],
  );

  const onSelectSeverity = useCallback(
    (value: string | undefined) => {
      if (value !== undefined) {
        setNewAlert(prevAlert => ({...prevAlert, severity: value}));
      }
    },
    [setNewAlert],
  );
  const onSelectAlertType = useCallback(
    (value: string | undefined) => {
      if (value !== undefined) {
        setNewAlert(prevAlert => ({...prevAlert, alertType: value}));
      }
    },
    [setNewAlert],
  );

  const onSelectNewAlertStatus = useCallback(
    (value: string | undefined) => {
      if (value !== undefined) {
        setNewAlert(prevAlert => ({...prevAlert, status: value}));
      }
    },
    [setNewAlert],
  );

  // // Confirm sensor deletion

  const hideDeleteConfirmation = () => {
    setDeleteConfirmationVisible(false);
    setAlertToDelete(null);
  };

  // Delete alert
  const handleDeleteAlert = useCallback((alert: AlertTypes) => {
    setAlerts(prevAlerts => prevAlerts.filter(a => a.id !== alert.id));
    hideDeleteConfirmation();
  }, []);

  return (
    <>
      <PageHeader title={PAGES.ALERTS} />
      <View style={commonStyle.addButtonContainer}>
        {validateRole ? (
          <FwButtonPrimary
            mode="outlined"
            onPress={openAddNewAlert}
            icon="plus">
            <FwTextPrimary>{LanguageString('Add New')}</FwTextPrimary>
          </FwButtonPrimary>
        ) : null}
      </View>
      <FlatList
        data={alerts}
        renderItem={renderItem}
        keyExtractor={item => item.id.toString()}
        contentContainerStyle={styles.container}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
        }
      />

      {/* Alert Details Modal */}
      <AlertDetailsModal
        selectedAlert={selectedAlert}
        closeAlertDetails={closeAlertDetails}
        startEditingStatus={startEditingStatus}
        editingStatus={editingStatus}
        saveStatus={saveStatus}
        newStatus={newStatus}
        validateRole={validateRole}
        statusAOptions={statusAOptions}
        onSelectStatus={onSelectStatus}
      />
      {/* Add New Alert Modal */}
      <AddAlertModal
        isAddingNewAlert={isAddingNewAlert}
        closeAddNewAlert={closeAddNewAlert}
        newAlert={newAlert}
        sensorAOptions={sensorAOptions}
        severityAOptions={severityAOptions}
        alertTypeOptions={alertTypeOptions}
        onSelectSensor={onSelectSensor}
        onSelectSeverity={onSelectSeverity}
        onSelectAlertType={onSelectAlertType}
        errors={errors}
        handleAddNewAlert={handleAddNewAlert}
        statusAOptions={statusAOptions}
        onSelectNewAlertStatus={onSelectNewAlertStatus}
      />

      {/* Delete Confirmation Dialog */}
      <FwDialog
        visible={deleteConfirmationVisible}
        hideDialog={hideDeleteConfirmation}
        title={LanguageString('Delete this Alert?')}>
        <FwButtonPrimary mode="outlined" onPress={hideDeleteConfirmation}>
          <FwTextPrimary>{LanguageString('Cancel')}</FwTextPrimary>
        </FwButtonPrimary>
        <FwButtonPrimary
          mode="outlined"
          onPress={() => handleDeleteAlert(alertToDelete)}>
          <FwTextPrimary>{LanguageString('Delete')}</FwTextPrimary>
        </FwButtonPrimary>
      </FwDialog>
    </>
  );
};

// Styles remain unchanged
const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
    padding: normalized(16),
    backgroundColor: COLORS.OFF_WHITE,
  },

  modalContainer: {
    backgroundColor: COLORS.BG_WHITE,
    padding: normalized(24),
    margin: normalized(24),
    borderRadius: 8,
    elevation: 4,
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: normalized(24),
  },
  modalTitle: {
    fontSize: normalized(21),
    fontWeight: 'bold',
    letterSpacing: 1,
    marginBottom: normalized(10),
    marginLeft: normalized(5),
    color: COLORS.BLACK,
  },
  closeButton: {
    marginTop: normalized(24),
  },
  modalContent: {
    color: COLORS.BLACK,
    lineHeight: normalized(24),
  },
  dropdownContainer: {
    marginTop: normalized(16),
    marginLeft: normalized(20),
  },
  input: {
    marginBottom: normalized(8),
  },
});

export default AlertScreenView;
