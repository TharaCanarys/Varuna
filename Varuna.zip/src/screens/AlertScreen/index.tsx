import React, {useCallback, useEffect, useMemo, useState} from 'react';
import AlertScreenView from './AlertScreenView';
import {alertData, AlertTypes} from '../../types/alertTypes';
import {LanguageString} from '../../constants/data';
import {PAGES} from '../../components/pages';
import {useSelector} from 'react-redux';
import {RootState} from '../../store/store';

const AlertScreen: React.FC = () => {
  const [newStatus, setNewStatus] = useState('');
  const [refreshing, setRefreshing] = useState(false);
  const [editingStatus, setEditingStatus] = useState(false);
  const [selectedAlert, setSelectedAlert] = useState<AlertTypes | null>(null);
  const [alerts, setAlerts] = useState<AlertTypes[]>(alertData);
  const [isAddingNewAlert, setIsAddingNewAlert] = useState(false);
  const [statusError, setStatusError] = useState('');
  const [isDatePickerVisible, setDatePickerVisibility] = useState(false);

  const [deleteConfirmationVisible, setDeleteConfirmationVisible] =
    useState(false);
  const [alertToDelete, setAlertToDelete] = useState<number | null>(null);

  const [newAlert, setNewAlert] = useState<AlertTypes>({
    id: 0,
    sensor: '',
    severity: '',
    status: '',
    createdDate: '',
    alertType: '',
  });

  const [errors, setErrors] = useState({
    sensor: '',
    severity: '',
    status: '',
    createdDate: '',
    alertType: '',
  });

  const closeAlertDetails = () => {
    setSelectedAlert(null);
    setEditingStatus(false);
  };
  const openAlertDetails = (alert: AlertTypes) => {
    setSelectedAlert(alert);
    setNewStatus(alert.status);
  };
  const startEditingStatus = () => {
    setEditingStatus(!editingStatus);
  };
  const openAddNewAlert = () => {
    setIsAddingNewAlert(true);
  };
  const validateStatus = (newStatus: string) => {
    if (!newStatus) {
      setStatusError('Status is required');
    } else {
      setStatusError('');
    }
  };
  const language = useSelector(
    (state: RootState) => state.app.selectedLanguage,
  );
  useEffect(() => {
    setAlerts(alertData);
  }, []);

  const onRefresh = useCallback(() => {
    setRefreshing(true);
    setAlerts(alertData);
    setRefreshing(false);
  }, []);

  const closeAddNewAlert = () => {
    setIsAddingNewAlert(false);
    setNewAlert({
      id: 0,
      sensor: '',
      severity: '',
      status: '',
      createdDate: '',
      alertType: '',
    });
    setErrors({
      sensor: '',
      severity: '',
      status: '',
      createdDate: '',
      alertType: '',
    });
  };
  const saveStatus = () => {
    if (selectedAlert) {
      const updatedAlerts = alerts.map(alert =>
        alert.id === selectedAlert.id ? {...alert, status: newStatus} : alert,
      );
      setAlerts(updatedAlerts);
      setSelectedAlert({...selectedAlert, status: newStatus});
      setEditingStatus(false);
    }
  };

  const validateNewAlert = () => {
    let isValid = true;
    const newErrors = {
      sensor: '',
      severity: '',
      createdDate: '',
      status: '',
      alertType: '',
    };

    if (!newAlert.sensor) {
      newErrors.sensor =
        LanguageString(PAGES.SENSOR) + ' ' + LanguageString('is required');
      isValid = false;
    }

    if (!newAlert.severity) {
      newErrors.severity =
        LanguageString('Severity') + ' ' + LanguageString('is required');
      isValid = false;
    }

    if (!newAlert.alertType) {
      newErrors.alertType =
        LanguageString('Alert Type') + ' ' + LanguageString('is required');
      isValid = false;
    }

    if (!newAlert.status) {
      newErrors.status =
        LanguageString('Status') + ' ' + LanguageString('is required');
      isValid = false;
    }

    setErrors(newErrors);
    return isValid;
  };

  const handleAddNewAlert = () => {
    if (validateNewAlert()) {
      const newId = Math.max(...alerts.map(s => s.id)) + 1;
      const alertToAdd = {...newAlert, id: newId};
      setAlerts([...alerts, alertToAdd]);
      closeAddNewAlert();
    }
  };

  const showDatePicker = () => {
    setDatePickerVisibility(true);
  };

  const hideDatePicker = () => {
    setDatePickerVisibility(false);
  };

  // Handle date change
  const handleConfirm = useCallback((selectedDate: Date) => {
    const indianTime = new Date(selectedDate.getTime() + 5.5 * 60 * 60 * 1000);
    setNewAlert(prev => ({
      ...prev,
      createdDate: indianTime.toISOString().slice(0, 19).replace('T', ' '),
    }));
    setDatePickerVisibility(false);
  }, []);
  // Close the modal when the screen loses focus

  const AlertScreenViewProps = useMemo(
    () => ({
      newAlert,
      setNewAlert,
      newStatus,
      setNewStatus,
      editingStatus,
      selectedAlert,
      startEditingStatus,
      alerts,
      saveStatus,
      closeAlertDetails,
      openAlertDetails,
      openAddNewAlert,
      isAddingNewAlert,
      refreshing,
      closeAddNewAlert,
      onRefresh,
      validateStatus,
      errors,
      isDatePickerVisible,
      deleteConfirmationVisible,
      showDatePicker,
      setDeleteConfirmationVisible,
      handleAddNewAlert,
      handleConfirm,
      hideDatePicker,
      setAlertToDelete,
      alertToDelete,
      setAlerts,
    }),
    [
      newAlert,
      setNewAlert,
      newStatus,
      setNewStatus,
      editingStatus,
      selectedAlert,
      startEditingStatus,
      alerts,
      saveStatus,
      closeAlertDetails,
      openAlertDetails,
      openAddNewAlert,
      isAddingNewAlert,
      refreshing,
      closeAddNewAlert,
      onRefresh,
      validateStatus,
      errors,
      isDatePickerVisible,
      deleteConfirmationVisible,
      showDatePicker,
      setDeleteConfirmationVisible,
      handleAddNewAlert,
      handleConfirm,
      hideDatePicker,
      setAlertToDelete,
      alertToDelete,
      setAlerts,
    ],
  );

  return <AlertScreenView {...AlertScreenViewProps} />;
};
export default AlertScreen;
