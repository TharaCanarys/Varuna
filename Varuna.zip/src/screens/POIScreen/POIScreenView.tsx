import React, {useCallback, useMemo} from 'react';
import {ScrollView, View, StyleSheet, RefreshControl} from 'react-native';

import {FwButtonPrimary, FwDialog, FwTextPrimary} from '../../elements';
import {POIScreenProps} from '../../types/commonTypes';
import {LanguageString, USER_ROLES} from '../../constants/data';
import {COLORS} from '../../constants/colors';
import PageHeader from '../../components/PageHeader';
import {commonStyle} from '../../constants/theme';
import {useSelector} from 'react-redux';
import {RootState} from '../../store/store';
import {normalized} from '../../constants/platform';
import {PoiDetailsComponent} from '../../components';
import AddPoiComponent from '../../components/POIComponents/AddPoiComponent';
import FwModal from '../../elements/FwModal';
import PoiCardComponent from '../../components/POIComponents/PoiCardComponent';
import Loader from '../../components/loader';

// Main component for the POI Screen
const POIScreenView = ({
  selectedPOI,
  refreshing,
  pois,
  newStatus,
  setNewStatus,
  editingStatus,
  isAddingNewPOI,
  newPOI,
  setNewPOI,
  errors,
  openPOIDetails,
  onRefresh,
  startEditingStatus,
  handleDeletePOI,
  openAddNewPOI,
  closePOIDetails,
  validateStatus,
  saveStatus,
  closeAddNewPOI,
  handleAddNewPOI,
  language,
  isLoading,
}: POIScreenProps) => {
  // State for delete confirmation dialog
  const [showDeleteDialog, setShowDeleteDialog] = React.useState(false);
  const [poiToDelete, setPOIToDelete] = React.useState(null);
  const elevationOptions = [
    {label: LanguageString('Low lying'), value: 'Low lying'},
    {label: LanguageString('Moderate'), value: 'Moderate'},
    {label: LanguageString('High'), value: 'High'},
  ];
  const floodRiskLevelOptions = [
    {label: LanguageString('Low'), value: 0},
    {label: LanguageString('Medium'), value: 1},
    {label: LanguageString('High'), value: 2},
    {label: LanguageString('Critical'), value: 3},
  ];
  const statusOptions = [
    {label: LanguageString('Active'), value: 'Active'},
    {label: LanguageString('Resolved'), value: 'Resolved'},
  ];
  const networkOptions = [
    {label: LanguageString('Religious'), value: 'Religious'},
    {label: LanguageString('Educational'), value: 'Educational'},
    {label: LanguageString('Health Care'), value: 'Health Care'},
    {label: LanguageString('VIP'), value: 'VIP'},
    {label: LanguageString('Shopping Areas'), value: 'Shopping Areas'},
    {label: LanguageString('Residential'), value: 'Residential'},
    {label: LanguageString('Industrial'), value: 'Industrial'},
    {label: LanguageString('Commercial'), value: 'Commercial'},
  ];
  const locationOptions = [
    {label: LanguageString('Golghar'), value: 'Golghar'},
    {label: LanguageString('Mohaddipur'), value: 'Mohaddipur'},
    {label: LanguageString('Gorakhnath'), value: 'Gorakhnath'},
    {label: LanguageString('Shahpur'), value: 'Shahpur'},
    {label: LanguageString('Rapti Nagar'), value: 'Rapti Nagar'},
  ];
  // Open delete confirmation dialog
  const openDeleteDialog = useCallback((poi: any) => {
    setPOIToDelete(poi);
    setShowDeleteDialog(true);
  }, []);

  // Close delete confirmation dialog
  const closeDeleteDialog = useCallback(() => {
    setShowDeleteDialog(false);
    setPOIToDelete(null);
  }, []);
  const role = useSelector((state: RootState) => state.auth.userRole);

  const validateRole =
    role == USER_ROLES.ADMIN ||
    role == USER_ROLES.SUPER_ADMIN ||
    role == USER_ROLES.IT_SUPPORT;
  // Confirm poi deletion
  const confirmDelete = useCallback(() => {
    if (poiToDelete) {
      handleDeletePOI(poiToDelete);
    }
    closeDeleteDialog();
  }, [poiToDelete, handleDeletePOI, closeDeleteDialog]);

  // Render individual poi card
  const renderPOICard = useCallback(
    (poi: any, index: number) => (
      <React.Fragment key={poi.poiID}>
        {isLoading ? (
          <Loader />
        ) : (
          <PoiCardComponent
            index={poi.poiID}
            styles={styles}
            openPOIDetails={openPOIDetails}
            poi={poi}
            validateRole={validateRole}
            startEditingStatus={startEditingStatus}
            openDeleteDialog={openDeleteDialog}
          />
        )}
      </React.Fragment>
    ),
    [openPOIDetails, startEditingStatus, openDeleteDialog],
  );
  // Render a message if no pois
  const poiCards = useMemo(() => {
    if (pois?.length === 0) {
      return (
        <FwTextPrimary style={styles.poiCardText}>
          No Point of Interest founds
        </FwTextPrimary>
      );
    }
    return pois?.map(renderPOICard);
  }, [pois, renderPOICard]);

  // Render poi details modal content
  const renderPOIDetails = useCallback(
    () => (
      <PoiDetailsComponent
        selectedPOI={selectedPOI}
        validateRole={validateRole}
        startEditingStatus={startEditingStatus}
        language={language}
        editingStatus={editingStatus}
        newStatus={newStatus}
        setNewStatus={setNewStatus}
        validateStatus={validateStatus}
        saveStatus={saveStatus}
        closePOIDetails={closePOIDetails}
      />
    ),
    [
      selectedPOI,
      editingStatus,
      newStatus,
      startEditingStatus,
      setNewStatus,
      validateStatus,
      saveStatus,
      closePOIDetails,
    ],
  );

  // Render add new poi modal content
  const renderAddNewPOI = useCallback(
    () => (
      <AddPoiComponent
        locationOptions={locationOptions}
        newPOI={newPOI}
        setNewPOI={setNewPOI}
        errors={errors}
        elevationOptions={elevationOptions}
        networkOptions={networkOptions}
        statusOptions={statusOptions}
        floodRiskLevelOptions={floodRiskLevelOptions}
        handleAddNewPOI={handleAddNewPOI}
        closeAddNewPOI={closeAddNewPOI}
      />
    ),
    [newPOI, errors, setNewPOI, handleAddNewPOI, closeAddNewPOI, language],
  );

  // Main render function
  return (
    <>
      <PageHeader title={LanguageString('POI')} />
      <View style={commonStyle.addButtonContainer}>
        <FwButtonPrimary mode="outlined" onPress={openAddNewPOI} icon="plus">
          <FwTextPrimary>{LanguageString('Add New')}</FwTextPrimary>
        </FwButtonPrimary>
      </View>

      <ScrollView
        style={styles.container}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
        }>
        {poiCards}
      </ScrollView>
      {/* POI Details Modal */}
      <FwModal
        visible={selectedPOI !== null}
        onDismiss={closePOIDetails}
        contentContainerStyle={styles.modalContainer}>
        {selectedPOI && renderPOIDetails()}
      </FwModal>
      {/* Add New POI Modal */}
      <FwModal
        visible={isAddingNewPOI}
        onDismiss={closeAddNewPOI}
        contentContainerStyle={styles.modalContainer}>
        {renderAddNewPOI()}
      </FwModal>
      {/* Delete Confirmation Dialog */}
      {/* Delete Confirmation Dialog box */}
      <FwDialog
        visible={showDeleteDialog}
        hideDialog={closeDeleteDialog}
        title={LanguageString('Delete this POI?')}>
        <FwButtonPrimary mode="outlined" onPress={closeDeleteDialog}>
          <FwTextPrimary>{LanguageString('Cancel')}</FwTextPrimary>
        </FwButtonPrimary>
        <FwButtonPrimary mode="outlined" onPress={confirmDelete}>
          <FwTextPrimary>{LanguageString('Delete')}</FwTextPrimary>
        </FwButtonPrimary>
      </FwDialog>
    </>
  );
};

// Styles for the component
const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: normalized(16),
    backgroundColor: COLORS.OFF_WHITE,
  },
  title: {
    fontSize: normalized(24),
    fontWeight: 'bold',
    marginBottom: normalized(16),
    color: COLORS.BLACK,
  },
  subtitle: {
    fontSize: normalized(18),
    marginBottom: normalized(16),
    color: COLORS.BLACK,
  },
  poiCard: {
    marginBottom: normalized(16),
    elevation: 2,
    backgroundColor: COLORS.BG_WHITE,
  },
  cardText: {
    color: COLORS.BLACK,
  },

  cardContent: {
    marginLeft: normalized(58),
    marginTop: normalized(-16),
  },
  modalContainer: {
    backgroundColor: COLORS.BG_WHITE,
    padding: normalized(24),
    margin: normalized(24),
    borderRadius: normalized(8),
    elevation: normalized(4),
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: normalized(24),
  },
  modalTitle: {
    fontSize: normalized(20),
    fontWeight: 'bold',
    color: COLORS.BLACK,
  },
  cardImage: {
    width: 40,
    height: 40,
    marginRight: normalized(16),
    marginTop: normalized(80),
  },
  cardImageIcon: {
    width: normalized(40),
    height: normalized(40),
    marginRight: normalized(16),
    marginTop: normalized(15),
  },

  dropdownContainer: {
    marginTop: normalized(16),
    marginLeft: normalized(20),
  },
  input: {
    marginBottom: normalized(8),
  },
  cardActions: {
    flexDirection: 'row',
  },

  poiCardText: {
    color: COLORS.BLACK,
  },
});

export default POIScreenView;
