import React, {useRef} from 'react';
import {View, StyleSheet, Dimensions} from 'react-native';
import {WebView} from 'react-native-webview';

const IMDMapScreen: React.FC = () => {
  const webViewRef = useRef<WebView | null>(null); // Reference for WebView

  const hideNavbarScript = `
    document.querySelector('nav')?.remove();
    document.querySelector('.navbar')?.remove();
    document.querySelector('header')?.remove();
    document.querySelector('.logos-container').style.display = 'none';
    true;
  `;
  const onLoadEnd = () => {
    // Inject the JavaScript to hide elements after the page has loaded
    if (webViewRef.current) {
      webViewRef.current.injectJavaScript(hideNavbarScript); // Ensure it's injected on iOS too
    }
  };
  return (
    <View style={styles.container}>
      <WebView
        ref={webViewRef} // Reference to the WebView component
        source={{uri: 'https://ufews.com:8085/Home/IMDMaps'}}
        style={styles.webview}
        javaScriptEnabled={true} // Enable JavaScript
        domStorageEnabled={true} // Enable DOM storage
        startInLoadingState={true} // Show a loading state initially
        injectedJavaScript={hideNavbarScript} // Inject the JavaScript on page load
        onLoadEnd={onLoadEnd} // Inject script on load end
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  webview: {
    width: Dimensions.get('window').width,
    height: Dimensions.get('window').height,
  },
});

export default IMDMapScreen;
