import axios from 'axios';
import {ALL_URLS} from '../constants/urls';
import {TaskTypes, TaskStatus, TaskHistoryTypes} from '../types/commonTypes';

interface ApiResponse<T> {
  data: T;
  status: number;
  statusText: string;
}

interface User {
  id: number;
  name: string;
}



export const createTask = async (task: TaskTypes): Promise<ApiResponse<TaskTypes>> => {
  try {
    const response = await axios.post(ALL_URLS.CREATE_TASK, task);
    return {
      data: response.data,
      status: response.status,
      statusText: response.statusText
    };
  } catch (error) {
    console.error('Error creating task:', error);
    throw error;
  }
};

export const updateTask = async (task: TaskTypes): Promise<ApiResponse<TaskTypes>> => {
  try {
    const response = await axios.put(ALL_URLS.UPDATE_TASK, task);
    return {
      data: response.data,
      status: response.status,
      statusText: response.statusText
    };
  } catch (error) {
    console.error('Error updating task:', error);
    throw error;
  }
};

export const deleteTask = async (taskId: number): Promise<ApiResponse<void>> => {
  try {
    const response = await axios.delete(`${ALL_URLS.DELETE_TASK}/${taskId}`);
    return {
      data: undefined,
      status: response.status,
      statusText: response.statusText
    };
  } catch (error) {
    console.error('Error deleting task:', error);
    throw error;
  }
};
