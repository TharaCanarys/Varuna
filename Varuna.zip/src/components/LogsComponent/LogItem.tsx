import React from 'react';
import {LanguageString} from '../../constants/data';
import {Avatar, Card, Title} from 'react-native-paper';
import {StyleSheet, View} from 'react-native';
import {commonStyle} from '../../constants/theme';
import {FwTextPrimary} from '../../elements';
import {COLORS} from '../../constants/colors';
import {normalized} from '../../constants/platform';

const LogItem = ({item, showModal, getSeverityStyle}: any) => {
  return (
    <Card style={styles.logsCard} onPress={() => showModal(item)}>
      <Card.Content>
        <View style={styles.cardContent}>
          <Avatar.Icon
            size={40}
            icon="file-clock-outline"
            style={styles.icon}
          />
          <View style={styles.cardDetails}>
            <View style={styles.headerRow}>
              <FwTextPrimary style={commonStyle.boldText}>
                {LanguageString('ID') + ' '}:
              </FwTextPrimary>
              <FwTextPrimary style={styles.normalText}>
                {LanguageString(item.logId)}
              </FwTextPrimary>
              <FwTextPrimary
                style={
                  [
                    styles.status,
                    LanguageString(item.status) === LanguageString('Success')
                      ? styles.success
                      : styles.error,
                  ] as any
                }>
                {LanguageString(LanguageString(item.status))}
              </FwTextPrimary>
            </View>
            <Title style={styles.title}>{LanguageString(item.initiator)}</Title>
            <View style={styles.detailsContainer}>
              <FwTextPrimary style={commonStyle.normalText}>
                {LanguageString('Time')}: {LanguageString(item.loggedTime)}
              </FwTextPrimary>
              <View style={styles.tagContainer}>
                <FwTextPrimary
                  style={
                    [
                      styles.tag,
                      getSeverityStyle(LanguageString(item.severity)),
                    ] as any
                  }>
                  {LanguageString(LanguageString(item.severity))}
                </FwTextPrimary>
                <FwTextPrimary style={[styles.tag, styles.category] as any}>
                  {LanguageString(LanguageString(item.category))}
                </FwTextPrimary>
              </View>
            </View>
          </View>
        </View>
      </Card.Content>
    </Card>
  );
};
export default LogItem;

const styles = StyleSheet.create({
  logsCard: {
    marginBottom: normalized(12),
    elevation: 2,
  },
  cardContent: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  icon: {
    marginRight: normalized(12),
    backgroundColor: '#E3F2FD',
  },
  cardDetails: {
    flex: 1,
  },
  headerRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: normalized(8),
  },
  normalText: {color: COLORS.BLACK, flex: 4, letterSpacing: 1.2, fontSize: 15},
  logId: {
    fontWeight: 'bold',
    color: COLORS.LIGHTGRAY,
  },
  status: {
    fontWeight: 'bold',
  },
  tag: {
    paddingHorizontal: normalized(8),
    paddingVertical: 2,
    borderRadius: normalized(4),
    overflow: 'hidden',
  },
  title: {
    color: COLORS.PRIMARY,
  },
  success: {
    color: COLORS.MEDIUMGREEN,
  },
  error: {
    color: COLORS.ERROR,
  },
  detailsContainer: {
    marginTop: normalized(8),
  },
  category: {
    backgroundColor: COLORS.OFF_WHITE,
    color: COLORS.BLUE,
  },
  tagContainer: {
    flexDirection: 'row',
    marginTop: normalized(8),
    gap: normalized(8),
  },
});
