import React from 'react';
import {AppState, StyleSheet, View} from 'react-native';
import {Card} from 'react-native-paper';
import FwImage from '../../elements/FwImage';
import {FwTextPrimary} from '../../elements';
import {LanguageString} from '../../constants/data';
import {commonStyle} from '../../constants/theme';
import {ICONS} from '../../assets';
import {COLORS} from '../../constants/colors';
import {normalized} from '../../constants/platform';
import {MaintenancePropTypes} from '../../types/commonTypes';
import { useSelector } from 'react-redux';

interface MaintenanceCardComponentProps {
  index: number;
  maintenance: MaintenancePropTypes;
  openMaintenanceDetails: (maintenance: MaintenancePropTypes) => void;
}
const MaintenanceCardComponent = ({
  index,
  maintenance,
  openMaintenanceDetails,
}: MaintenanceCardComponentProps) => {
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    const day = date.getDate().toString().padStart(2, '0');
    const month = date.toLocaleString('default', { month: 'short' });
    const year = date.getFullYear();
    return `${day}/${month}/${year}`;
  };

  const users = useSelector((state: AppState) => state.app.users?.data);

  // Find user name based on technician ID
  const getUserName = (assignedUserID: number): string => { 
    const user = users?.find((user: any) => user.userID === assignedUserID);
    return user ? LanguageString(user.userName) : LanguageString('Unknown');
  };

  return (
    <Card
      key={index}
      style={styles.maintenanceCard}
      onPress={() => openMaintenanceDetails(maintenance)}>
      <Card.Title
        title={LanguageString('Maintenance') + ' ' + maintenance?.maintenanceID}
        titleStyle={commonStyle.cardHeaderText}
        left={() => (
          <View style={styles.cardImage}>
            <FwImage source={ICONS.MAINTENANCE} style={styles.cardImageIcon} />
          </View>
        )}
        right={props => (
          <View style={styles.cardActions}>
          </View>
        )}
      />
      <Card.Content style={commonStyle.cardContent}>
        <View style={commonStyle.modalRow}>
          <FwTextPrimary style={commonStyle.boldText}>
            {LanguageString('Scheduled Date') + ' : '}
          </FwTextPrimary>
          <FwTextPrimary style={commonStyle.normalText}>
            {formatDate(maintenance?.scheduledDate.toString())}
          </FwTextPrimary>
        </View>
        
        <View style={commonStyle.modalRow}>
          <FwTextPrimary style={commonStyle.boldText}>
            {LanguageString('Assigned To') + ' : '}
          </FwTextPrimary>
          <FwTextPrimary style={commonStyle.normalText}>
          {getUserName(maintenance?.assignedUserID)}
          </FwTextPrimary>
        </View>
        <View style={commonStyle.modalRow}>
          <FwTextPrimary style={commonStyle.boldText}>
            {LanguageString('Due Date') + ' : '}
          </FwTextPrimary>
          <FwTextPrimary style={commonStyle.normalText}>
            {formatDate(maintenance?.dueDate.toString())}
          </FwTextPrimary>
        </View>
        <View style={commonStyle.modalRow}>
          <FwTextPrimary style={commonStyle.boldText}>
            {LanguageString('Status') + ' : '}
          </FwTextPrimary>
          <FwTextPrimary style={commonStyle.normalText}>
            {LanguageString(maintenance?.status.toString())}
          </FwTextPrimary>
        </View>
      </Card.Content>
    </Card>
  );
};

export default MaintenanceCardComponent;

const styles = StyleSheet.create({
  maintenanceCardText: {
    color: COLORS.BLACK,
  },

  cardImage: {
    width: normalized(50),
    height: normalized(50),
    borderRadius: normalized(50),
    marginRight: normalized(16),
    marginTop: normalized(50),
  },
  cardImageIcon: {
    width: normalized(50),
    height: normalized(50),
    borderRadius: normalized(50),
    marginRight: normalized(16),
    marginTop: normalized(10),
  },
  cardActions: {
    flexDirection: 'row',
  },
  maintenanceCard: {
    marginBottom: normalized(16),
    elevation: normalized(2),
    backgroundColor: COLORS.BG_WHITE,
  },
});