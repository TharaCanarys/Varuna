import React, {useState} from 'react';
import {
  Card,
  Paragraph,
  Button,
  RadioButton,
  Divider,
} from 'react-native-paper';
import {View, Dimensions, StyleSheet, ScrollView} from 'react-native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import {LineChart} from 'react-native-chart-kit';
import {ICONS} from '../../assets';
import {COLORS} from '../../constants/colors';
import {LanguageString} from '../../constants/data';
import {commonStyle} from '../../constants/theme';
import {normalized} from '../../constants/platform';

const screenWidth = Dimensions.get('window').width;
const chartDimension = screenWidth / 1.2;

type SummaryMetricsProps = {
  data: any;
  renderIcon: (icon: any, color: string) => JSX.Element;
};

const SummaryMetrics: React.FC<SummaryMetricsProps> = ({data, renderIcon}) => {
  const [chartType, setChartType] = useState<'daily' | 'weekly' | 'monthly'>(
    'daily',
  );

  const rainfallData = {
    daily: {
      actual: [5.2, 8.4, 12.6, 15.8, 7.3, 3.1, 9.5],
      predicted: [6.8, 10.1, 14.2, 13.9, 9.5, 2.8, 11.2],
      labels: [
        LanguageString('Mon'),
        LanguageString('Tue'),
        LanguageString('Wed'),
        LanguageString('Thu'),
        LanguageString('Fri'),
        LanguageString('Sat'),
        LanguageString('Sun'),
      ],
    },
    weekly: {
      actual: [45.2, 62.8, 83.5, 55.7],
      predicted: [52.3, 71.4, 75.8, 64.9],
      labels: [
        LanguageString('Week') + ' 1',
        LanguageString('Week') + ' 2',
        LanguageString('Week') + ' 3',
        LanguageString('Week') + ' 4',
      ],
    },
    monthly: {
      actual: [182.4, 229.6, 348.2, 287.5, 156.8, 98.3],
      predicted: [165.2, 248.7, 312.4, 305.8, 142.3, 115.9],
      labels: [
        LanguageString('Jan'),
        LanguageString('Feb'),
        LanguageString('Mar'),
        LanguageString('Apr'),
        LanguageString('May'),
        LanguageString('Jun'),
      ],
    },
  };
  const chartConfig = {
    backgroundGradientFrom: '#ffffff',
    backgroundGradientTo: '#f8f9fa',
    decimalPlaces: 1,
    color: (opacity = 1) => `rgba(66, 133, 244, ${opacity})`,
    labelColor: (opacity = 1) => `rgba(51, 51, 51, ${opacity})`,
    style: {borderRadius: normalized(16)},
    propsForDots: {
      r: normalized(6),
      strokeWidth: 2,
      stroke: '#ffffff',
    },
    propsForBackgroundLines: {
      strokeDasharray: '',
      strokeWidth: 0.5,
    },
    propsForLabels: {
      fontSize: normalized(10),
      fontWeight: '600',
    },
  };

  const renderChart = () => {
    const currentData = rainfallData[chartType];

    return (
      <LineChart
        data={{
          labels: currentData.labels,
          datasets: [
            {
              data: currentData.actual,
              color: (opacity = 1) => `rgba(66, 133, 244, ${opacity})`,
              strokeWidth: normalized(5),
            },
            {
              data: currentData.predicted,
              color: (opacity = 1) => `rgba(25, 135, 84, ${opacity})`,
              strokeWidth: normalized(5),
            },
          ],
          legend: [
            LanguageString('Actual Rainfall'),
            LanguageString('Predicted Rainfall'),
          ],
        }}
        width={chartDimension}
        height={chartDimension}
        chartConfig={chartConfig}
        style={{
          ...styles.chart,
          marginVertical: normalized(8),
          shadowColor: '#000',
          shadowOffset: {
            width: normalized(0),
            height: normalized(2),
          },
          shadowOpacity: 0.25,
          shadowRadius: normalized(3.84),
          elevation: normalized(5),
        }}
        bezier
        withInnerLines={true}
        withOuterLines={true}
        withVerticalLines={true}
        withHorizontalLines={true}
        withVerticalLabels={true}
        withHorizontalLabels={true}
        fromZero={true}
        segments={5}
        yAxisSuffix=" mm"
      />
    );
  };
  return (
    <Card style={commonStyle.card}>
      <Card.Content>
        <View style={commonStyle.cardContainer}>
          <View style={commonStyle.metric}>
            {renderIcon(ICONS.RAINFALLICON, COLORS.PRIMARY)}
            <Paragraph style={commonStyle.metricTitle}>
              {data?.dashboardDataCount?.waterLevelBreachCountByStation ?? null}{' '}
              {data?.summaryMetrics?.rainfall ? 'mm' : ''}
            </Paragraph>
            <Paragraph style={commonStyle.metricValue}>
              {LanguageString('Water level (>=80%)')}
            </Paragraph>
          </View>
          <View style={commonStyle.metric}>
            <Icon
              name="access-point"
              size={normalized(36)}
              color={COLORS.PRIMARY}
            />
            <Paragraph style={commonStyle.metricTitle}>
              {data?.dashboardDataCount?.awlrSensorCount ?? null}
            </Paragraph>
            <Paragraph style={commonStyle.metricValue}>
              {LanguageString("Active AWLR's")}
            </Paragraph>
          </View>
          <View style={commonStyle.metric}>
            {renderIcon(ICONS.PUMP, COLORS.PRIMARY)}
            <Paragraph style={commonStyle.metricTitle}>
              {data?.dashboardDataCount?.pumpCountByStation ?? null}
            </Paragraph>
            <Paragraph style={commonStyle.metricValue}>
              {LanguageString('Pump Ready')}
            </Paragraph>
          </View>
          <View style={commonStyle.metric}>
            <Icon
              name="check-circle"
              size={normalized(36)}
              color={COLORS.SUCCESS}
            />
            <Paragraph style={commonStyle.metricTitle}>
              {data?.dashboardDataCount?.completedTaskCount ?? null} /{' '}
              {data?.dashboardDataCount?.createdTaskCount ?? null}
            </Paragraph>
            <Paragraph style={commonStyle.metricValue}>
              {LanguageString('Tasks')}
            </Paragraph>
          </View>
        </View>

        {/* Chart Section */}
        <Divider style={{marginVertical: normalized(10)}} />
      </Card.Content>
      {/* <Paragraph style={styles.heading}>
        {LanguageString('Rainfall Data')}
      </Paragraph>  
      <RadioButton.Group
        onValueChange={value =>
          setChartType(value as 'daily' | 'weekly' | 'monthly')
        }
        value={chartType}>
        <View style={styles.radioContainer}>
          <View style={styles.radioButton}>
            <RadioButton.Android value="daily" />
            <Paragraph>{LanguageString('Daily')}</Paragraph>
          </View>
          <View style={styles.radioButton}>
            <RadioButton.Android value="weekly" />
            <Paragraph>{LanguageString('Weekly')}</Paragraph>
          </View>
          <View style={styles.radioButton}>
            <RadioButton.Android value="monthly" />
            <Paragraph>{LanguageString('Monthly')}</Paragraph>
          </View>
        </View>
      </RadioButton.Group>
      <ScrollView horizontal style={{marginHorizontal: normalized(5)}}>
        {renderChart()}
      </ScrollView> */}
    </Card>
  );
};

const styles = StyleSheet.create({
  chart: {
    borderRadius: normalized(16),
    backgroundColor: '#ffffff',
    padding: normalized(10),
    // marginLeft: -20,
  },
  radioContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'center',
    marginTop: normalized(10),
  },
  radioButton: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  heading: {
    fontSize: normalized(16),
    fontWeight: 'bold',
    marginLeft: normalized(16),
    marginTop: normalized(10),
    color: COLORS.PRIMARY,
  },
});

export default SummaryMetrics;
