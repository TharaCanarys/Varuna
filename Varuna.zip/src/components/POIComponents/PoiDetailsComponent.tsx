import React from 'react';
import {StyleSheet, View} from 'react-native';
import {ScrollView} from 'react-native';
import {FwButtonPrimary, FwTextPrimary, FwTextSecondary} from '../../elements';
import {LanguageString} from '../../constants/data';
import {IconButton} from 'react-native-paper';
import {commonStyle} from '../../constants/theme';
import FWDropdown from '../../elements/FwDropdown';
import {COLORS} from '../../constants/colors';
import {normalized} from '../../constants/platform';

interface PoiDetailsComponentProps {
  selectedPOI: any;
  validateRole: boolean;
  startEditingStatus: any;
  language: string;
  editingStatus: boolean;
  newStatus: any;
  setNewStatus: any;
  validateStatus: any;
  saveStatus: any;
  closePOIDetails: any;
}

const PoiDetailsComponent = ({
  selectedPOI,
  validateRole,
  startEditingStatus,
  language,
  editingStatus,
  newStatus,
  setNewStatus,
  validateStatus,
  saveStatus,
  closePOIDetails,
}: PoiDetailsComponentProps) => {
  const statusOptions = [
    {label: LanguageString('Active'), value: 'Active'},
    {label: LanguageString('Resolved'), value: 'Resolved'},
  ];
  return (
    <ScrollView>
      {selectedPOI && (
        <View style={commonStyle.modalHeader}>
          <FwTextSecondary style={commonStyle.modalTitle}>
            {LanguageString('Point Of Interest')} {LanguageString('Details')}
          </FwTextSecondary>
          {validateRole ? (
            <IconButton
              icon="pencil"
              size={24}
              onPress={startEditingStatus}
              disabled={selectedPOI.poiStatus === 'Resolved'}
            />
          ) : null}
        </View>
      )}
      {selectedPOI && (
        <View>
          <View style={commonStyle.modalRow}>
            <FwTextPrimary style={commonStyle.boldText}>
              {LanguageString('Location')}:
            </FwTextPrimary>
            <FwTextPrimary style={commonStyle.normalText}>
              {LanguageString(selectedPOI.location)}
            </FwTextPrimary>
          </View>
          <View style={commonStyle.modalRow}>
            <FwTextPrimary style={commonStyle.boldText}>
              {LanguageString('POI') + ' ' + LanguageString('Name')} :
            </FwTextPrimary>
            <FwTextPrimary style={commonStyle.normalText}>
              {LanguageString(selectedPOI.poiName)}
            </FwTextPrimary>
          </View>

          {/* <View style={commonStyle.modalRow}>
            <FwTextPrimary style={commonStyle.boldText}>
              {LanguageString('Elevation')} :
            </FwTextPrimary>
            <FwTextPrimary style={commonStyle.normalText}>
              {LanguageString(selectedPOI.elevation)}
            </FwTextPrimary>
          </View> */}
          <View style={commonStyle.modalRow}>
            <FwTextPrimary style={commonStyle.boldText}>
              {LanguageString('POI Type')} :
            </FwTextPrimary>
            <FwTextPrimary style={commonStyle.normalText}>
              {LanguageString(selectedPOI.network)}
            </FwTextPrimary>
          </View>
          <View style={commonStyle.modalRow}>
            <FwTextPrimary style={commonStyle.boldText}>
              {LanguageString('Flood Risk Level')} :
            </FwTextPrimary>
            <FwTextPrimary style={commonStyle.normalText}>
              {LanguageString(selectedPOI.floodRiskLevel)}
            </FwTextPrimary>
          </View>
          {/* <View
            style={{
              flexDirection: 'row',
              marginVertical: 8,
              paddingTop: language === 'hi' ? 10 : 0,
            }}>
            <FwTextPrimary style={commonStyle.boldText}>
              {LanguageString('Adjescent POIs') + ' '}:
            </FwTextPrimary>
            <FwTextPrimary style={commonStyle.normalText}>
              {LanguageString(selectedPOI.adjescentPois)}
            </FwTextPrimary>
          </View> */}
          {!editingStatus && (
            <View style={{flexDirection: 'row', marginVertical: 8}}>
              <FwTextPrimary style={commonStyle.boldText}>
                {LanguageString('POI') + ' ' + LanguageString('Status')} :
              </FwTextPrimary>
              <FwTextPrimary
                style={{
                  ...commonStyle.normalText,
                  color:
                    selectedPOI.poiStatus === 'Active'
                      ? COLORS.SUCCESS
                      : COLORS.ERROR,
                }}>
                {LanguageString(selectedPOI.poiStatus)}
              </FwTextPrimary>
            </View>
          )}
        </View>
      )}
      {editingStatus && (
        <View style={{marginHorizontal: 16}}>
          <FWDropdown
            multiple={false}
            label={LanguageString('POI') + ' ' + LanguageString('Status')}
            options={statusOptions}
            value={newStatus}
            onSelect={(value: string | undefined) => {
              if (value !== undefined) {
                setNewStatus(value);
                validateStatus(value);
              }
            }}
          />
        </View>
      )}
      {editingStatus && (
        <FwButtonPrimary onPress={saveStatus} style={commonStyle.saveButton}>
          <FwTextSecondary>{LanguageString('Save')}</FwTextSecondary>
        </FwButtonPrimary>
      )}
      <FwButtonPrimary
        onPress={closePOIDetails}
        style={commonStyle.closeButton}>
        <FwTextSecondary>{LanguageString('Cancel')}</FwTextSecondary>
      </FwButtonPrimary>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContent: {
    color: COLORS.BLACK,
    lineHeight: normalized(24),
  },
});
export default PoiDetailsComponent;
