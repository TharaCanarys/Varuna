import React from 'react';
import {StyleSheet, View} from 'react-native';
import {FlatList} from 'react-native';
import {
  FwButtonPrimary,
  FwTextInputPrimary,
  FwTextPrimary,
  FwTextSecondary,
} from '../../elements';
import {LanguageString} from '../../constants/data';
import FWDropdown from '../../elements/FwDropdown';
import {HelperText} from 'react-native-paper';
import DateTimePickerModal from 'react-native-modal-datetime-picker';
import {normalized} from '../../constants/platform';
import {COLORS} from '../../constants/colors';
import {MaintenancePropTypes} from '../../types/commonTypes';
import {commonStyle} from '../../constants/theme';
import FwDateTimePicker from '../../elements/FwDateTimePicker';

interface AddMaintenanceComponentProps {
  newMaintenance: MaintenancePropTypes;
  setNewMaintenance: (maintenance: MaintenancePropTypes) => void;
  errors: {
    status: string;
    location: string;
    maintenanceType: string;
    description: string;
    scheduledDate: string;
    dueDate: string;
    completedDate: string;
    Technician: string;
    Remarks: string;
    assetsType: string;
  };
  setActiveDateField: (field: string) => void;
  setShowDatePicker: (show: boolean) => void;
  showDatePicker: boolean;
  handleDateChange: (date: Date) => void;
  handleAddNewMaintenance: () => void;
  closeAddNewMaintenance: () => void;
}
const AddMaintenanceComponent = ({
  newMaintenance,
  setNewMaintenance,
  errors,
  setActiveDateField,
  setShowDatePicker,
  showDatePicker,
  handleDateChange,
  handleAddNewMaintenance,
  closeAddNewMaintenance,
}: AddMaintenanceComponentProps) => {
  const locationOptions = [
    {label: LanguageString('Golghar'), value: 'Golghar'},
    {label: LanguageString('Mohaddipur'), value: 'Mohaddipur'},
    {label: LanguageString('Gorakhnath'), value: 'Gorakhnath'},
    {label: LanguageString('Shahpur'), value: 'Shahpur'},
    {label: LanguageString('Rapti Nagar'), value: 'Rapti Nagar'},
  ];
  const maintenanceTypeOptions = [
    {label: LanguageString('Routine'), value: 'Routine'},
    {label: LanguageString('Emergency'), value: 'Emergency'},
    {label: LanguageString('Inspection'), value: 'Inspection'},
    {label: LanguageString('Repair'), value: 'Repair'},
  ];
  const statusOptions = [
    {label: LanguageString('Assigned'), value: 'Assigned'},
    {label: LanguageString('Scheduled'), value: 'Scheduled'},
    {label: LanguageString('In progress'), value: 'In progress'},
    {label: LanguageString('Cancelled'), value: 'Cancelled'},
    {label: LanguageString('Overdue'), value: 'Overdue'},
  ];
  const technicianOptions = [
    {label: LanguageString('Rajesh'), value: 'Rajesh'},
    {label: LanguageString('Ramesh'), value: 'Ramesh'},
    {label: LanguageString('Suresh'), value: 'Suresh'},
  ];
  const assetsTypeOptions = [
    {label: LanguageString('Pumping Station'), value: 'Pumping Station'},
    {label: LanguageString('Drainage'), value: 'Drainage'},
  ];

  return (
    <FlatList
      data={[1]}
      renderItem={() => (
        <>
          <View style={commonStyle.modalHeader}>
            <FwTextPrimary style={commonStyle.modalTitle}>
              {LanguageString('Add New Maintenance')}
            </FwTextPrimary>
          </View>
          <FWDropdown
            multiple={false}
            label={LanguageString('Select Location')}
            options={locationOptions}
            value={newMaintenance?.location}
            onSelect={(value: string | undefined) => {
              if (value !== undefined) {
                setNewMaintenance({...newMaintenance, location: value});
              }
            }}
          />
          <HelperText type="error" visible={!!errors.location}>
            {errors.location}
          </HelperText>
          <FWDropdown
            multiple={false}
            label={LanguageString('Select Maintenance Type')}
            options={maintenanceTypeOptions}
            value={newMaintenance?.maintenanceType}
            onSelect={(value: string | undefined) => {
              if (value !== undefined) {
                setNewMaintenance({
                  ...newMaintenance,
                  maintenanceType: value,
                });
              }
            }}
          />
          <HelperText type="error" visible={!!errors.maintenanceType}>
            {errors.maintenanceType}
          </HelperText>
          <FWDropdown
            multiple={false}
            label={LanguageString('Select Status')}
            options={statusOptions}
            value={newMaintenance?.status}
            onSelect={(value: string | undefined) => {
              if (value !== undefined) {
                setNewMaintenance({...newMaintenance, status: value});
              }
            }}
          />
          <HelperText type="error" visible={!!errors.status}>
            {errors.status}
          </HelperText>
          <FwTextInputPrimary
            label={LanguageString('Description')}
            value={newMaintenance?.description}
            onChangeText={(text: string) => {
              setNewMaintenance({...newMaintenance, description: text});
            }}
            style={{...styles.input, ...styles.descriptionInput}}
            placeholder={LanguageString('Enter description')}
          />
          <HelperText type="error" visible={!!errors.description}>
            {errors.description}
          </HelperText>
          <FwDateTimePicker
            isVisible={showDatePicker && showDatePicker}
            label="Due Date"
            onPress={() => {
              setShowDatePicker(true), setActiveDateField('dueDate');
            }}
            onConfirm={handleDateChange}
            onCancel={() => setShowDatePicker(false)}
            value={newMaintenance.dueDate}
            mode="date"
            minimumDate={new Date()}
          />
          <HelperText type="error" visible={!!errors.dueDate}>
            {errors.dueDate}
          </HelperText>
          <FwDateTimePicker
            isVisible={showDatePicker && showDatePicker}
            label="Completed Date"
            onPress={() => {
              setShowDatePicker(true), setActiveDateField('completedDate');
            }}
            onConfirm={handleDateChange}
            onCancel={() => setShowDatePicker(false)}
            value={newMaintenance?.completedDate}
            mode="date"
            minimumDate={new Date()}
          />

          <HelperText type="error" visible={!!errors.completedDate}>
            {errors.completedDate}
          </HelperText>
          <FWDropdown
            multiple={false}
            label={LanguageString('Select Technician')}
            options={technicianOptions}
            value={newMaintenance?.Technician}
            onSelect={(value: string | undefined) => {
              if (value !== undefined) {
                setNewMaintenance({...newMaintenance, Technician: value});
              }
            }}
          />
          <HelperText type="error" visible={!!errors.Technician}>
            {errors.Technician}
          </HelperText>
          <FwTextInputPrimary
            label={LanguageString('Remarks')}
            value={newMaintenance?.Remarks}
            onChangeText={(text: string) => {
              setNewMaintenance({...newMaintenance, Remarks: text});
            }}
            style={{...styles.input, ...styles.descriptionInput}}
            placeholder={LanguageString('Enter remarks')}
          />
          <HelperText type="error" visible={!!errors.Remarks}>
            {errors.Remarks}
          </HelperText>
          <FWDropdown
            multiple={false}
            label={LanguageString('Select Assets Type')}
            options={assetsTypeOptions}
            value={newMaintenance?.assetsType}
            onSelect={(value: string | undefined) => {
              if (value !== undefined) {
                setNewMaintenance({...newMaintenance, assetsType: value});
              }
            }}
          />
          <HelperText type="error" visible={!!errors.assetsType}>
            {errors.assetsType}
          </HelperText>
          {/* <DateTimePickerModal
            isVisible={showDatePicker}
            mode="date"
            onConfirm={handleDateChange}
            onCancel={() => setShowDatePicker(false)}
            display="inline"
          /> */}
          <FwButtonPrimary
            onPress={handleAddNewMaintenance}
            style={commonStyle.saveButton}>
            <FwTextSecondary>{LanguageString('Save')}</FwTextSecondary>
          </FwButtonPrimary>
          <FwButtonPrimary
            onPress={closeAddNewMaintenance}
            style={commonStyle.closeButton}>
            <FwTextSecondary>{LanguageString('Cancel')}</FwTextSecondary>
          </FwButtonPrimary>
        </>
      )}
      keyExtractor={() => 'key'}
    />
  );
};
export default AddMaintenanceComponent;

const styles = StyleSheet.create({
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: normalized(24),
  },
  modalTitle: {
    fontSize: normalized(20),
    fontWeight: 'bold',
    color: COLORS.BLACK,
  },
  input: {
    marginBottom: normalized(8),
    color: COLORS.SECONDARY,
    marginHorizontal: normalized(8),
  },
  descriptionInput: {
    height: normalized(80),
    textAlignVertical: 'top',
    marginHorizontal: normalized(8),
  },
});
