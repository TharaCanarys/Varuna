import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';
import { useTranslation } from 'react-i18next';
const resources = {
  en: { translation: require('./en.json') },
  hi: { translation: require('./hi.json') },
  // Add more languages here, if needed
};

i18n.use(initReactI18next).init({
  compatibilityJSON: 'v3',
  resources,
  lng: 'hi', // default language
  fallbackLng: 'en',
  interpolation: { escapeValue: false },
  initImmediate: false,
  react: { useSuspense: false },
});

export default i18n;