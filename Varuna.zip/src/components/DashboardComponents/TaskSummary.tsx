import React from 'react';
import {StyleSheet, View} from 'react-native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import {Card, Paragraph} from 'react-native-paper';
import {COLORS} from '../../constants/colors';
import {LanguageString} from '../../constants/data';
import {commonStyle} from '../../constants/theme';
import {normalized} from '../../constants/platform';

const TaskSummary = ({data}: {data: any}) => {
  const taskItems = [
    {
      icon: 'folder-open',
      color: COLORS.PRIMARY,
      value: data?.openTaskCount,
      label: 'Open'
    },
    {
      icon: 'account-check',
      color: COLORS.DARKYELLOW,
      value: data?.assignedTaskCount,
      label: 'Assigned'
    },
    {
      icon: 'progress-clock',
      color: COLORS.WARNING,
      value: data?.inProgressTaskCount,
      label: 'In progress'
    },
    {
      icon: 'check-circle-outline',
      color: COLORS.INFO,
      value: data?.acceptedTaskCount,
      label: 'Accepted'
    },
    {
      icon: 'check-circle',
      color: COLORS.SUCCESS,
      value: data?.completedTaskCount,
      label: 'Completed'
    },
    {
      icon: 'alert-circle',
      color: COLORS.ERROR,
      value: data?.escalationCount,
      label: 'Escalation'
    }
  ];

  return (
    <Card style={commonStyle.card}>
      <Card.Content>
        <View style={commonStyle.cardContainer}>
          {taskItems.map((item, index) => (
            <View key={index} style={[commonStyle.metric, styles.equalCard]}>
              <Icon name={item.icon} size={32} color={item.color} />
              <Paragraph style={commonStyle.metricTitle}>
                {item.value}
              </Paragraph>
              <Paragraph style={styles.metricValue}>
                {LanguageString(item.label)}
              </Paragraph>
            </View>
          ))}
        </View>
      </Card.Content>
    </Card>
  );
};

export default TaskSummary;

const styles = StyleSheet.create({
  metricValue: {
    fontSize: normalized(12),
    marginTop: normalized(8),
    textAlign: 'center',
  },
  equalCard: {
    flex: 1,
    justifyContent: 'flex-start',
    alignItems: 'center',
  }
});
