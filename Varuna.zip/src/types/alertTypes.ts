export interface AlertTypes {
  id: number;
  sensor: string;
  severity: string;
  status: string;
  createdDate: string;
  alertType: string;
}

export const alertData: AlertTypes[] = [
  {
    id: 1,
    sensor: 'Sensor',
    severity: 'High',
    status: 'Active',
    createdDate: '2023-05-15 10:30',
    alertType: 'Flood',
  },
  {
    id: 2,
    sensor: 'Sensor',
    severity: 'Medium',
    status: 'Resolved',
    createdDate: '2023-05-10 12:30',
    alertType: 'Nala Block',
  },
  {
    id: 3,
    sensor: 'Sensor',
    severity: 'Low',
    status: 'Active',
    createdDate: '2023-05-12 14:30',
    alertType: 'Flood',
  },
];

export interface AlertErrorTypes {
  sensor: string;
  severity: string;
  status: string;
  createdDate: string;
}

export interface AlertScreenViewProps {
  newAlert: AlertTypes;
  setNewAlert: React.Dispatch<React.SetStateAction<AlertTypes>>;
  editingStatus: boolean;
  selectedAlert: AlertTypes | null;
  startEditingStatus: () => void;
  alerts: AlertTypes[];
  newStatus: string;
  setNewStatus: React.Dispatch<React.SetStateAction<string>>;
  closeAlertDetails: () => void;
  openAlertDetails: (alert: AlertTypes) => void;
  saveStatus: () => void;
  refreshing: boolean;
  validateStatus: (status: string) => void;
  openAddNewAlert: () => void;
  closeAddNewAlert: () => void;
  isAddingNewAlert: boolean;
  errors: AlertErrorTypes;
  onRefresh: () => void;
  isDatePickerVisible: boolean;
  deleteConfirmationVisible: boolean;
  showDatePicker: () => void;
  handleAddNewAlert: () => void;
  handleConfirm: (selectedDate: Date) => void;
  hideDatePicker: () => void;
  setDeleteConfirmationVisible: React.Dispatch<React.SetStateAction<boolean>>;
  setAlertToDelete: React.Dispatch<React.SetStateAction<number | null>>;
  alertToDelete: any;
  setAlerts: React.Dispatch<React.SetStateAction<AlertTypes[]>>;
}
