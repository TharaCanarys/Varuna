import React from 'react';
import {StyleSheet} from 'react-native';
import {FwTextPrimary} from '../elements';
import {COLORS} from '../constants/colors';
import {View} from 'react-native';
import {LanguageString, width} from '../constants/data';
import {commonStyle} from '../constants/theme';
import {normalized} from '../constants/platform';
import {TranslatingData} from '../services/authService';

export default function PageHeader({title}: {title: string}) {
  const content = async () => {
    const translatedTitle = await TranslatingData(title, 'en');
    return translatedTitle;
  };
  content().then(translatedTitle => {});
  return (
    <View style={styles.container}>
      {/* <Appbar.Header>
                <Appbar.Content title={title} />
            </Appbar.Header> */}
      {/* <FwTextPrimary style={styles.title}>
        {LanguageString(title)} {LanguageString('Management')}
      </FwTextPrimary> */}
      <FwTextPrimary style={commonStyle.cardHeaderText}>
        {' '}
        {LanguageString(title)}{' '}
      </FwTextPrimary>
    </View>
  );
}
const styles = StyleSheet.create({
  container: {
    marginLeft: normalized(width * 0.05),
    marginRight: normalized(width * 0.05),
  },
  title: {
    paddingTop: width * 0.05,
    fontSize: normalized(21),
    fontWeight: 'bold',
    letterSpacing: 1,
    marginBottom: normalized(10),
    marginLeft: normalized(5),
    color: COLORS.BLACK,
  },
  subtitle: {
    fontSize: normalized(15),
    color: COLORS.BLACK,
  },
});
