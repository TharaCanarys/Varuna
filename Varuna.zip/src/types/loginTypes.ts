export interface LoginViewProps {
  formState: {
    email: string;
    password: string;
    otp: string;
    confirmMobile: string;
    newPassword: string;
    confirmNewPassword: string;
  };
  uiState: {
    showPassword: boolean;
    showNewPassword: boolean;
    showConfirmNewPassword: boolean;
    isLoading: boolean;
    timer: number;
  };
  modalState: {
    visible: boolean;
    otpModal: boolean;
    passwordModal: boolean;
    newPasswordModal: boolean;
    dialogTitle: string;
    dialogDescription: string;
  };
  errorState: {
    emailError: string;
    otpError: string;
    passwordError: string;
    confirmMobileError: string;
    newPasswordError: string;
    confirmNewPasswordError: string;
  };
  updateFormState: any;
  updateUiState: any;
  updateModalState: any;
  handleLoginSubmit: any;
  handleResetPasswordSubmit: any;
  handleVerifyOTPSubmit: any;
  handleSetNewPasswordSubmit: any;
  handleResendOTP: any;
  closePasswordModal: any;
  handleSignIn:any;
}
