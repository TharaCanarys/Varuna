import React, {useCallback, useMemo, useState} from 'react';
import {View, StyleSheet, RefreshControl, FlatList} from 'react-native';
import {FwButtonPrimary, FwDialog, FwTextPrimary} from '../../elements';
import {MaintenanceScreenProps} from '../../types/commonTypes';
import {LanguageString} from '../../constants/data';
import {COLORS} from '../../constants/colors';
import PageHeader from '../../components/PageHeader';
import {commonStyle} from '../../constants/theme';
import {normalized} from '../../constants/platform';
import {
  AddMaintenanceComponent,
  MaintenanceCardComponent,
  MaintenanceDetailsComponent,
} from '../../components';
import FwModal from '../../elements/FwModal';

// Main component for the Maintenance Screen
const MaintenanceScreenView = ({
  selectedMaintenance,
  refreshing,
  maintenances,
  newStatus,
  setNewStatus,
  editingStatus,
  isAddingNewMaintenance,
  newMaintenance,
  setNewMaintenance,
  errors,
  showDatePicker,
  setShowDatePicker,
  openMaintenanceDetails,
  onRefresh,
  startEditingStatus,
  // handleDeleteMaintenance,
  openAddNewMaintenance,
  closeMaintenanceDetails,
  validateStatus,
  saveStatus,
  closeAddNewMaintenance,
  handleAddNewMaintenance,
}: MaintenanceScreenProps) => {
  // State for delete confirmation dialog
  const [showDeleteDialog, setShowDeleteDialog] = React.useState(false);
  const [maintenanceToDelete, setMaintenanceToDelete] = React.useState(null);
  const [activeDateField, setActiveDateField] = useState('');

  // Open delete confirmation dialog
  const openDeleteDialog = useCallback((maintenance: any) => {
    setMaintenanceToDelete(maintenance.id);
    setShowDeleteDialog(true);
  }, []);

  // Close delete confirmation dialog
  const closeDeleteDialog = useCallback(() => {
    setShowDeleteDialog(false);
    setMaintenanceToDelete(null);
  }, []);

  // Confirm maintenance deletion
  // const confirmDelete = useCallback(() => {
  //   if (maintenanceToDelete) {
  //     handleDeleteMaintenance(maintenanceToDelete);
  //   }
  //   closeDeleteDialog();
  // }, [maintenanceToDelete, handleDeleteMaintenance, closeDeleteDialog]);

  // Handle date change
  const handleDateChange = useCallback(
    (date: Date) => {
      const formattedDate = date.toISOString().split('T')[0];
      setNewMaintenance({
        ...newMaintenance,
        [activeDateField]: formattedDate,
      });
      setShowDatePicker(false);
    },
    [activeDateField, setNewMaintenance],
  );

  // Render individual maintenance card
  const renderMaintenanceCard = useCallback(
    (maintenance: any, index: number) => (
      <MaintenanceCardComponent
        index={index}
        maintenance={maintenance}
        openMaintenanceDetails={openMaintenanceDetails}
      />
    ),
    [openMaintenanceDetails, startEditingStatus, openDeleteDialog],
  );

  // Render a message if no maintenances
  
  // Render maintenance details modal content
  const renderMaintenanceDetails = useCallback(
    () =>
      selectedMaintenance && (
        <MaintenanceDetailsComponent
          editingStatus={editingStatus}
          selectedMaintenance={selectedMaintenance}
          newStatus={newStatus}
          setNewStatus={setNewStatus}
          validateStatus={validateStatus}
          saveStatus={saveStatus}
          closeMaintenanceDetails={closeMaintenanceDetails}
        />
      ),
    [
      selectedMaintenance,
      editingStatus,
      newStatus,
      startEditingStatus,
      setNewStatus,
      validateStatus,
      saveStatus,
      closeMaintenanceDetails,
    ],
  );

  // Render add new maintenance modal content
  const renderAddNewMaintenance = useCallback(
    () => (
      <AddMaintenanceComponent
        newMaintenance={newMaintenance}
        setNewMaintenance={setNewMaintenance}
        errors={errors}
        setActiveDateField={setActiveDateField}
        setShowDatePicker={setShowDatePicker}
        showDatePicker={showDatePicker}
        handleDateChange={handleDateChange}
        handleAddNewMaintenance={handleAddNewMaintenance}
        closeAddNewMaintenance={closeAddNewMaintenance}
      />
    ),
    [
      newMaintenance,
      errors,
      showDatePicker,
      setNewMaintenance,
      setShowDatePicker,

      handleDateChange,
      handleAddNewMaintenance,
      closeAddNewMaintenance,
    ],
  );

  const isAnyModalActive = isAddingNewMaintenance || editingStatus == null;

  // Main render function
  return (
    <>
      <PageHeader title="Maintenance" />
      <View style={commonStyle.addButtonContainer}>
        {!isAnyModalActive && (
          <FwButtonPrimary
            mode="outlined"
            onPress={openAddNewMaintenance}
            icon="plus">
            <FwTextPrimary>{LanguageString('Add New')}</FwTextPrimary>
          </FwButtonPrimary>
        )}
      </View>
      <FlatList
        style={styles.container}
        data={maintenances?.data}
        renderItem={({item}) => renderMaintenanceCard(item, item?.id)}
        keyExtractor={item => item?.id?.toString()}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
        }
        ListEmptyComponent={
          <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
            <FwTextPrimary style={styles.maintenanceCardText}>
              {LanguageString(maintenances?.message)}
            </FwTextPrimary>
          </View>
        }
      />
      {/* Maintenance Details Modal */}
      <FwModal
        visible={selectedMaintenance !== null}
        onDismiss={closeMaintenanceDetails}
        contentContainerStyle={styles.modalContainer}>
        {selectedMaintenance && renderMaintenanceDetails()}
      </FwModal>
      {/* Add New Maintenance Modal */}
      <FwModal
        visible={isAddingNewMaintenance}
        onDismiss={closeAddNewMaintenance}
        contentContainerStyle={styles.modalContainer}>
        {renderAddNewMaintenance()}
      </FwModal>
      {/* Delete Confirmation Dialog box */}
      {/* <FwDialog
        visible={showDeleteDialog}
        hideDialog={closeDeleteDialog}
        title={LanguageString('Delete this Maintenance?')}>
        <FwButtonPrimary mode="outlined" onPress={closeDeleteDialog}>
          <FwTextPrimary>{LanguageString('Cancel')}</FwTextPrimary>
        </FwButtonPrimary>
        <FwButtonPrimary mode="outlined" onPress={confirmDelete}>
          <FwTextPrimary>{LanguageString('Delete')}</FwTextPrimary>
        </FwButtonPrimary>
      </FwDialog> */}
    </>
  );
};

// Styles for the component
const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: normalized(16),
    backgroundColor: COLORS.OFF_WHITE,
  },
  title: {
    fontSize: normalized(24),
    fontWeight: 'bold',
    marginBottom: normalized(16),
    color: COLORS.BLACK,
  },
  subtitle: {
    fontSize: normalized(18),
    marginBottom: normalized(16),
    color: COLORS.BLACK,
  },

  cardText: {
    color: COLORS.BLACK,
  },

  cardContent: {
    marginLeft: normalized(58),
    marginTop: normalized(-16),
  },
  modalContainer: {
    backgroundColor: COLORS.BG_WHITE,
    padding: normalized(24),
    margin: normalized(24),
    borderRadius: normalized(8),
    elevation: normalized(4),
  },

  modalTitle: {
    fontSize: normalized(20),
    fontWeight: 'bold',
    color: COLORS.BLACK,
  },
  closeButton: {
    marginTop: normalized(24),
  },
  modalContent: {
    color: COLORS.BLACK,
    lineHeight: normalized(24),
  },

  dropdownContainer: {
    marginTop: normalized(16),
    marginLeft: normalized(20),
  },
  maintenanceCardText: {
    color: COLORS.BLACK,
  },
});

export default MaintenanceScreenView;
