import React, {useCallback, useMemo, useState, useEffect} from 'react';
import {View, StyleSheet, RefreshControl, FlatList} from 'react-native';
import {Card} from 'react-native-paper';
import {useNavigation} from '@react-navigation/native';
import Icon from 'react-native-vector-icons/MaterialIcons';
import {useDispatch, useSelector} from 'react-redux';
import AsyncStorage from '@react-native-async-storage/async-storage';

import {FwButtonPrimary, FwTextPrimary, FwTextSecondary} from '../../elements';
import {LanguageString, notificationData} from '../../constants/data';
import {COLORS} from '../../constants/colors';
import {
  NotificationPropTypes,
  NotificationScreenProps,
} from '../../types/commonTypes';
import {commonStyle} from '../../constants/theme';
import {normalized} from '../../constants/platform';
import TopBar from '../../navigation/TopBar';
import {PAGES} from '../../components/pages';
import {RootState} from '../../store/store';
import FwModal from '../../elements/FwModal';
import {updateNotificationCount} from '../../store/appSlice';
import {getNotificationCount} from '../../services/authService';

const NotificationScreenView = ({
  refreshing,
  notifications,
  onRefresh,
}: NotificationScreenProps) => {
  const navigation = useNavigation();
  const dispatch = useDispatch();
  const [isModalVisible, setIsModalVisible] = useState(false);
  const [currentNotification, setCurrentNotification] =
    useState<NotificationPropTypes | null>(null);
  const [viewedNotifications, setViewedNotifications] = useState<Set<number>>(
    new Set(),
  );
  const [isViewed, setIsViewed] = useState(false);
  const language = useSelector(
    (state: RootState) => state.app.selectedLanguage,
  );

  useEffect(() => {
    loadViewedNotifications();
  }, [isViewed]);
  const loadViewedNotifications = async () => {
    try {
      const savedViewedNotifications = await getNotificationCount();
      if (savedViewedNotifications) {
        setViewedNotifications(new Set(JSON.parse(savedViewedNotifications)));
      }
    } catch (error) {
      console.error('Error loading viewed notifications:', error);
    }
  };

  const saveViewedNotifications = async (notification: Set<number>) => {
    try {
      await AsyncStorage.setItem(
        'viewedNotifications',
        JSON.stringify(Array.from(notification)),
      );
    } catch (error) {
      console.error('Error saving viewed notifications:', error);
    }
  };
  const handleModalClose = () => {
    setIsModalVisible(false);
    setIsViewed(true);
  };
  // Render individual notification card
  const renderNotificationCard = useCallback(
    (notification: NotificationPropTypes, index: number) => {
      const isNotificationViewed = viewedNotifications.has(notification.id);
      return (
        <Card
          key={index}
          style={[
            styles.notificationCard,
            isNotificationViewed && styles.viewedNotificationCard,
            // {
            //   backgroundColor: isNotificationViewed
            //     ? COLORS.LIGHTGRAY
            //     : COLORS.BG_WHITE,
            // },
          ]}
          onPress={() => {
            setCurrentNotification(notification);
            setIsModalVisible(true);
            setIsViewed(true);
            const isNewNotification = !viewedNotifications.has(notification.id);
            if (isNewNotification) {
              const newViewedNotifications = new Set([
                ...viewedNotifications,
                notification.id,
              ]);
              setViewedNotifications(newViewedNotifications);
              saveViewedNotifications(newViewedNotifications);
              dispatch(updateNotificationCount());
            }
          }}>
          <Card.Title
            title={LanguageString(notification.name)}
            titleStyle={[
              commonStyle.cardHeaderText,
              isNotificationViewed && styles.viewedText,
            ]}
            left={() => (
              <View style={styles.cardImage}>
                <Icon
                  name="notifications"
                  size={30}
                  color={
                    isNotificationViewed ? COLORS.LIGHTGRAY : COLORS.PRIMARY
                  }
                />
              </View>
            )}
          />
          <Card.Content style={styles.cardContent}>
            <View style={styles.modalItem}>
              <FwTextPrimary
                style={{
                  ...commonStyle.boldText, ...styles.cardText,
                  ...styles.cardText,
                  ...(isNotificationViewed ? styles.viewedText : {})
                }}>
                {LanguageString('Sent Time')} :
              </FwTextPrimary>
              <FwTextPrimary
                style={{
                  ...commonStyle.normalText,
                  ...styles.cardText,
                  ...(isNotificationViewed ? styles.viewedText : {})
                }}>
                {LanguageString(notification.sentTime)}
              </FwTextPrimary>
            </View>
            <View style={styles.modalItem}>
              <FwTextPrimary
                style={{
                  ...commonStyle.boldText, ...styles.cardText,
                  ...styles.cardText,
                  ...(isNotificationViewed ? styles.viewedText : {})
                }}>
                {LanguageString('Channel')} :
              </FwTextPrimary>
              <FwTextPrimary
                style={{
                  ...commonStyle.normalText, ...styles.cardText,
                  ...styles.cardText,
                  ...(isNotificationViewed ? styles.viewedText : {})
                }}>
                {LanguageString(notification.channel)}
              </FwTextPrimary>
            </View>
            <View style={styles.modalItem}>
              <FwTextPrimary
                style={{
                  ...commonStyle.boldText, ...styles.cardText,
                  ...styles.cardText,
                  ...(isNotificationViewed ? styles.viewedText : {})
                }}>
                {LanguageString('Delivery Status')} :
              </FwTextPrimary>
              <FwTextPrimary
                style={{
                  ...commonStyle.normalText, ...styles.cardText,
                  ...styles.cardText,
                  ...(isNotificationViewed ? styles.viewedText : {})
                }}>
                {LanguageString(notification.deliveryStatus)}
              </FwTextPrimary>
            </View>
          </Card.Content>
        </Card>
      );
    },
    [language, dispatch, viewedNotifications, isViewed],
  );

  // Render a message if no notifications
  const notificationCards = useMemo(() => {
    if (notificationData.length === 0) {
      return (
        <FwTextPrimary style={styles.notificationCardText}>
          {LanguageString('No Notification')}
        </FwTextPrimary>
      );
    }
    return notificationData.map(renderNotificationCard);
  }, [notificationData, renderNotificationCard]);

  // Render notification details modal content
  const renderNotificationDetails = useCallback(
    () => (
      <FlatList
        data={[
          {
            label: LanguageString('Sent Time'),
            value: currentNotification?.sentTime || '',
          },
          {
            label: LanguageString('Channel'),
            value: LanguageString(currentNotification?.channel || ''),
          },
          {
            label: LanguageString('Delivery Status'),
            value: LanguageString(currentNotification?.deliveryStatus || ''),
          },
          {
            label: LanguageString('Message'),
            value: LanguageString(currentNotification?.message || ''),
          },
        ]}
        ListHeaderComponent={
          <View style={commonStyle.modalHeader}>
            <FwTextSecondary style={commonStyle.modalTitle}>
              {LanguageString(currentNotification?.name || '')}
            </FwTextSecondary>
          </View>
        }
        renderItem={({item}) =>
          item.label != LanguageString('Message') ? (
            <View style={styles.modalItem}>
              <FwTextPrimary style={commonStyle.boldText}>
                {LanguageString(item.label)}:{' '}
              </FwTextPrimary>
              <FwTextPrimary style={commonStyle.normalText}>
                {LanguageString(item.value)}
              </FwTextPrimary>
            </View>
          ) : (
            <View>
              <FwTextPrimary style={commonStyle.boldText}>
                {LanguageString(item.label)}:{' '}
              </FwTextPrimary>
              <FwTextPrimary
                style={{
                  ...commonStyle.normalText,
                  textAlign: 'justify',
                }}>
                {item.value}
              </FwTextPrimary>
            </View>
          )
        }
      />
    ),
    [currentNotification, language],
  );
  // Main render function
  return (
    <>
      <TopBar navigation={navigation} routeName={PAGES.NOTIFICATIONS} />
      <FlatList
        style={styles.container}
        data={notifications}
        renderItem={({item}) => renderNotificationCard(item, item.id)}
        keyExtractor={item => item.id.toString()}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
        }
      />
      <FwModal
        visible={isModalVisible}
        onDismiss={() => handleModalClose()}
        contentContainerStyle={styles.modalContainer}>
        {renderNotificationDetails()}
        <FwButtonPrimary
          onPress={() => handleModalClose()}
          style={styles.closeButton}>
          <FwTextSecondary>{LanguageString('Close')}</FwTextSecondary>
        </FwButtonPrimary>
      </FwModal>
    </>
  );
};
// Styles for the component
const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: normalized(16),
    backgroundColor: COLORS.OFF_WHITE,
  },

  notificationCard: {
    marginBottom: normalized(16),
    elevation: normalized(2),
    backgroundColor: COLORS.BG_WHITE,
  },
  viewedNotificationCard: {
    // backgroundColor: COLORS.LIGHTGRAY,
  },
  viewedText: {
    color: COLORS.GRAY,
  },
  cardText: {
    lineHeight: normalized(24),
    fontFamily: 'Poppins-Regular',
    fontSize: normalized(16),
  },

  cardContent: {
    marginLeft: normalized(58),
    marginTop: normalized(-16),
  },
  modalContainer: {
    backgroundColor: COLORS.BG_WHITE,
    padding: normalized(24),
    margin: normalized(24),
    borderRadius: normalized(8),
    elevation: normalized(4),
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: normalized(24),
  },
  modalTitle: {
    fontSize: normalized(20),
    fontWeight: 'bold',
    color: COLORS.BLACK,
  },
  closeButton: {
    marginTop: normalized(24),
  },

  cardImage: {
    width: normalized(50),
    height: normalized(50),
    borderRadius: normalized(50),
    marginRight: normalized(16),
    marginTop: normalized(80),
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalItem: {
    flexDirection: 'row',
    marginBottom: normalized(2),
  },
  notificationCardText: {
    color: COLORS.BLACK,
  },
});

export default NotificationScreenView;
