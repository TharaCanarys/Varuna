import React, {useCallback, useEffect, useState} from 'react';
import {View, StyleSheet, ScrollView} from 'react-native';
import EscalationScreenView from './EscalationScreenView';
import {useDispatch, useSelector} from 'react-redux';
import {RootState} from '../../store/store';
import {LanguageString} from '../../constants/data';
import { EscalationScreenViewProps } from '../../types/escalationTypes';
import { setNotificationVisible, setSnackMessage, setUsers } from '../../store/appSlice';
import { getAllUsers, getEscalationData } from '../../services/apiServices';
import { User } from '../../types/userTypes';

export interface Escalation {
  id: number;
  escalationName: string;
  escalatedByUserID: number;
  escalationTime: string;
  escalationLevel: string;
  escalationType: number;
  resolutionTime: string;
  status: number;
}

interface EscalationResponse {
  data: Escalation[];
  message: string;
  statuscode: number;
  success: boolean;
}
const EscalationScreen: React.FC = () => {
  const [selectedEscalation, setSelectedEscalation] =
    useState<Escalation | null>(null);
  const [escalations, setEscalations] = useState<Escalation[]>([]);
  const dispatch = useDispatch();

  const [refreshing, setRefreshing] = useState(false);

  const onGetSuccess = (response: EscalationResponse) => {
    setEscalations(response.data);
    fetchUsers();
  };

  const onGetFailed = useCallback((error: any) => {
    dispatch(setNotificationVisible(true));
    dispatch(setSnackMessage(error.message));
    console.log('Failed to get escalation data', error.message);
  }, [dispatch]);

  useEffect(() => {
    getEscalation();
  }, []);

  const getEscalation = async () => {
    let payload = [0];
    getEscalationData(payload, onGetSuccess, onGetFailed);
  };

  const fetchUsers = async (): Promise<void> => {
      try {
        const response = await getAllUsers();
        if (response?.data) {
          dispatch(setUsers(response.data as User[]));
        }
      } catch (error: unknown) {
        console.error('Error fetching users:', error);
      }
    };

  return (
    <>
      <EscalationScreenView
        refreshing={refreshing}
        setRefreshing={setRefreshing}
        escalations={escalations}
        selectedEscalation={selectedEscalation}
        setSelectedEscalation={setSelectedEscalation}
        onRefresh={getEscalation}
      />
    </>
  );
};
export default EscalationScreen;
