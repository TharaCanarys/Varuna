import {CommonActions, NavigationProp, useNavigation} from '@react-navigation/native';
import {removeToken} from '../services/authService';
import { PAGES } from '../components/pages';

export const logout = async (navigation: any) => {
  try {
    // Remove token first
    await removeToken();
    
    // Clear any existing state
    navigation.dispatch(
      CommonActions.reset({
        index: 0,
        routes: [{name: PAGES.LOGIN}]
      })
    );

    // Force a screen refresh
    navigation.dispatch(
      CommonActions.navigate({ 
        name: PAGES.LOGIN 
      })
    );
    
  } catch (error) {
    console.error('Logout error:', error);
    throw error;
  }
};
