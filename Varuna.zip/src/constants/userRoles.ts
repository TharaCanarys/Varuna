export const USER_ROLES = {
  ADMIN: 'ADMIN',
  SUPER_ADMIN: 'SUPER_ADMIN',
  IT_SUPPORT: 'IT_SUPPORT'
} as const;
