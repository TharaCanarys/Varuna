export interface User {
  id: number;
  name: string;
  [key: string]: any;
}
