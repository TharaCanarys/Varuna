import React from 'react';
import {StyleSheet} from 'react-native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import {Card, Divider, List} from 'react-native-paper';
import {LanguageString} from '../../constants/data';
import {COLORS} from '../../constants/colors';
import {normalized} from '../../constants/platform';

const AssetsList = () => {
  const assetsData = [
    {
      name: 'Poclain Machine Big 110',
      icon: 'excavator',
      value: 3
    },
    {
      name: 'JCB Poclain Machine Medium 70',
      icon: 'bulldozer',
      value: 2
    },
    {
      name: 'Excavation Machinery Poclain Machine Mini 20',
      icon: 'excavator',
      value: 10
    },
    {
      name: 'JCB J.C.B. Machine',
      icon: 'bulldozer',
      value: 11
    },
    {
      name: 'Tipper',
      icon: 'dump-truck',
      value: 20
    },
    {
      name: 'Tractor Trolley',
      icon: 'tractor',
      value: 71
    },
    {
      name: 'Tata Magic',
      icon: 'tractor',
      value: 162
    }
  ];

  return (
    <Card style={styles.card}>
      <Card.Content>
        {assetsData.map((asset, index) => (
          <React.Fragment key={index}>
            <List.Item
              title={LanguageString(asset.name)+` : ${asset.value}`}
              left={() => (
                <Icon name={asset.icon} size={30} color={COLORS.PRIMARY} />
              )}
            />
            <Divider />
          </React.Fragment>
        ))}
      </Card.Content>
    </Card>
  );
};

export default AssetsList;

const styles = StyleSheet.create({
  card: {
    marginBottom: normalized(30),
  },
});
