import React from 'react';
import {View, StyleSheet} from 'react-native';
import {ActivityIndicator, useTheme} from 'react-native-paper';
import {IMAGES} from '../assets';
import {COLORS} from '../constants/colors';
import FwImage from '../elements/FwImage';

interface LoaderProps {
  size?: 'small' | 'large' | number;
}

/**
 * Loader component displays a loading indicator with a logo
 * @param {LoaderProps} props - The component props
 * @param {('small' | 'large' | number)} [props.size=100] - The size of the loading indicator
 * @returns {React.ReactElement} The rendered Loader component
 */
const Loader: React.FC<LoaderProps> = ({
  size = 100,
}: LoaderProps): React.ReactElement => {
  const theme = useTheme();

  return (
    <View style={styles.container}>
      <View style={styles.loaderContainer}>
        <ActivityIndicator
          size={size}
          color={COLORS.PRIMARY}
          animating={true}
        />
        <View style={styles.logoContainer}>
          <FwImage source={IMAGES.LOADER_LOGO} style={styles.logo} />
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loaderContainer: {
    position: 'relative',
  },
  logoContainer: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    justifyContent: 'center',
    alignItems: 'center',
  },
  logo: {
    width: 80,
    height: 80,
    alignSelf: 'center',
  },
});

export default Loader;
