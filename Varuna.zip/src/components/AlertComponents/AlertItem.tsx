import React from 'react';
import {LanguageString} from '../../constants/data';
import {Card, IconButton} from 'react-native-paper';
import {StyleSheet, View} from 'react-native';
import {commonStyle} from '../../constants/theme';
import {FwTextPrimary} from '../../elements';
import {COLORS} from '../../constants/colors';
import {PAGES} from '../pages';
import {normalized} from '../../constants/platform';

const AlertItem = ({
  alert,
  openAlertDetails,
  openDeleteDialog,
  validateRole,
  startEditingStatus,
}: any) => {
  return (
    <Card style={styles.alertCard} onPress={() => openAlertDetails(alert)}>
      <Card.Title
        title={LanguageString('Alerts') + ' ' + alert.id}
        titleStyle={commonStyle.cardHeaderText}
        left={props => (
          <IconButton {...props} icon="alert" style={styles.cardIcon} />
        )}
        right={props =>
          validateRole ? (
            <View style={styles.cardActions}>
              <IconButton
                {...props}
                icon="pencil"
                onPress={() => {
                  openAlertDetails(alert);
                  startEditingStatus();
                }}
                disabled={alert.status === 'Resolved'}
              />
              <IconButton
                {...props}
                icon="delete"
                onPress={() => openDeleteDialog(alert)}
              />
            </View>
          ) : null
        }
      />
      <Card.Content style={commonStyle.cardContent}>
        <View style={commonStyle.modalRow}>
          <FwTextPrimary style={commonStyle.boldText}>
            {LanguageString('Status') + ' : '}
          </FwTextPrimary>
          <FwTextPrimary style={commonStyle.normalText}>
            {LanguageString(alert.status)}
          </FwTextPrimary>
        </View>
        <View style={commonStyle.modalRow}>
          <FwTextPrimary style={commonStyle.boldText}>
            {LanguageString('Severity') + ' : '}
          </FwTextPrimary>
          <FwTextPrimary style={commonStyle.normalText}>
            {LanguageString(alert.severity)}
          </FwTextPrimary>
        </View>
      </Card.Content>
    </Card>
  );
};
export default AlertItem;

const styles = StyleSheet.create({
  alertCard: {
    marginBottom: normalized(16),
    elevation: 2,
    //backgroundColor: COLORS.BG_WHITE,
  },
  cardActions: {
    flexDirection: 'row',
  },
  cardIcon: {
    marginTop: normalized(60),
    paddingRight: normalized(13),
  },
});
