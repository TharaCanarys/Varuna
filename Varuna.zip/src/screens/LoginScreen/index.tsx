import React, {useEffect, useState} from 'react';
import {useDispatch} from 'react-redux';
import LoginScreenView from './LoginScreenView';
import {CommonActions, useNavigation} from '@react-navigation/native';
import UsersData from '../../constants/UsersData.json';
import {
  handleVerifyEmail,
  handleVerifyOTP,
  handleSetNewPassword,
  handleLogin,
  HandleSendOtp,
} from '../../services/apiServices';
import Loader from '../../components/loader';
import {DecodeJWT} from '../../components/DecodeJWT';
import {setToken, setUserDetails} from '../../store/authSlice';
import {storeToken} from '../../services/authService';
import {PAGES} from '../../components/pages';

const LoginScreen: React.FC = () => {
  const dispatch = useDispatch();
  const navigation = useNavigation();
  const [isLoading, setIsLoading] = useState(false);

  const [formState, setFormState] = useState({
    email: '',
    password: '',
    otp: '',
    confirmMobile: '',
    newPassword: '',
    confirmNewPassword: '',
  });

  const [uiState, setUiState] = useState({
    showPassword: false,
    showNewPassword: false,
    showConfirmNewPassword: false,
    isLoading: false,
    timer: 60,
  });

  const [modalState, setModalState] = useState({
    visible: false,
    otpModal: false,
    passwordModal: false,
    newPasswordModal: false,
    dialogTitle: '',
    dialogDescription: '',
  });

  const [errorState, setErrorState] = useState({
    emailError: '',
    otpError: '',
    passwordError: '',
    confirmMobileError: '',
    newPasswordError: '',
    confirmNewPasswordError: '',
  });
  const updateFormState = (field: string, value: string) => {
    setFormState(prev => ({...prev, [field]: value}));
  };

  const updateUiState = (field: string, value: boolean | number) => {
    setUiState(prev => ({...prev, [field]: value}));
  };

  const updateModalState = (field: string, value: boolean | string) => {
    setModalState(prev => ({...prev, [field]: value}));
  };

  const showDialog = (title: string, description: string) => {
    updateModalState('dialogTitle', title);
    updateModalState('dialogDescription', description);
    updateModalState('visible', true);
    setTimeout(() => updateModalState('visible', false), 2000);
  };

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (modalState.otpModal && uiState.timer > 0) {
      interval = setInterval(() => {
        updateUiState('timer', uiState.timer - 1);
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [modalState.otpModal, uiState.timer]);

  const handleResendOTP = () => {
    const payload = {
      mobileNumber: formState.email?.toString(),
    };
    HandleSendOtp(payload, onPhoneVerifySuccess, onPhoneVerifyFailed);
    // handleVerifyEmail(
    //   formState.email,
    //   (loading: boolean) => updateUiState('isLoading', loading),
    //   onPhoneVerifySuccess,
    //   onPhoneVerifyFailed,
    // );
    updateUiState('timer', 60);
  };

  const onLoginError = (data: any) => {
    showDialog('Login Error', data);
  };
  const closePasswordModal = () => {
    updateModalState('passwordModal', false);
    setErrorState(prev => ({...prev, confirmMobileError: ''}));
  };

  const onPhoneVerifySuccess = (data: any) => {
    console.log('Phone Number in Login', data);
    updateModalState('otpModal', true);
    updateUiState('timer', 60);
    showDialog('OTP Sent', data.message);
    // updateFormState('confirmMobile', '');
    // closePasswordModal();
  };

  const onPhoneVerifyFailed = (data: any) => {
    showDialog(
      'Verification Error',
      data.message === undefined
        ? 'Phone is not registered. Please try again.'
        : data.message,
    );
  };

  const handleResetPasswordSubmit = async (phone: string): Promise<void> => {
    if (phone.length == 10) {
      onPhoneVerifySuccess(phone);
    } else {
      onPhoneVerifyFailed(phone);
    }
    // handleVerifyEmail(
    //   email,
    //   (loading: boolean) => updateUiState('isLoading', loading),
    //   onPhoneVerifySuccess,
    //   onPhoneVerifyFailed,
    // );
  };
  const handleLoginSubmit = async (phone: string) => {
    const payload = {
      mobileNumber: phone?.toString(),
    };
    HandleSendOtp(payload, onPhoneVerifySuccess, onPhoneVerifyFailed);

    // onPhoneVerifySuccess(phone);
    // handleLogin(
    //   email,
    //   password,
    //   navigation,
    //   dispatch,
    //   onLoginError,
    //   setIsLoading,
    // );
  };

  const handleSignIn = async (email: string, password: string) => {
    handleLogin(email, password, onOTPVerifySuccess, onOTPVerifyFailed, (loading: boolean) => updateUiState('isLoading', loading));
  };  
  const onOTPVerifySuccess = async (data: any) => {
    const token = data.data.token;
    const decoded = DecodeJWT({token});
    if (decoded) {
      const id = (decoded as any).id;
      const role = (decoded as any).role;
      console.log('Decoded Token:', role);
      console.log('Decoded Token ID:', id);
      dispatch(setUserDetails({id, role}));
      dispatch(setToken(token));
      await storeToken(token);
      // Replace the navigation to DASHBOARD_NAV with a more specific screen
      updateUiState('loading', false);
      navigation.dispatch(
        CommonActions.reset({
          index: 0,
          routes: [{name: PAGES.DASHBOARD_NAV}], // Assuming HOME is a valid screen in your navigation
        }),
      );
      console.log('Now save token ahndhandle login:', data);
    }
  };
  const onOTPVerifyFailed = (data: any) => {
    console.log('Setting Erro state', data);
    setErrorState(prev => ({...prev, otpError: data}));
  };

  const handleVerifyOTPSubmit = async (): Promise<void> => {
    // if (formState.otp === '888888') {
    //   onOTPVerifySuccess(formState.otp);
    // } else {
    //   onOTPVerifyFailed("Otp didn't match");
    // }
    handleVerifyOTP(
      formState.confirmMobile,
      formState.otp,
      (loading: boolean) => updateUiState('isLoading', loading),
      onOTPVerifySuccess,
      onOTPVerifyFailed,
    );
  };
  const closeNewPasswordModal = () => {
    updateModalState('newPasswordModal', false);
    updateFormState('newPassword', '');
    updateFormState('confirmNewPassword', '');
    setErrorState(prev => ({
      ...prev,
      newPasswordError: '',
      confirmNewPasswordError: '',
    }));
  };

  const onSetNewPasswordSuccess = (data: any) => {
    showDialog('Password Reset', data.data);
    closeNewPasswordModal();
  };

  const onSetNewPasswordFailed = (data: any) => {
    showDialog('New Password Error', data);
  };

  const handleSetNewPasswordSubmit = async (
    newPassword: string,
    confirmNewPassword: string,
  ): Promise<void> => {
    handleSetNewPassword(
      formState.confirmEmail,
      newPassword,
      (loading: boolean) => updateUiState('isLoading', loading),
      onSetNewPasswordSuccess,
      onSetNewPasswordFailed,
    );
  };

  if (isLoading) {
    return <Loader />;
  }

  return (
    <LoginScreenView
      formState={formState}
      uiState={uiState}
      modalState={modalState}
      errorState={errorState}
      updateFormState={updateFormState}
      updateUiState={updateUiState}
      updateModalState={updateModalState}
      handleLoginSubmit={handleLoginSubmit}
      handleResetPasswordSubmit={handleResetPasswordSubmit}
      handleVerifyOTPSubmit={handleVerifyOTPSubmit}
      handleSetNewPasswordSubmit={handleSetNewPasswordSubmit}
      handleResendOTP={handleResendOTP}
      closePasswordModal={closePasswordModal}
      handleSignIn={handleSignIn}
    />
  );
};

export default LoginScreen;
