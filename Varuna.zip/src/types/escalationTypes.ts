export interface Escalation {
  id: number;
  escalationName: string;
  escalatedByUserID: number;
  escalationTime: string;
  escalationLevel: string;
  escalationType: number;
  resolutionTime: string;
  status: number;
}

export interface EscalationScreenViewProps {
    refreshing: boolean;
    setRefreshing: React.Dispatch<React.SetStateAction<boolean>>;
    escalations: Escalation[];
    selectedEscalation: Escalation | null;
    setSelectedEscalation: React.Dispatch<React.SetStateAction<Escalation | null>>;
}