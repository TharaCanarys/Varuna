import React from 'react';
import {StyleSheet, View} from 'react-native';
import {Card, Paragraph} from 'react-native-paper';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import {LanguageString} from '../../constants/data';
import {COLORS} from '../../constants/colors';
import {normalized} from '../../constants/platform';
import {commonStyle} from '../../constants/theme';

const RiskZones = ({data}: any) => {
  const riskZoneItems = [
    {
      icon: 'alert-octagon',
      color: COLORS.ERROR,
      value: data?.waterLevelBreachCountByStation,
      label: 'Emergency'
    },
    {
      icon: 'alert-circle', 
      color: COLORS.WARNING,
      value: data?.criticalSensorCountByStation,
      label: 'Critical'
    },
    {
      icon: 'alert-outline',
      color: COLORS.DARKYELLOW,
      value: data?.alertSensorCountByStation,
      label: 'Alert'
    },
    {
      icon: 'shield-check',
      color: COLORS.SUCCESS,
      value: data?.watchSensorCountByStation,
      label: 'Watch'
    },
    {
      icon: 'check-circle',
      color: COLORS.PRIMARY,
      value: data?.normalSensorCountByStation,
      label: 'Normal'
    }
  ];

  return (
    <Card style={styles.card}>
      <Card.Content>
        <View style={commonStyle.cardContainer}>
          {riskZoneItems.map((item, index) => (
            <View key={index} style={[commonStyle.metric, styles.equalCard]}>
              <Icon 
                name={item.icon}
                size={normalized(40)}
                color={item.color}
              />
              <Paragraph style={[commonStyle.metricTitle, styles.metricValue]}>
                {item.value}
              </Paragraph>
              <Paragraph style={[
                commonStyle.metricValue,
                styles.largerText
              ]}>
                {LanguageString(item.label)}
              </Paragraph>
            </View>
          ))}
        </View>
      </Card.Content>
    </Card>
  );
};

export default RiskZones;

const styles = StyleSheet.create({
  card: {
    marginBottom: normalized(16),
  },
  equalCard: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  largerText: {
    fontSize: normalized(12),
    color: COLORS.BLACK,
  },
  metricValue: {
    fontSize: normalized(16),
    color: COLORS.BLACK,
  },
});
