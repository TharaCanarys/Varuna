import React, {useCallback, useMemo} from 'react';
import {View, StyleSheet, RefreshControl, FlatList} from 'react-native';
import {Card, IconButton, HelperText} from 'react-native-paper';

import {
  FwButtonPrimary,
  FwDialog,
  FwTextInputPrimary,
  FwTextPrimary,
  FwTextSecondary,
} from '../../elements';
import {PumpStationScreenProps} from '../../types/commonTypes';
import {LanguageString, USER_ROLES, width} from '../../constants/data';
import {COLORS} from '../../constants/colors';
import FWDropdown from '../../elements/FwDropdown';
import PageHeader from '../../components/PageHeader';
import {PAGES} from '../../components/pages';
import {useSelector} from 'react-redux';
import {RootState} from '../../store/store';
import {commonStyle} from '../../constants/theme';
import {normalized} from '../../constants/platform';
import {PumpStationidOptions} from '../../constants/data';
import {ScrollView} from 'react-native-gesture-handler';
import FwModal from '../../elements/FwModal';

const PumpStationScreenView = ({
  refreshing,
  pumpStations,
  errors,
  showDatePicker,
  setShowDatePicker,
  onRefresh,
  onDateChange,
  isLoading,
  handleDeletePumpStation,
  handleUpdatePumpStation,
  openPumpStationDetails,
  selectedPumpStation,
  setSelectedPumpStation,
  closePumpStationDetails,
  newPumpStation,
  setNewPumpStation,
  handleAddNewPumpStation,
  closeAddNewPumpStation,
  isAddingNewPumpStation,
  openAddNewPumpStation,
}: PumpStationScreenProps) => {
  const [showDeleteDialog, setShowDeleteDialog] = React.useState(false);
  const [pumpStationToDelete, setPumpStationToDelete] = React.useState(null);
  const [isEditing, setIsEditing] = React.useState(false);

  const role = useSelector((state: RootState) => state.auth.userRole);
  const validateRole = useMemo(
    () =>
      role == USER_ROLES.ADMIN ||
      role == USER_ROLES.SUPER_ADMIN ||
      role == USER_ROLES.IT_SUPPORT,
    [role],
  );

  const openDeleteDialog = useCallback((pumpStation: any) => {
    setPumpStationToDelete(pumpStation);
    setShowDeleteDialog(true);
  }, []);

  const closeDeleteDialog = useCallback(() => {
    setShowDeleteDialog(false);
    setPumpStationToDelete(null);
  }, []);

  const confirmDelete = useCallback(() => {
    if (pumpStationToDelete) {
      handleDeletePumpStation(pumpStationToDelete);
    }
    closeDeleteDialog();
  }, [pumpStationToDelete, handleDeletePumpStation, closeDeleteDialog]);

  const handleUpdatePumpStationCallback = useCallback(
    (pumpStation: any) => {
      const updatedPumpStation = {
        ...pumpStation,
        enabled: !pumpStation.enabled,
      };
      handleUpdatePumpStation(updatedPumpStation);
    },
    [handleUpdatePumpStation],
  );
  const renderPumpStationCard = useCallback(
    ({item: pumpStation, index}: {item: any; index: number}) => (
      <Card
        key={index}
        style={styles.pumpStationCard}
        onPress={() => openPumpStationDetails(pumpStation)}>
        <Card.Title
          title={LanguageString(pumpStation.PumpHouseName)}
          titleStyle={commonStyle.cardHeaderText}
          left={props => (
            <IconButton
              {...props}
              style={{
                marginTop: normalized(60),
                paddingRight: normalized(20),
              }}
              icon="access-point"
            />
          )}
          right={props =>
            validateRole ? (
              <View style={styles.cardActions}>
                <IconButton
                  {...props}
                  icon="pencil"
                  onPress={() => {
                    openPumpStationDetails(pumpStation);
                  }}
                />
                <IconButton
                  {...props}
                  icon="delete"
                  onPress={() => openDeleteDialog(pumpStation)}
                />
              </View>
            ) : null
          }
        />
        <Card.Content style={styles.cardContent}>
          <View style={commonStyle.modalRow}>
            <FwTextPrimary style={commonStyle.boldText}>
              {LanguageString('Location') + ' : '}
            </FwTextPrimary>
            <FwTextPrimary style={commonStyle.normalText}>
              {LanguageString(pumpStation.Location)}
            </FwTextPrimary>
          </View>
          <View style={commonStyle.modalRow}>
            <FwTextPrimary style={commonStyle.boldText}>
              {LanguageString('Pump type') + ' : '}
            </FwTextPrimary>
            <FwTextPrimary style={commonStyle.normalText}>
              {LanguageString(pumpStation.PumpType)}
            </FwTextPrimary>
          </View>
        </Card.Content>
      </Card>
    ),
    [openPumpStationDetails, openDeleteDialog, validateRole],
  );

  const ListEmptyComponent = useCallback(
    () => (
      <FwTextPrimary style={styles.noPumpStationsText}>
        {LanguageString('No pumpStations found')}
      </FwTextPrimary>
    ),
    [],
  );
  const renderPumpStationDetails = useCallback(
    () => (
      <>
        <View style={commonStyle.modalHeader}>
          <FwTextSecondary style={commonStyle.modalTitle}>
            {LanguageString('Pump Station Details')}
          </FwTextSecondary>
          <IconButton
            icon="pencil"
            onPress={() => {
              setIsEditing(!isEditing);
            }}
          />
        </View>
        <ScrollView>
          {selectedPumpStation && (
            <>
              <FwTextInputPrimary
                label={LanguageString('Pump House Name')}
                value={String(selectedPumpStation.PumpHouseName)}
                onChangeText={(text: string) =>
                  setSelectedPumpStation({
                    ...selectedPumpStation,
                    PumpHouseName: text,
                  })
                }
                style={{
                  ...styles.input,
                  backgroundColor: isEditing
                    ? COLORS.LIGHT_PURPLE
                    : COLORS.BG_WHITE,
                  borderWidth: 0,
                }}
                editable={isEditing}
              />
              <FwTextInputPrimary
                label={LanguageString('Location ID')}
                value={String(selectedPumpStation.Locationid)}
                onChangeText={(text: string) =>
                  setSelectedPumpStation({
                    ...selectedPumpStation,
                    Locationid: parseInt(text, 10),
                  })
                }
                style={{
                  ...styles.input,
                  backgroundColor: isEditing
                    ? COLORS.LIGHT_PURPLE
                    : COLORS.BG_WHITE,
                  borderWidth: 0,
                }}
                editable={isEditing}
              />
              <FwTextInputPrimary
                label={LanguageString('Inspection Date')}
                value={String(selectedPumpStation.inspectionDate)}
                onChangeText={(text: string) =>
                  setSelectedPumpStation({
                    ...selectedPumpStation,
                    inspectionDate: text,
                  })
                }
                style={{
                  ...styles.input,
                  backgroundColor: isEditing
                    ? COLORS.LIGHT_PURPLE
                    : COLORS.BG_WHITE,
                  borderWidth: 0,
                }}
                editable={isEditing}
              />
              <FwTextInputPrimary
                label={LanguageString('Elevation')}
                value={String(selectedPumpStation.Elevation)}
                onChangeText={(text: string) =>
                  setSelectedPumpStation({
                    ...selectedPumpStation,
                    Elevation: parseFloat(text),
                  })
                }
                style={{
                  ...styles.input,
                  backgroundColor: isEditing
                    ? COLORS.LIGHT_PURPLE
                    : COLORS.BG_WHITE,
                  borderWidth: 0,
                }}
                editable={isEditing}
              />
              <FwTextInputPrimary
                label={LanguageString('Pump Type')}
                value={LanguageString(String(selectedPumpStation.PumpType))}
                onChangeText={(text: string) =>
                  setSelectedPumpStation({
                    ...selectedPumpStation,
                    PumpType: text,
                  })
                }
                style={{
                  ...styles.input,
                  backgroundColor: isEditing
                    ? COLORS.LIGHT_PURPLE
                    : COLORS.BG_WHITE,
                  borderWidth: 0,
                }}
                editable={isEditing}
              />
              <FwTextInputPrimary
                label={LanguageString('Pump Number')}
                value={String(selectedPumpStation.PumpNumber)}
                onChangeText={(text: string) =>
                  setSelectedPumpStation({
                    ...selectedPumpStation,
                    PumpNumber: parseInt(text, 10),
                  })
                }
                style={{
                  ...styles.input,
                  backgroundColor: isEditing
                    ? COLORS.LIGHT_PURPLE
                    : COLORS.BG_WHITE,
                  borderWidth: 0,
                }}
                editable={isEditing}
              />
              <FwTextInputPrimary
                label={LanguageString('Rated Power')}
                value={String(selectedPumpStation.RatedPower)}
                onChangeText={(text: string) =>
                  setSelectedPumpStation({
                    ...selectedPumpStation,
                    RatedPower: parseFloat(text),
                  })
                }
                style={{
                  ...styles.input,
                  backgroundColor: isEditing
                    ? COLORS.LIGHT_PURPLE
                    : COLORS.BG_WHITE,
                  borderWidth: 0,
                }}
                editable={isEditing}
              />
              <FwTextInputPrimary
                label={LanguageString('Location')}
                value={LanguageString(String(selectedPumpStation.Location))}
                onChangeText={(text: string) =>
                  setSelectedPumpStation({
                    ...selectedPumpStation,
                    Location: text,
                  })
                }
                style={{
                  ...styles.input,
                  backgroundColor: isEditing
                    ? COLORS.LIGHT_PURPLE
                    : COLORS.BG_WHITE,
                  borderWidth: 0,
                }}
                editable={isEditing}
              />
              <FwTextInputPrimary
                label={LanguageString('Pipe Details')}
                value={String(selectedPumpStation.PipeDetails)}
                onChangeText={(text: string) =>
                  setSelectedPumpStation({
                    ...selectedPumpStation,
                    PipeDetails: text,
                  })
                }
                style={{
                  ...styles.input,
                  textAlignVertical: 'top',
                  minHeight: normalized(width * 0.2),
                  backgroundColor: isEditing
                    ? COLORS.LIGHT_PURPLE
                    : COLORS.BG_WHITE,
                  borderWidth: 0,
                }}
                editable={isEditing}
                multiline={true}
                numberOfLines={3}
              />
              <FwTextInputPrimary
                label={LanguageString('Pump Operation Raw Data')}
                value={String(selectedPumpStation.PumpOperationRawData)}
                onChangeText={(text: string) =>
                  setSelectedPumpStation({
                    ...selectedPumpStation,
                    PumpOperationRawData: text,
                  })
                }
                style={{
                  ...styles.input,
                  textAlignVertical: 'top',
                  minHeight: normalized(width * 0.25),
                  backgroundColor: isEditing
                    ? COLORS.LIGHT_PURPLE
                    : COLORS.BG_WHITE,
                  borderWidth: 0,
                }}
                editable={isEditing}
                multiline={true}
                numberOfLines={3}
              />
            </>
          )}
          <FwButtonPrimary
            onPress={closePumpStationDetails}
            style={styles.closeButton}>
            <FwTextSecondary>{LanguageString('Cancel')}</FwTextSecondary>
          </FwButtonPrimary>
        </ScrollView>
      </>
    ),
    [selectedPumpStation, closePumpStationDetails, isEditing],
  );
  const renderAddNewPumpStation = useCallback(
    () => (
      <>
        <View style={commonStyle.modalHeader}>
          <FwTextPrimary style={commonStyle.modalTitle}>
            {LanguageString('Add New Pump Station')}
          </FwTextPrimary>
        </View>
        <FWDropdown
          multiple={false}
          label={LanguageString('Select Pump Station Id')}
          options={PumpStationidOptions}
          value={newPumpStation.PumpStationid}
          onSelect={(value: number | undefined) => {
            if (value !== undefined) {
              setNewPumpStation({...newPumpStation, PumpStationid: value});
            }
          }}
        />
        <HelperText type="error" visible={!!errors.PumpStationid}>
          {errors.PumpStationid}
        </HelperText>
      </>
    ),
    [
      newPumpStation,
      errors,
      showDatePicker,
      setNewPumpStation,
      setShowDatePicker,
      onDateChange,
      handleAddNewPumpStation,
      closeAddNewPumpStation,
    ],
  );

  const styles = useMemo(
    () =>
      StyleSheet.create({
        container: {
          flex: 1,
          padding: normalized(16),
          backgroundColor: COLORS.OFF_WHITE,
        },
        pumpStationCard: {
          marginBottom: normalized(16),
          elevation: 2,
          backgroundColor: COLORS.BG_WHITE,
        },
        addButtonContainer: {
          marginVertical: normalized(24),
          alignItems: 'center',
        },
        cardContent: {
          marginLeft: normalized(58),
          marginTop: normalized(-16),
        },
        modalContainer: {
          backgroundColor: COLORS.BG_WHITE,
          padding: normalized(24),
          margin: normalized(24),
          borderRadius: 8,
          elevation: 4,
        },
        modalHeader: {
          flexDirection: 'row',
          justifyContent: 'space-between',
          alignItems: 'center',
          marginBottom: normalized(24),
        },
        modalTitle: {
          fontSize: normalized(20),
          fontWeight: 'bold',
          color: COLORS.BLACK,
        },
        closeButton: {
          marginTop: normalized(24),
        },
        modalContent: {
          color: COLORS.BLACK,
          lineHeight: 24,
        },

        dropdownContainer: {
          marginTop: normalized(16),
          marginLeft: normalized(20),
        },
        input: {
          marginBottom: normalized(8),
        },
        cardActions: {
          flexDirection: 'row',
        },
        appBar: {
          marginTop: 'auto',
        },
        noPumpStationsText: {
          textAlign: 'center',
          marginTop: normalized(20),
          fontSize: normalized(16),
          color: COLORS.BLACK,
        },
      }),
    [],
  );

  return (
    <>
      <PageHeader title={PAGES.PUMPSTATION} />
      <FlatList
        style={styles.container}
        data={pumpStations}
        renderItem={renderPumpStationCard}
        keyExtractor={(item, index) => index.toString()}
        ListEmptyComponent={ListEmptyComponent}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
        }
        // ListFooterComponent={() => (
        //   <View style={styles.addButtonContainer}>
        //     <FwButtonPrimary
        //       mode="contained"
        //       onPress={openAddNewPumpStation}
        //       icon="plus">
        //       <FwTextSecondary>{LanguageString('Add New')}</FwTextSecondary>
        //     </FwButtonPrimary>
        //   </View>
        // )}
      />

      <FwModal
        visible={selectedPumpStation !== null}
        onDismiss={closePumpStationDetails}
        contentContainerStyle={styles.modalContainer}>
        {selectedPumpStation && renderPumpStationDetails()}
      </FwModal>
      <FwModal
        visible={isAddingNewPumpStation}
        onDismiss={closeAddNewPumpStation}
        contentContainerStyle={styles.modalContainer}>
        {renderAddNewPumpStation()}
      </FwModal>
      <FwDialog
        visible={showDeleteDialog}
        hideDialog={closeDeleteDialog}
        title={LanguageString('Delete PumpStation')}>
        <FwButtonPrimary mode="outlined" onPress={closeDeleteDialog}>
          <FwTextPrimary>{LanguageString('Cancel')}</FwTextPrimary>
        </FwButtonPrimary>
        <FwButtonPrimary mode="outlined" onPress={confirmDelete}>
          <FwTextPrimary>{LanguageString('Delete')}</FwTextPrimary>
        </FwButtonPrimary>
      </FwDialog>
    </>
  );
};

// Styles for the component
const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: normalized(16),
    backgroundColor: COLORS.OFF_WHITE,
  },
  pumpStationCard: {
    marginBottom: normalized(16),
    elevation: 2,
    backgroundColor: COLORS.BG_WHITE,
  },
  addButtonContainer: {
    marginVertical: normalized(24),
    alignItems: 'center',
  },
  cardContent: {
    marginLeft: normalized(58),
    marginTop: normalized(-16),
  },
  modalContainer: {
    backgroundColor: COLORS.BG_WHITE,
    padding: normalized(24),
    margin: normalized(24),
    borderRadius: 8,
    elevation: 4,
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: normalized(24),
  },
  modalTitle: {
    fontSize: normalized(20),
    fontWeight: 'bold',
    color: COLORS.BLACK,
  },
  closeButton: {
    marginTop: normalized(24),
  },
  modalContent: {
    color: COLORS.BLACK,
    lineHeight: 24,
  },

  dropdownContainer: {
    marginTop: normalized(16),
    marginLeft: normalized(20),
  },
  input: {
    marginBottom: normalized(8),
  },
  cardActions: {
    flexDirection: 'row',
  },
  appBar: {
    marginTop: 'auto',
  },
  noPumpStationsText: {
    textAlign: 'center',
    marginTop: normalized(20),
    fontSize: normalized(16),
    color: COLORS.BLACK,
  },
});

export default PumpStationScreenView;
