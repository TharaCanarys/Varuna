import {Dimensions, PixelRatio, Platform, ScaledSize} from 'react-native';

const {width, height} = Dimensions.get('window');
const guidelineBaseWidth = 375;
// const guidelineBaseHeight = 680;
const BASE_SCALE = width / guidelineBaseWidth;

const window = Dimensions.get('window');
export const screenWidth: number = window.width;
export const screenHeight: number = window.height;

export const widthPercentageToDP = (widthPercent: string | number): number => {
  // Parse string percentage input and convert it to number.
  const elemWidth =
    typeof widthPercent === 'number' ? widthPercent : parseFloat(widthPercent);

  // Use PixelRatio.roundToNearestPixel method in order to round the layout
  // size (dp) to the nearest one that correspons to an integer number of pixels.
  return PixelRatio.roundToNearestPixel((screenWidth * elemWidth) / 100);
};

/**
 * Converts provided height percentage to independent pixel (dp).
 * @param  {string} heightPercent The percentage of screen's height that UI element should cover
 *                                along with the percentage symbol (%).
 * @return {number}               The calculated dp depending on current device's screen height.
 */
export const heightPercentageToDP = (
  heightPercent: string | number,
): number => {
  // Parse string percentage input and convert it to number.
  const elemHeight =
    typeof heightPercent === 'number'
      ? heightPercent
      : parseFloat(heightPercent);

  // Use PixelRatio.roundToNearestPixel method in order to round the layout
  // size (dp) to the nearest one that correspons to an integer number of pixels.
  return PixelRatio.roundToNearestPixel((screenHeight * elemHeight) / 100);
};

interface OrientationComponent {
  setState: (state: {orientation: 'portrait' | 'landscape'}) => void;
}

export const isIos = (): boolean => {
  return Platform.OS === 'ios';
};

export const isWeb = (): boolean => {
  return Platform.OS === 'web';
};

export const dim = (): {width: number; height: number} => {
  return {width, height};
};

export const normalized = (size: number): number => {
  const fontScale = PixelRatio.getFontScale();
  const newSize = size * BASE_SCALE;
  if (Platform.OS === 'ios') {
    return Math.round(PixelRatio.roundToNearestPixel(newSize));
  } else {
    if (fontScale > 1) {
      return Math.round(PixelRatio.roundToNearestPixel(newSize) - 4);
    } else {
      return Math.round(PixelRatio.roundToNearestPixel(newSize));
    }
  }
};

export const isIphoneX = (): boolean => {
  return Platform.OS === 'ios' && (isIPhoneXSize() || isIPhoneXrSize());
};

export const isIPhoneXSize = (): boolean => {
  const dim = Dimensions.get('window');
  return dim.height == 812 || dim.width == 812;
};

export const isIPhoneXrSize = (): boolean => {
  const dim = Dimensions.get('window');
  return dim.height == 896 || dim.width == 896;
};

// TODO have to hadel the height

export const AppBarHeight = (props: number): number => {
  if (Platform.OS === 'ios') {
    return props;
    // return isIPhoneXrSize() || isIPhoneXSize()
    //   ? normalize(64) + StatusBarHeight()
    //   : normalize(64)
  } else {
    return props;
  }
};

export const StatusBarHeight = (): number => {
  if (Platform.OS === 'ios') {
    return normalized(24);
  } else {
    return 0;
  }
};
