import React from 'react';
import {View} from 'react-native';
import {commonStyle} from '../../constants/theme';
import {FwButtonPrimary, FwTextPrimary, FwTextSecondary} from '../../elements';
import {LanguageString} from '../../constants/data';
import {IconButton} from 'react-native-paper';
import FWDropdown from '../../elements/FwDropdown';

interface SensorDetailsComponentProps {
  selectedSensor: any;
  validateRole: boolean;
  startEditingStatus: () => void;
  editingStatus: boolean;
  statusOptions: any[];
  newStatus: any;
  setNewStatus: (value: any) => void;
  validateStatus: (newStatus: string) => void;
  saveStatus: () => void;
  closeSensorDetails: () => void;
}

const sensorDetailsComponent = ({
  selectedSensor,
  validateRole,
  startEditingStatus,
  editingStatus,
  statusOptions,
  newStatus,
  setNewStatus,
  validateStatus,
  saveStatus,
  closeSensorDetails,
}: SensorDetailsComponentProps) => {
  return (
    <>
      <View style={commonStyle.modalHeader}>
        <FwTextSecondary style={commonStyle.modalTitle}>
          {LanguageString(selectedSensor?.sensorName || '')}
        </FwTextSecondary>
        {validateRole ? (
          <IconButton icon="pencil" size={24} onPress={startEditingStatus} />
        ) : null}
      </View>

      {selectedSensor && (
        <>
          <View style={commonStyle.modalRow}>
            <FwTextPrimary style={commonStyle.boldText}>
              {LanguageString('Location')}:{' '}
            </FwTextPrimary>
            <FwTextPrimary style={commonStyle.normalText}>
              {LanguageString(selectedSensor?.locationName)}
            </FwTextPrimary>
          </View>
          <View style={commonStyle.modalRow}>
            <FwTextPrimary style={commonStyle.boldText}>
              {LanguageString('Installation Date')}:{' '}
            </FwTextPrimary>
            <FwTextPrimary style={commonStyle.normalText}>
              {new Date(selectedSensor.installedDate).toLocaleDateString(
                'en-GB',
                {day: 'numeric', month: 'numeric', year: 'numeric'},
              )}
            </FwTextPrimary>
          </View>
          <View style={commonStyle.modalRow}>
            <FwTextPrimary style={commonStyle.boldText}>
              {LanguageString('Status')}:{' '}
            </FwTextPrimary>
            <FwTextPrimary style={commonStyle.normalText}>
              {!editingStatus &&
                LanguageString(
                  selectedSensor.status == 0
                    ? 'Active'
                    : selectedSensor.status == 1
                    ? 'Inactive'
                    : selectedSensor.status == 2
                    ? 'Maintenance'
                    : 'Status Not found',
                )}
            </FwTextPrimary>
          </View>
        </>
      )}
      {editingStatus && (
        <FWDropdown
          multiple={false}
          label={LanguageString('Select Status')}
          options={statusOptions.map(option => ({
            ...option,
            value: option.value.toString(),
          }))}
          value={newStatus}
          onSelect={(value: string) => {
            if (value !== undefined) {
              setNewStatus(value);
              validateStatus(value);
            }
          }}
        />
      )}
      {editingStatus && (
        <FwButtonPrimary onPress={saveStatus} style={commonStyle.saveButton}>
          <FwTextSecondary>{LanguageString('Save')}</FwTextSecondary>
        </FwButtonPrimary>
      )}
      <FwButtonPrimary
        onPress={closeSensorDetails}
        style={commonStyle.closeButton}>
        <FwTextSecondary> {LanguageString('Cancel')}</FwTextSecondary>
      </FwButtonPrimary>
    </>
  );
};

export default sensorDetailsComponent;
