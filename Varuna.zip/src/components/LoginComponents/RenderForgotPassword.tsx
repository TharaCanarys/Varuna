import React from 'react';
import {
  FwButtonPrimary,
  FwButtonSecondary,
  FwTextInputPrimary,
  FwTextPrimary,
  FwTextSecondary,
} from '../../elements';
import {LanguageString} from '../../constants/data';
import {View} from 'react-native';

const RenderForgotPassword = ({
  styles,
  formState,
  updateFormState,
  validateConfirmMobile,
  errorState,
  handleResetPress,
  closePasswordModal,
}: any) => {
  const handleClose = () => {
    updateFormState('confirmMobile', '');
    closePasswordModal();
  };

  return (
    <View onTouchEnd={e => e.stopPropagation()}>
      <FwTextPrimary type="title_2" style={styles.modalTitle}>
        {LanguageString('Forgot Password')}
      </FwTextPrimary>
      <FwTextInputPrimary
        label={LanguageString('Enter Mobile Number')}
        value={formState.confirmMobile}
        onChangeText={(text: string) => {
          const numericText = text.replace(/[^0-9]/g, '');
          if (numericText.length <= 10) {
            updateFormState('confirmMobile', numericText);
            validateConfirmMobile(numericText);
          }
        }}
        style={styles.input}
        keyboardType="phone-pad"
        maxLength={10}
        error={!!errorState.confirmMobileError}
      />

      {errorState.confirmMobileError ? (
        <FwTextPrimary style={styles.errorText}>
          {errorState.confirmMobileError}
        </FwTextPrimary>
      ) : null}
      <FwButtonPrimary
        mode="contained"
        style={styles.modalButton}
        onPress={handleResetPress}
        disabled={formState.confirmMobile == '' ? true : false}>
        <FwTextSecondary type="buttonText">
          {LanguageString('Reset Password')}
        </FwTextSecondary>
      </FwButtonPrimary>
      <FwButtonSecondary
        mode="outlined"
        style={styles.modalButton}
        onPress={handleClose}>
        <FwTextPrimary type="buttonText">
          {LanguageString('Cancel')}
        </FwTextPrimary>
      </FwButtonSecondary>
    </View>
  );
};
export default RenderForgotPassword;
