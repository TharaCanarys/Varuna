import React, {useState} from 'react';
import SupportTicketScreenView from './SupportTicketScreenView';
import {SupportTicketPropTypes} from '../../types/commonTypes';

const SupportTicketScreen: React.FC = () => {
  const [newSupportTicket, setNewSupportTicket] =
    useState<SupportTicketPropTypes>({
      id: 0,
      location: '',
      category: '',
      priority: '',
      raisedBy: '',
      raisedDate: '',
      status: '',
      assignedTo: '',
      resolvedDate: '',
      assetType: '',
      description: '',
      resolutionDetails: '',
      remarks: '',
    });
  return (
    <SupportTicketScreenView
      newSupportTicket={newSupportTicket}
      setNewSupportTicket={setNewSupportTicket}
    />
  );
};

export default SupportTicketScreen;
