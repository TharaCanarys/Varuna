import React, {useMemo, useState, useCallback, useEffect} from 'react';
import IncidentScreenView from './IncidentScreenView';
import {incidentData, IncidentTypes} from '../../types/incidentTypes';
import {LanguageString} from '../../constants/data';
import {useNavigation} from '@react-navigation/native';
import {useDispatch} from 'react-redux';
import {PAGES} from '../../components/pages';
import {changeIncidentHeader, changeIncidentModal, setNotificationVisible, setSnackMessage} from '../../store/appSlice';
import { getIncidentData } from '../../services/apiServices';

const IncidentScreen: React.FC = () => {
  const [incidents, setIncidents] = useState<IncidentTypes[]>([]);
  const [refreshing, setRefreshing] = useState(false);
  const [isDatePickerVisible, setDatePickerVisibility] = useState(false);
  const [isAddingNewIncident, setIsAddingNewIncident] = useState(false);
  const [statusError, setStatusError] = useState('');
  const [newIncident, setNewIncident] = useState<IncidentTypes>({
    id: 0,
    alertName: '',
    reportedBy: '',
    reportedTime: '',
    location: '',
    resulationTime: '',
    status: '',
  });
  const navigation = useNavigation();
  const dispatch = useDispatch();
  const [errors, setErrors] = useState({
    alertName: '',
    reportedBy: '',
    reportedTime: '',
    location: '',
    resulationTime: '',
    status: '',
  });
  const [editingStatus, setEditingStatus] = useState(false);
  const [newStatus, setNewStatus] = useState('');
  const [selectedIncident, setSelectedIncident] =
    useState<IncidentTypes | null>(null);

  // Function to start editing status
  const startEditingStatus = useCallback(() => {
    if (selectedIncident && selectedIncident.status !== 'Resolved') {
      setEditingStatus(!editingStatus);
    }
  }, [selectedIncident, editingStatus]);

  // Function to open incident details
  const openIncidentDetails = useCallback((incident: IncidentTypes) => {
    setSelectedIncident(incident);
    setNewStatus(incident.status);
  }, []);

  // Get Incident Data

  const onGetSuccess = (data: IncidentTypes[]) => {
    setIncidents(data);
    };
  
    const onGetFailed = useCallback((error: any) => {
      dispatch(setNotificationVisible(true));
      dispatch(setSnackMessage(error.message));
  
      console.log('Failed to get incident data', error.message);
    }, []);
  
    useEffect(() => {
      getIncidents();
    }, []);
  
    const getIncidents = async () => {
      let payload = [0];
      getIncidentData(payload, onGetSuccess, onGetFailed);
    };

  // Function to open add new incident modal
  const openAddNewIncident = useCallback(() => {
    navigation.navigate(PAGES.ADDINCIDENT as never);
    dispatch(changeIncidentModal(true));
    dispatch(changeIncidentHeader(true));
    // setIsAddingNewIncident(true);
    // const indianTime = new Date().toLocaleString('en-US', {
    //   timeZone: 'Asia/Kolkata',
    // });
    // setNewIncident(prevIncident => ({
    //   ...prevIncident,
    //   reportedTime: indianTime,
    // }));
  }, []);

  // Function to close add new incident modal
  const closeAddNewIncident = useCallback(() => {
    setIsAddingNewIncident(false);
    setNewIncident({
      id: 0,
      alertName: '',
      reportedBy: '',
      reportedTime: '',
      location: '',
      resulationTime: '',
      status: '',
    });
    setErrors({
      alertName: '',
      reportedBy: '',
      reportedTime: '',
      location: '',
      resulationTime: '',
      status: '',
    });
  }, []);

  // Function to close incident details
  const closeIncidentDetails = useCallback(() => {
    setSelectedIncident(null);
    setEditingStatus(false);
  }, []);

  // Function to validate status
  const validateStatus = useCallback((newStatus: string) => {
    if (!newStatus) {
      setStatusError(LanguageString('Status is required'));
    } else {
      setStatusError('');
    }
  }, []);

  // Function to save status
  const saveStatus = useCallback(() => {
    if (selectedIncident) {
      const currentTime = new Date().toLocaleString('en-US', {
        timeZone: 'Asia/Kolkata',
      });
      const updatedIncidents = incidents.map(incident =>
        incident.id === selectedIncident.id
          ? {
              ...incident,
              status: newStatus,
              resulationTime:
                newStatus === 'Resolved'
                  ? currentTime
                  : incident.resulationTime,
            }
          : incident,
      );
      // setIncidents(updatedIncidents);
      setSelectedIncident({
        ...selectedIncident,
        status: newStatus,
        resulationTime:
          newStatus === 'Resolved'
            ? currentTime
            : selectedIncident.resulationTime,
      });
      setEditingStatus(false);
    }
  }, [selectedIncident, newStatus, incidents]);

  // Memoize the props for IncidentScreenView to prevent unnecessary re-renders
  const incidentScreenViewProps = useMemo(
    () => ({
      newIncident,
      setNewIncident,
      editingStatus,
      setEditingStatus,
      selectedIncident,
      newStatus,
      setNewStatus,
      startEditingStatus,
      openIncidentDetails,
      closeIncidentDetails,
      incidents,
      setIncidents,
      saveStatus,
      refreshing,
      setRefreshing,
      isDatePickerVisible,
      setDatePickerVisibility,
      isAddingNewIncident,
      statusError,
      errors,
      setErrors,
      openAddNewIncident,
      closeAddNewIncident,
      validateStatus,
    }),
    [
      newIncident,
      editingStatus,
      selectedIncident,
      newStatus,
      startEditingStatus,
      openIncidentDetails,
      closeIncidentDetails,
      incidents,
      saveStatus,
      refreshing,
      isDatePickerVisible,
      isAddingNewIncident,
      errors,
      statusError,
      openAddNewIncident,
      closeAddNewIncident,
      validateStatus,
    ],
  );

  return <IncidentScreenView {...incidentScreenViewProps} />;
};

export default IncidentScreen;
