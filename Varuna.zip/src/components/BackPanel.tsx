import React from 'react';
import {View} from 'react-native';
import {IconButton, Title} from 'react-native-paper';
import {useNavigation} from '@react-navigation/native';
import {FwTextInputPrimary, FwTextPrimary} from '../elements';
import {LanguageString} from '../constants/data';

const BackPanel = () => {
  const navigation = useNavigation();

  return (
    <View
      style={{
        backgroundColor: 'white',
        height: 56,
        flexDirection: 'row',
        alignItems: 'center',
        elevation: 4,
        shadowColor: '#000',
        shadowOffset: {width: 0, height: 2},
        shadowOpacity: 0.25,
        shadowRadius: 3.84,
      }}>
      <IconButton
        icon="arrow-left"
        size={24}
        onPress={() => navigation.goBack()}
        style={{position: 'absolute', left: 8}}
      />
      <View style={{flex: 1, alignItems: 'center'}}>
        <Title style={{fontSize: 18, fontWeight: 'bold'}}>
          <FwTextPrimary
            style={{
              fontSize: 22,
            }}>
            {LanguageString('Guest View')}
          </FwTextPrimary>
        </Title>
      </View>
    </View>
  );
};
export default BackPanel;
