import React from 'react';
import {Image} from 'react-native';

export default function FwImage(props: any) {
  return <Image {...props} loading="lazy" />;
}
