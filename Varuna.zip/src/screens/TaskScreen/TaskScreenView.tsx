import React, { useCallback, useEffect, useState } from 'react';
import { View, TouchableOpacity, StyleSheet, FlatList, RefreshControl } from 'react-native';
import { Card, IconButton, Text } from 'react-native-paper';
import { useDispatch, useSelector } from 'react-redux';
import i18n from '../../language/i18n';
import { User } from '../../types/commonTypes';
import PageHeader from '../../components/PageHeader';
import { TaskTypes, TaskStatus, TaskHistoryTypes, ErrorState } from '../../types/commonTypes';
import { useNavigation } from '@react-navigation/native';
import { RootState } from '../../store/store';
import { getAllUsers } from '../../services/apiServices';
import { LanguageString } from '../../constants/data';

interface TaskStatusOptions {
  value: string;
  label: string;
};

interface TaskScreenProps {
  selectedTask: TaskTypes | null;
  tasks: TaskTypes[];
  newTask: TaskTypes;
  updateTaskState: (field: keyof TaskTypes, value: any) => void;
  setNewTask: (task: TaskTypes) => void;
  errors: ErrorState;
  editingStatus: boolean;
  newStatus: string;
  setNewStatus: (status: string) => void;
  isAddingNewTask: boolean;
  setTaskToDelete: (task: TaskTypes | null) => void;
  setDeleteConfirmationVisible: (visible: boolean) => void;
  taskToDelete: TaskTypes | null;
  deleteConfirmationVisible: boolean;
  setRefreshing: (refreshing: boolean) => void;
  setSelectedTask: (task: TaskTypes | null) => void;
  setTasks: (tasks: TaskTypes[]) => void;
  setIsAddingNewTask: (isAdding: boolean) => void;
  setEditingStatus: (editing: boolean) => void;
  setStatusError: (error: string) => void;
  isDetailsVisible: boolean;
  setDetailsVisible: (visible: boolean) => void;
  refreshing: boolean;
  setErrors: (errors: ErrorState) => void;
  setShowTaskHistory: (visible: boolean) => void;
  showTaskHistory: boolean;
  setShowDeleteConfirmation: (visible: boolean) => void;
  showDeleteConfirmation: boolean;
}

const TaskScreenView: React.FC<TaskScreenProps> = ({
  selectedTask,
  tasks,
  newTask,
  updateTaskState,
  setNewTask,
  errors,
  editingStatus,
  newStatus,
  setNewStatus,
  isAddingNewTask,
  setTaskToDelete,
  setDeleteConfirmationVisible,
  taskToDelete,
  deleteConfirmationVisible,
  setRefreshing,
  setSelectedTask,
  setTasks,
  setIsAddingNewTask,
  setEditingStatus,
  setStatusError,
  isDetailsVisible,
  setDetailsVisible,
  setErrors,
  refreshing,
  setShowTaskHistory,
  showTaskHistory,
  setShowDeleteConfirmation,
  showDeleteConfirmation
}) => {
  const dispatch = useDispatch();
  const navigation = useNavigation();
  const language = useSelector(
    (state: RootState) => state.app.selectedLanguage,
  );
  const role = useSelector((state: RootState) => state.auth.userRole);
  const userId = useSelector((state: RootState) => state.auth.userId);

  const [statusOptions, setStatusOptions] = useState<TaskStatusOptions[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    setStatusOptions([
      { value: TaskStatus.ESCALATED.toString(), label: 'Escalated' },
      { value: TaskStatus.ASSIGNED.toString(), label: 'Assigned' },
      { value: TaskStatus.IN_PROGRESS.toString(), label: 'In Progress' },
    ]);
  }, []);

  const handleTaskHistory = (task: TaskTypes): void => {
    setSelectedTask(task);
    setShowTaskHistory(true);
  };

  const handleDeleteTask = (task: TaskTypes) => {
    setSelectedTask(task);
    setShowDeleteConfirmation(true);
  };

  const handleCancelDelete = () => {
    setShowDeleteConfirmation(false);
  };

  const handleConfirmDelete = () => {
    // Handle task deletion logic here
    setShowDeleteConfirmation(false);
  };

  const handleCancelHistory = () => {
    setShowTaskHistory(false);
  };

  const handleRefresh = useCallback(() => {
    setRefreshing(true);
    // Add refresh logic here
    setRefreshing(false);
  }, []);

    const users = useSelector((state: RootState) => state.app.users.data);
  
  const getUserName = useCallback((userId: string) => {
      const user = users?.find((user: User) => user.userID === userId);
      return user ? user.userName : LanguageString('Unknown');
    }, [users]);
    const getStatusName = useCallback((status: number) => {
        switch (status) {
          case 0:
            return LanguageString('Pending');
          case 1:
            return LanguageString('In Progress');
          case 2:
            return LanguageString('Completed');
          case 3:
            return LanguageString('Rejected');
          default:
            return LanguageString('Unknown');
        }
      }, []);

  const renderTaskItem = ({ item }: { item: TaskTypes }) => {
    return (
      <Card style={styles.card}>
        <Card.Content>
          <View style={styles.taskDetails}>
            <Text style={styles.taskDescription}>{item.description}</Text>
            <View style={styles.taskInfo}>
              <Text style={styles.taskField}>
                {LanguageString('Status')}: {getStatusName(item.status)}
              </Text>
              <Text style={styles.taskField}>
                {LanguageString('Assigned To')}: {getUserName(item.assignedToUserID)}
              </Text>
              <Text style={styles.taskField}>
                {LanguageString('Created By')}: {getUserName(item.createdByUserID)}
              </Text>
              <Text style={styles.taskField}>
                {LanguageString('Created Date')}: {item.creationDate}
              </Text>
            </View>
          </View>
          {/* <Card.Actions>
            <IconButton icon="eye" onPress={() => setSelectedTask(item)} />
            <IconButton
              icon="history"
              onPress={() => handleTaskHistory(item)}
            />
            <IconButton icon="delete" onPress={() => handleDeleteTask(item)} />
          </Card.Actions> */}
        </Card.Content>
      </Card>
    );
  };

  return (
    <View style={styles.container}>
      <PageHeader title={LanguageString('Grievance Redressal')} />
      <FlatList
        data={tasks}
        renderItem={renderTaskItem}
        keyExtractor={(item) => item.taskID}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={handleRefresh} />
        }
      />
      {showDeleteConfirmation && (
        <View style={styles.confirmationModal}>
          <Card>
            <Card.Content>
              <Text>{LanguageString('ARE_YOU_SURE_DELETE_TASK')}</Text>
              <View style={styles.buttonGroup}>
                <TouchableOpacity
                  style={styles.cancelButton}
                  onPress={handleCancelDelete}
                >
                  <Text>{LanguageString('CANCEL')}</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={styles.confirmButton}
                  onPress={handleConfirmDelete}
                >
                  <Text>{LanguageString('DELETE')}</Text>
                </TouchableOpacity>
              </View>
            </Card.Content>
          </Card>
        </View>
      )}
      {showTaskHistory && selectedTask && (
        <View style={styles.historyModal}>
          <Card>
            <Card.Content>
              <Text>{LanguageString('TASK_HISTORY')}</Text>
              {selectedTask.taskHistory.map((history: TaskHistoryTypes) => (
                <View key={history.id} style={styles.historyItem}>
                  <Text>
                    {LanguageString('COMMENTS')}: {history.comments}
                  </Text>
                  <Text>
                    {LanguageString('CHANGED_BY')}: {history.changedBy}
                  </Text>
                  <Text>
                    {LanguageString('CHANGED_DATE')}: {history.changedDate}
                  </Text>
                  <Text>
                    {LanguageString('OLD_STATUS')}: {history.oldStatus}
                  </Text>
                  <Text>
                    {LanguageString('NEW_STATUS')}: {history.newStatus}
                  </Text>
                </View>
              ))}
              <TouchableOpacity
                style={styles.closeButton}
                onPress={handleCancelHistory}
              >
                <Text>{LanguageString('CLOSE')}</Text>
              </TouchableOpacity>
            </Card.Content>
          </Card>
        </View>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
    padding: 16,
  },
  card: {
    marginBottom: 16,
  },
  taskDetails: {
    flex: 1,
  },
  taskDescription: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  taskInfo: {
    marginTop: 8,
  },
  taskField: {
    fontSize: 14,
    marginBottom: 4,
  },
  confirmationModal: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  buttonGroup: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'center',
    marginTop: 16,
  },
  cancelButton: {
    backgroundColor: '#fff',
    padding: 12,
    borderRadius: 8,
    marginRight: 8,
  },
  confirmButton: {
    backgroundColor: '#dc3545',
    padding: 12,
    borderRadius: 8,
  },
  historyModal: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  historyItem: {
    marginBottom: 16,
  },
  closeButton: {
    backgroundColor: '#fff',
    padding: 12,
    borderRadius: 8,
    marginTop: 16,
  }
});

export default TaskScreenView;
